using System;
using System.ComponentModel;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using NitroxLauncher.Models.Events;
using NitroxLauncher.Models.Properties;
using NitroxLauncher.Pages;
using NitroxModel.Helper;

namespace NitroxLauncher
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public string Version => $"{LauncherLogic.ReleasePhase} {LauncherLogic.Version}";

        public object FrameContent
        {
            get => frameContent;
            set
            {
                frameContent = value;
                OnPropertyChanged();

                Type pageType = value is ServerConsolePage ? typeof(ServerPage) : value?.GetType();
                foreach (UIElement item in NavigationButtons.Children)
                {
                    if (item is Button button)
                    {
                        ButtonProperties.SetSelected(button, pageType != null && button.Tag as Type == pageType);
                    }
                }
            }
        }

        public bool UpdateAvailable => !LauncherLogic.Config.IsUpToDate;

        private readonly LauncherLogic logic;
        private bool isServerEmbedded;
        private object frameContent;

        public MainWindow()
        {
            Log.Setup();
            LauncherNotifier.Setup();
            
            logic = new LauncherLogic();

            MaxHeight = SystemParameters.VirtualScreenHeight;
            MaxWidth = SystemParameters.VirtualScreenWidth;

            LauncherLogic.Config.PropertyChanged += (s, e) => OnPropertyChanged(nameof(UpdateAvailable));
            LauncherLogic.Server.ServerStarted += ServerStarted;
            LauncherLogic.Server.ServerExited += ServerExited;

            InitializeComponent();
            FrameContent = Application.Current.FindResource(nameof(LaunchGamePage));
            ContentRendered += (_, _) => FirstLaunchReel.PlayOnFirstLaunch();

            // Pirate trigger should happen after UI is loaded.
            Loaded += (sender, args) =>
            {
                // Error if running from a temporary directory because Nitrox Launcher won't be able to write files directly to zip/rar
                // Tools like WinRAR do this to support running EXE files while it's still zipped.
                if (Directory.GetCurrentDirectory().StartsWith(Path.GetTempPath(), StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Nitrox launcher should not be executed from a temporary directory. Install Nitrox launcher properly by extracting ALL files and moving these to a dedicated location on your PC.",
                                    "Invalid working directory",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Error);
                    Environment.Exit(1);
                }
                
                // Deep Current: never replace the launcher with unrelated web
                // content. No game DRM or platform API files are modified.

                if (!NetworkInterface.GetIsNetworkAvailable())
                {
                    Log.Warn("Launcher may not be connected to internet");
                    LauncherNotifier.Error("Launcher may not be connected to internet");
                }

                if (!NitroxEnvironment.IsReleaseMode)
                {
                    LauncherNotifier.Warning("You're now using Nitrox DEV build");
                }
            };

            _ = LoadGamePathAsync();
        }

        private async Task LoadGamePathAsync()
        {
            try
            {
                await logic.SetTargetedSubnauticaPath(NitroxUser.GamePath);
            }
            catch (Exception error)
            {
                Log.Warn("Unable to configure the game path: " + error.Message);
            }
        }

        private bool CanClose()
        {
            if (LauncherLogic.Server.IsServerRunning && isServerEmbedded)
            {
                MessageBoxResult userAnswer = MessageBox.Show("The embedded server is still running. Click yes to close.", "Close aborted", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                return userAnswer == MessageBoxResult.Yes;
            }

            return true;
        }

        private void OnClosing(object sender, CancelEventArgs e)
        {
            if (!CanClose())
            {
                e.Cancel = true;
                return;
            }

            logic.Dispose();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Minimze_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Restore_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void ServerStarted(object sender, ServerStartEventArgs e)
        {
            isServerEmbedded = e.IsEmbedded;

            if (e.IsEmbedded)
            {
                LauncherLogic.Instance.NavigateTo<ServerConsolePage>();
            }
        }

        private void ServerExited(object sender, EventArgs e)
        {
            Dispatcher?.Invoke(() =>
            {
                if (sender is System.Diagnostics.Process process && process.ExitCode == 0 && LauncherLogic.Instance.NavigationIsOn<ServerConsolePage>())
                {
                    LauncherLogic.Instance.NavigateTo<ServerPage>();
                }
            });
        }

        private void ButtonNavigation_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button)
            {
                LauncherLogic.Instance.NavigateTo(button.Tag as Type);
            }
        }

        private void Discord_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(
                    "https://discord.com/channels/1569024689509236746/1569025586859479233") { UseShellExecute = true });
            }
            catch (Exception error)
            {
                Log.Warn("Unable to open Discord: " + error.Message);
                MessageBox.Show(this, "Could not open Discord in your browser.", "TIDRA", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}



