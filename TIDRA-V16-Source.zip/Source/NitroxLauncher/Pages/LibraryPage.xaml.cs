using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;
using NitroxLauncher.Models;
using NitroxModel.Helper;

namespace NitroxLauncher.Pages
{
    public partial class LibraryPage : PageBase
    {
        public LibraryPage()
        {
            InitializeComponent();
            Loaded += (_, _) => RefreshGameStatus();
        }

        private void RefreshGameStatus()
        {
            try
            {
                GameStatus.Text = GameZipImport.IsCompatible(LauncherLogic.Config.SubnauticaPath)
                    ? "LEGACY 68598 · READY"
                    : "NO COMPATIBLE INSTALLATION SELECTED";
            }
            catch (IOException)
            {
                GameStatus.Text = "INSTALLATION COULD NOT BE READ";
            }
            catch (UnauthorizedAccessException)
            {
                GameStatus.Text = "INSTALLATION COULD NOT BE READ";
            }
        }

        private async void Import_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new() { Filter = "ZIP archives (*.zip)|*.zip", Title = "Select your Subnautica ZIP" };
            if (dialog.ShowDialog(Window.GetWindow(this)) != true)
            {
                return;
            }

            await ConnectAsync(async () =>
            {
                ImportProgress.Visibility = Visibility.Visible;
                ImportProgress.Value = 0;
                ImportStatus.Text = "Checking archive…";
                Progress<int> progress = new(percent =>
                {
                    ImportProgress.Value = percent;
                    ImportStatus.Text = $"Extracting game · {percent}%";
                });
                return await Task.Run(() => GameZipImport.Extract(dialog.FileName, DeepCurrentLegacy.DataDirectory, progress));
            });
        }

        private async Task ConnectAsync(Func<Task<string>> selectPath)
        {
            ImportButton.IsEnabled = false;
            try
            {
                string path = await selectPath();
                if (!GameZipImport.IsCompatible(path))
                {
                    throw new InvalidDataException("Choose a complete Subnautica Legacy 68598 installation.");
                }

                if (await LauncherLogic.Instance.SetTargetedSubnauticaPath(path) == null)
                {
                    throw new IOException("The selected installation could not be connected.");
                }

                ImportStatus.Text = "Subnautica is ready. Return to Play to start the game.";
            }
            catch (Exception error)
            {
                ImportStatus.Text = $"Could not connect Subnautica. {error.Message}";
            }
            finally
            {
                ImportProgress.Visibility = Visibility.Collapsed;
                ImportButton.IsEnabled = true;
                RefreshGameStatus();
            }
        }
    }
}
