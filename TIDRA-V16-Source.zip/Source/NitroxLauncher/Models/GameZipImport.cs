using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.RegularExpressions;
using NitroxModel.Helper;

namespace NitroxLauncher.Models
{
    internal static class GameZipImport
    {
        private const string GameExecutable = "Subnautica.exe";
        private const string GameAssembly = "Subnautica_Data/Managed/Assembly-CSharp.dll";
        private static readonly Regex ReservedName = new(@"^(CON|PRN|AUX|NUL|COM[0-9¹²³]|LPT[0-9¹²³])(?:\.|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        public static bool IsCompatible(string directory) =>
            !string.IsNullOrWhiteSpace(directory) &&
            File.Exists(Path.Combine(directory, GameExecutable)) &&
            File.Exists(Path.Combine(directory, GameAssembly)) &&
            DeepCurrentLegacy.IsSupportedDirectory(directory);

        public static string Extract(string zipPath, string dataDirectory, IProgress<int> progress)
        {
            using ZipArchive archive = ZipFile.OpenRead(zipPath);
            ZipArchiveEntry[] games = archive.Entries.Where(entry =>
                string.Equals(entry.Name, GameExecutable, StringComparison.OrdinalIgnoreCase)).ToArray();
            if (games.Length != 1)
            {
                throw new InvalidDataException("The ZIP must contain exactly one Subnautica.exe.");
            }

            string gameEntry = games[0].FullName.Replace('\\', '/');
            string gameFolder = gameEntry.Substring(0, gameEntry.Length - GameExecutable.Length);
            string imports = Path.GetFullPath(Path.Combine(dataDirectory, "imported-games"));
            Directory.CreateDirectory(imports);
            string id = Guid.NewGuid().ToString("N");
            string staging = Path.Combine(imports, ".import-" + id);
            string destination = Path.Combine(imports, "Legacy-68598-" + id);
            string root = staging + Path.DirectorySeparatorChar;
            long total = archive.Entries.Sum(entry => entry.Length);
            if (total > new DriveInfo(Path.GetPathRoot(imports)).AvailableFreeSpace)
            {
                throw new IOException("There is not enough free space to extract this ZIP.");
            }

            // Check every name before any archive data is written.
            foreach (ZipArchiveEntry entry in archive.Entries)
            {
                ResolveEntry(root, entry.FullName);
            }

            Directory.CreateDirectory(staging);
            try
            {
                long extracted = 0;
                int lastPercent = -1;
                byte[] buffer = new byte[128 * 1024];
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    string path = ResolveEntry(root, entry.FullName);
                    if (entry.FullName.EndsWith("/", StringComparison.Ordinal) ||
                        entry.FullName.EndsWith("\\", StringComparison.Ordinal))
                    {
                        Directory.CreateDirectory(path);
                        continue;
                    }

                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    using Stream input = entry.Open();
                    using FileStream output = new(path, FileMode.CreateNew);
                    long remaining = entry.Length;
                    int read;
                    while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        remaining -= read;
                        if (remaining < 0)
                        {
                            throw new InvalidDataException("A ZIP entry exceeds its declared size.");
                        }
                        output.Write(buffer, 0, read);
                        extracted += read;
                        int percent = (int)(100d * extracted / total);
                        if (percent != lastPercent)
                        {
                            lastPercent = percent;
                            progress?.Report(percent);
                        }
                    }
                    if (remaining != 0)
                    {
                        throw new InvalidDataException("The ZIP contains an incomplete file.");
                    }
                }

                if (!IsCompatible(Path.Combine(staging, gameFolder)))
                {
                    throw new InvalidDataException("The ZIP does not contain a complete Legacy 68598 installation.");
                }

                Directory.Move(staging, destination);
                return Path.GetFullPath(Path.Combine(destination, gameFolder));
            }
            finally
            {
                if (Directory.Exists(staging))
                {
                    Directory.Delete(staging, true);
                }
            }
        }

        private static string ResolveEntry(string root, string entryName)
        {
            string[] parts = entryName.Replace('\\', '/').TrimEnd('/').Split('/');
            if (parts.Any(part => part.Length == 0 || part.EndsWith(".", StringComparison.Ordinal) ||
                part.EndsWith(" ", StringComparison.Ordinal) || part.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 ||
                ReservedName.IsMatch(part)))
            {
                throw new InvalidDataException("The ZIP contains an unsafe file path.");
            }

            string path = Path.GetFullPath(Path.Combine(root, Path.Combine(parts)));
            if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("The ZIP contains a path outside the import folder.");
            }
            return path;
        }
    }
}
