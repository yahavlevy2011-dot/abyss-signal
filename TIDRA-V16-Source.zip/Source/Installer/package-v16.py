from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
import json

source=Path('C:/Users/Yahav/Documents/Codex/2026-10-31/referenced-chatgpt-conversation-this-is-an-2/outputs/DeepCurrent-Legacy')
stage=Path('work/tidra-v16-release')
stage.mkdir(exist_ok=True)
setup=Path('work/tidra-v15-release/TidraSetup.cs').read_text(encoding='utf-8-sig')
setup=setup.replace('#if TIDRA_V15_SEED', '#if TIDRA_V16_SEED\n    private const int EmbeddedVersion = 92;\n#elif TIDRA_V15_SEED',1)
setup=setup.replace('AssemblyFileVersion("4.0.0.0")','AssemblyFileVersion("16.0.0.0")')
(stage/'TidraSetup.cs').write_text(setup,encoding='utf-8')

with ZipFile('work/tidra-v15-release/TIDRA-V15.zip') as old:
    files={n:old.read(n) for n in old.namelist() if not n.endswith('/')}
files['AbyssSignal.exe']=(source/'NitroxLauncher/bin/Debug/NitroxLauncher.exe').read_bytes()
files['AbyssSignal.Server.exe']=(source/'NitroxServer-Subnautica/bin/Debug/NitroxServer-Subnautica.exe').read_bytes()
for name in ('NitroxClient','NitroxPatcher','NitroxModel','NitroxModel-Subnautica','NitroxServer'):
    files[f'lib/{name}.dll']=(source/f'NitroxLauncher/bin/Debug/lib/{name}.dll').read_bytes()
notes='''TIDRA V16 — tested multiplayer fixes

Includes shared opening readiness/skip, remote held-tool inventory identification,
camera aim synchronization, initial world-cell reconciliation and join rejection/cancel fixes.
Samples passed in two real local game clients: matched world items, pickup in both
directions, reload persistence, tools/PDA, Fabricator occupancy, basic construction,
short Seamoth/Prawn entry/movement/exit tests.

Not a full-game certification. Creature movement, sustained swim smoothness,
cross-computer latency, all biomes, Cyclops, Aurora and the ending remain incomplete.
The unverified experimental fish-motion change is NOT included.
Both the server and all clients must update together. Stop the old server first.
No Subnautica game files are included. Existing game installation and worlds remain separate.
'''
files['VERIFIED_RESULTS_HE.md']=notes.encode('utf-8')
files['READ_FIRST_HE.txt']=('TIDRA V16\nיש לעדכן גם את השרת וגם את כל השחקנים, ולסגור את השרת הישן לפני ההפעלה.\nהמשחק עצמו אינו כלול.\nתיקונים נבדקו בשני מופעים מקומיים; עדיין לא כל המשחק נבדק.\n').encode('utf-8')
files['MANIFEST_SHA256.json']=json.dumps({n:sha256(data).hexdigest() for n,data in sorted(files.items())},indent=2).encode()
with ZipFile(stage/'TIDRA-V16.zip','w',ZIP_DEFLATED) as z:
    for name,data in sorted(files.items()):
        assert Path(name).name.lower() not in {'subnautica.exe','assembly-csharp.dll','steam_emu.ini'}
        z.writestr(name,data)
with ZipFile(stage/'TIDRA-V16.zip') as z:
    assert z.testzip() is None
    for name,digest in json.loads(z.read('MANIFEST_SHA256.json')).items():
        assert sha256(z.read(name)).hexdigest()==digest
digest=sha256((stage/'TIDRA-V16.zip').read_bytes()).hexdigest()
(stage/'catalog.txt').write_text(f'92\nTIDRA-V16.zip\n{digest}\n',encoding='ascii')
(stage/'index.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>TIDRA downloads</title><h1>TIDRA V16</h1><p><a href="TIDRA-Setup.exe">Download the Windows installer</a></p><p><a href="TIDRA-V16-Source.zip">Source and license</a> · <a href="catalog.txt">Update catalog</a></p></html>',encoding='utf-8')
with ZipFile('work/tidra-v15-release/TIDRA-V15-Source.zip') as old:
    sources={n:old.read(n) for n in old.namelist() if not n.endswith('/')}
for name in list(sources):
    if name.startswith('Source/') and (source/name[7:]).is_file():
        sources[name]=(source/name[7:]).read_bytes()
for file in source.rglob('*'):
    if not file.is_file() or file.suffix.lower() not in {'.cs','.csproj','.xaml'}: continue
    rel=file.relative_to(source)
    if any(p.lower() in {'bin','obj','.git','packages','generated_files'} for p in rel.parts): continue
    sources['Source/'+rel.as_posix()]=file.read_bytes()
sources['Source/Installer/TidraSetup.cs']=(stage/'TidraSetup.cs').read_bytes()
sources['Source/Installer/package-v16.py']=Path(__file__).read_bytes()
sources['RELEASE_NOTES.txt']=notes.encode('utf-8')
with ZipFile(stage/'TIDRA-V16-Source.zip','w',ZIP_DEFLATED) as z:
    for name,data in sorted(sources.items()): z.writestr(name,data)
print('Runtime SHA256:',digest)
print('Runtime files:',len(files),'Source files:',len(sources))
