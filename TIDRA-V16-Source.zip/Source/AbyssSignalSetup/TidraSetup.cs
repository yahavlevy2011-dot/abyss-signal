using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyFileVersion("4.0.0.0")]

internal static class TidraSetup
{
#if TIDRA_V13_SEED
    private const int EmbeddedVersion = 89;
#elif TIDRA_V13_HUB
    private const int EmbeddedVersion = 88;
#elif TIDRA_V12_SEED
    private const int EmbeddedVersion = 88;
#elif TIDRA_HUB
    private const int EmbeddedVersion = 87;
#elif TIDRA_DESIGN_PREVIEW
    private const int EmbeddedVersion = 87;
#elif V8_SEED
    private const int EmbeddedVersion = 84;
#elif V7_SEED
    private const int EmbeddedVersion = 83;
#elif V5_SEED
    private const int EmbeddedVersion = 81;
#elif V3_SEED
    private const int EmbeddedVersion = 79;
#elif V2_SEED
    private const int EmbeddedVersion = 78;
#else
    private const int EmbeddedVersion = 77;
#endif
    private const int FirstPublicVersion = 77;
    private const string DefaultFeed = "https://yahavlevy2011-dot.github.io/abyss-signal/catalog.txt";
    private const long MaxPackage = 150 * 1024 * 1024;
    private const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\AbyssSignal";
    private static string root;
    private static string Versions { get { return Path.Combine(root, "versions"); } }
    private static string RequiredFile { get { return Path.Combine(root, "required-update.txt"); } }
    private static string FeedFile { get { return Path.Combine(root, "update-source.txt"); } }

    [STAThread]
    private static int Main(string[] args)
    {
#if TIDRA_DESIGN_PREVIEW
        if (args.Length == 0)
        {
            root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "TIDRA", "Design Preview");
            try
            {
                using (var gate = new Mutex(false, @"Local\TIDRA.DesignPreview"))
                {
                    bool acquired;
                    try { acquired = gate.WaitOne(TimeSpan.FromSeconds(20)); }
                    catch (AbandonedMutexException) { acquired = true; }
                    if (!acquired) throw new IOException("The preview is still preparing its files. Try again in a moment.");
                    try
                    {
                        Directory.CreateDirectory(Versions);
                        InstallEmbedded(null);
                        OpenLauncher();
                    }
                    finally { gate.ReleaseMutex(); }
                }
                return 0;
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "TIDRA Design Preview", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
#endif
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        bool test = args.Length >= 2 && args[0] == "--test-root";
        root = test ? Path.GetFullPath(args[1]) : Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TIDRA", "Deep Current");
        if (args.Length == 2 && args[0] == "--uninstall-worker")
            return CompleteUninstall(args[1]);

        using (Mutex gate = new Mutex(false, @"Local\TIDRA.DeepCurrent.Setup"))
        {
            bool acquired;
            try { acquired = gate.WaitOne(0); }
            catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) return 2;
            try
            {
                if (!test && args.Length == 1 && args[0] == "--uninstall")
                {
                    BeginUninstall();
                    return 0;
                }

                if (!test && args.Length == 1 && args[0] == "--register-brand")
                {
                    if (Latest() == 0 || !string.Equals(Application.ExecutablePath, HubPath, StringComparison.OrdinalIgnoreCase))
                        return 1;
                    RegisterShortcut();
                    return 0;
                }

                if (test && args.Length == 3 && args[2] == "--test-remove")
                {
                    RemoveInstalledVersions();
                    return 0;
                }

                Directory.CreateDirectory(Versions);
                if (test)
                {
                    InstallEmbedded(null);
                    if (args.Length == 3) Update(args[2]);
                    Console.WriteLine("Installed " + VersionLabel(Latest()));
                    return 0;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                if (Latest() == 0 || !string.Equals(Application.ExecutablePath, HubPath, StringComparison.OrdinalIgnoreCase))
                    Application.Run(new SetupWizard());
                else
                    OpenFromShortcut();
                return 0;
            }
            catch (Exception error)
            {
                if (test) Console.Error.WriteLine(error.Message);
                else MessageBox.Show(error.Message, "TIDRA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
            finally { gate.ReleaseMutex(); }
        }
    }

    private static string HubPath { get { return Path.Combine(root, "Abyss Signal Hub.exe"); } }

    private static string VersionLabel(int version)
    {
        return version >= FirstPublicVersion ? "V" + (version - FirstPublicVersion + 1) : "Preview " + version;
    }

    private static void InstallEmbedded(Action<int, string> progress)
    {
        int previous = Latest();
        if (previous >= EmbeddedVersion) return;
        using (Stream seed = Assembly.GetExecutingAssembly().GetManifestResourceStream("tidra.seed"))
            Install(seed, EmbeddedVersion, previous, progress);
    }

    private static void OpenLauncher()
    {
        string directory = VersionPath(Latest());
        Process.Start(new ProcessStartInfo(LauncherPath(directory)) { WorkingDirectory = directory });
    }

    private static void OpenFromShortcut()
    {
        int required = 0;
        if (File.Exists(RequiredFile)) int.TryParse(File.ReadAllText(RequiredFile), out required);
        string source = UpdateSource();
        Release available = null;
        try
        {
            if (!string.IsNullOrWhiteSpace(source))
            {
                // Limit how long the shortcut waits even if DNS or the server stalls.
                Task<Release> check = Task.Run(() => ReadRelease(source));
                if (check.Wait(TimeSpan.FromSeconds(2))) available = check.Result;
            }
        }
        catch (Exception)
        {
            // The installed version can start when the update service is unavailable.
        }

        int installed = Latest();
        if (available != null && available.Version > Math.Max(installed, required))
        {
            required = available.Version;
            File.WriteAllText(RequiredFile, required.ToString(CultureInfo.InvariantCulture));
        }
        if (required > installed)
        {
            using (var prompt = new UpdateWindow(required, source, available))
                if (prompt.ShowDialog() != DialogResult.OK || Latest() < required) return;
        }

        OpenLauncher();
    }

    private static string VersionPath(int version)
    {
        return Path.Combine(Versions, version.ToString(CultureInfo.InvariantCulture));
    }

    private static string LauncherPath(string directory)
    {
        string branded = Path.Combine(directory, "AbyssSignal.exe");
        return File.Exists(branded) ? branded : Path.Combine(directory, "TIDRA.exe");
    }

    private static bool Installed(int version)
    {
        string path = VersionPath(version);
        return File.Exists(Path.Combine(path, ".ready")) && File.Exists(LauncherPath(path));
    }

    private static int Latest()
    {
        return Directory.EnumerateDirectories(Versions).Select(Path.GetFileName)
            .Select(name => { int number; return int.TryParse(name, out number) && Installed(number) ? number : 0; })
            .DefaultIfEmpty(0).Max();
    }

    private static void Install(Stream payload, int version, int previous, Action<int, string> progress = null)
    {
        string target = VersionPath(version);
        string stage = Path.Combine(Versions, ".install-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(stage);
        try
        {
            string safeRoot = Path.GetFullPath(stage) + Path.DirectorySeparatorChar;
            long extracted = 0;
            int reported = -1;
            using (ZipArchive zip = new ZipArchive(payload, ZipArchiveMode.Read, true))
            {
                long total = zip.Entries.Sum(entry => entry.Length);
                if (total > MaxPackage) throw new InvalidDataException("Package is too large.");
                foreach (ZipArchiveEntry entry in zip.Entries)
                {
                    if (entry.FullName.Contains(":"))
                        throw new InvalidDataException("Invalid package file name.");
                    string path = Path.GetFullPath(Path.Combine(stage, entry.FullName));
                    if (!path.StartsWith(safeRoot, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidDataException("Invalid package file path.");
                    if (string.IsNullOrEmpty(entry.Name)) { Directory.CreateDirectory(path); continue; }
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    using (Stream source = entry.Open())
                    using (FileStream destination = new FileStream(path, FileMode.CreateNew))
                        source.CopyTo(destination);
                    extracted += entry.Length;
                    int percent = total == 0 ? 0 : (int)(extracted * 95 / total);
                    if (percent != reported && progress != null)
                    {
                        reported = percent;
                        progress(percent, "Installing " + entry.Name);
                    }
                }
            }

            if (!File.Exists(LauncherPath(stage)) ||
                !(File.Exists(Path.Combine(stage, "AbyssSignal.Server.exe")) || File.Exists(Path.Combine(stage, "TIDRA.Server.exe"))))
                throw new InvalidDataException("Package is missing the launcher or server.");
            foreach (string file in new[] { @"lib\NitroxClient.dll", @"lib\NitroxPatcher.dll" })
                if (!File.Exists(Path.Combine(stage, file))) throw new InvalidDataException("Package is missing " + file);
            if (previous > 0)
            {
                string previousServers = Path.Combine(VersionPath(previous), "servers");
                if (File.Exists(previousServers)) File.Copy(previousServers, Path.Combine(stage, "servers"), true);
            }
            File.WriteAllText(Path.Combine(stage, ".ready"), "");
            Directory.Move(stage, target);
            if (progress != null) progress(100, "Files installed.");
        }
        finally
        {
            if (Directory.Exists(stage)) Directory.Delete(stage, true);
        }
    }

    private static Uri SourceUri(string input)
    {
        Uri uri;
        if (Path.IsPathRooted(input) && !input.StartsWith(@"\\")) uri = new Uri(Path.GetFullPath(input));
        else if (!Uri.TryCreate(input, UriKind.Absolute, out uri)) throw new InvalidDataException("Use an HTTPS URL or a local catalog path.");
        if (uri.Scheme != "https" && !(uri.IsFile && !uri.IsUnc))
            throw new InvalidDataException("Only HTTPS and local catalog files are supported.");
        return uri;
    }

    private static byte[] Read(Uri uri, long limit, Action<long> progress = null)
    {
        if (uri.IsFile)
        {
            using (FileStream source = File.OpenRead(uri.LocalPath)) return ReadLimited(source, limit, progress);
        }
        var request = (HttpWebRequest)WebRequest.Create(uri);
        request.Timeout = 12000;
        request.ReadWriteTimeout = 12000;
        request.AllowAutoRedirect = false;
        request.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.Reload);
        using (var response = (HttpWebResponse)request.GetResponse())
        {
            if (response.StatusCode != HttpStatusCode.OK) throw new IOException("Update source must return HTTP 200.");
            using (Stream source = response.GetResponseStream()) return ReadLimited(source, limit, progress);
        }
    }

    private static byte[] ReadLimited(Stream source, long limit, Action<long> progress)
    {
        using (var buffer = new MemoryStream())
        {
            byte[] block = new byte[65536];
            int count;
            while ((count = source.Read(block, 0, block.Length)) > 0)
            {
                if (buffer.Length + count > limit) throw new InvalidDataException("Download exceeded the expected size.");
                buffer.Write(block, 0, count);
                if (progress != null) progress(buffer.Length);
            }
            return buffer.ToArray();
        }
    }

    private static void Update(string source, Action<int, string> progress = null, int minimumVersion = 1)
    {
        Release release = ReadRelease(source);
        if (release.Version >= minimumVersion) InstallRelease(release, progress);
    }

    private sealed class Release
    {
        public readonly int Version;
        public readonly Uri Package;
        public readonly string Sha256;

        public Release(int version, Uri package, string sha256)
        {
            Version = version;
            Package = package;
            Sha256 = sha256;
        }
    }

    private static Release ReadRelease(string source)
    {
        Uri catalog = SourceUri(source);
        string[] lines = System.Text.Encoding.UTF8.GetString(Read(catalog, 4096)).Trim().Split('\n').Select(x => x.Trim()).ToArray();
        int version;
        if (lines.Length != 3 || !int.TryParse(lines[0], out version) || version < 1 || lines[2].Length != 64 || !lines[2].All(Uri.IsHexDigit))
            throw new InvalidDataException("Invalid update catalog.");
        Uri package = new Uri(catalog, lines[1]);
        if (package.Scheme != catalog.Scheme || !string.Equals(package.Authority, catalog.Authority, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("The package must use the same source as the catalog.");
        return new Release(version, package, lines[2]);
    }

    private static void InstallRelease(Release release, Action<int, string> progress)
    {
        int installed = Latest();
        int version = release.Version;
        if (version <= installed) return;

        long shown = -1;
        byte[] data = Read(release.Package, MaxPackage, bytes =>
        {
            long megabytes = bytes / 1048576;
            if (progress != null && megabytes != shown)
            {
                shown = megabytes;
                progress(-1, "Downloading " + VersionLabel(version) + " (" + megabytes + " MB)...");
            }
        });
        if (progress != null) progress(0, "Verifying the download...");
        using (SHA256 sha = SHA256.Create())
        {
            string digest = BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "");
            if (!string.Equals(digest, release.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Package integrity check failed.");
        }
        using (var stream = new MemoryStream(data, false)) Install(stream, version, installed, progress);
    }

    private static string UpdateSource()
    {
        return File.Exists(FeedFile) ? File.ReadAllText(FeedFile).Trim() : DefaultFeed;
    }

    private static void RegisterUninstall()
    {
        using (RegistryKey key = Registry.CurrentUser.CreateSubKey(UninstallKey))
        {
            key.SetValue("DisplayName", "TIDRA");
            key.SetValue("DisplayVersion", VersionLabel(Latest()));
            key.SetValue("DisplayIcon", LauncherPath(VersionPath(Latest())));
            key.SetValue("UninstallString", "\"" + HubPath + "\" --uninstall");
            key.SetValue("NoModify", 1, RegistryValueKind.DWord);
            key.SetValue("NoRepair", 1, RegistryValueKind.DWord);
        }
    }

    private static bool BeginUninstall()
    {
        if (!File.Exists(HubPath)) return false;
        if (!ShowUninstallScreen(false)) return false;

        string worker = Path.Combine(Path.GetTempPath(), "AbyssSignal-Uninstall-" + Guid.NewGuid().ToString("N") + ".exe");
        File.Copy(Application.ExecutablePath, worker);
        using (Process current = Process.GetCurrentProcess())
            Process.Start(new ProcessStartInfo(worker, "--uninstall-worker " + current.Id) { UseShellExecute = false });
        return true;
    }

    private static int CompleteUninstall(string ownerId)
    {
        try
        {
            int pid;
            if (!int.TryParse(ownerId, out pid) || pid <= 0)
                throw new InvalidOperationException("Invalid uninstall request.");
            try
            {
                using (Process parent = Process.GetProcessById(pid))
                    if (!parent.WaitForExit(10000)) throw new IOException("Close TIDRA and try again.");
            }
            catch (ArgumentException)
            {
                // The setup process already exited.
            }

            using (Mutex gate = new Mutex(false, @"Local\TIDRA.DeepCurrent.Setup"))
            {
                bool acquired;
                try { acquired = gate.WaitOne(0); }
                catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) throw new IOException("Close TIDRA and try again.");
                try
                {
                    string versionsRoot = Path.GetFullPath(Versions) + Path.DirectorySeparatorChar;
                    foreach (string name in new[] { "AbyssSignal", "AbyssSignal.Server", "TIDRA", "TIDRA.Server" })
                    {
                        foreach (Process running in Process.GetProcessesByName(name))
                        {
                            using (running)
                            {
                                string path;
                                try { path = running.MainModule.FileName; }
                                catch (InvalidOperationException) { continue; }
                                if (path.StartsWith(versionsRoot, StringComparison.OrdinalIgnoreCase))
                                    throw new IOException("Close the TIDRA launcher and server before uninstalling.");
                            }
                        }
                    }
                    RemoveInstalledVersions();
                    RemoveShortcut("TIDRA.lnk", HubPath);
                    RemoveShortcut("Abyss Signal.lnk", HubPath);
                    RemoveShortcut("TIDRA - Deep Current.lnk", Path.Combine(root, "TIDRA Hub.exe"));
                    File.Delete(HubPath);
                    File.Delete(Path.Combine(root, "TIDRA Hub.exe"));
                    File.Delete(FeedFile);
                    File.Delete(RequiredFile);
                    Registry.CurrentUser.DeleteSubKeyTree(UninstallKey, false);
                }
                finally { gate.ReleaseMutex(); }
            }

            ShowUninstallScreen(true);
            return 0;
        }
        catch (Exception error)
        {
            MessageBox.Show("Uninstall could not finish. " + error.Message, "TIDRA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return 1;
        }
    }

    private static bool ShowUninstallScreen(bool complete)
    {
        using (var window = new Form
        {
            Text = "TIDRA | Uninstall", ClientSize = new Size(630, 305),
            BackColor = Color.FromArgb(8, 26, 39), ForeColor = Color.FromArgb(199, 232, 237),
            Font = new Font("Segoe UI", 10), AutoScaleMode = AutoScaleMode.Font,
            FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false,
            StartPosition = FormStartPosition.CenterScreen
        })
        {
            window.Controls.Add(new OceanPanel { Left = 0, Top = 0, Width = 178, Height = 305, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left });
            window.Controls.Add(new Label { Left = 208, Top = 26, Width = 390, Height = 26,
                Text = "TIDRA   /   INSTALLATION", ForeColor = Color.PaleTurquoise });
            window.Controls.Add(new Label { Left = 204, Top = 60, Width = 408, Height = 62,
                Text = complete ? "Uninstall complete" : "Uninstall TIDRA?",
                ForeColor = Color.White, Font = new Font("Segoe UI", 22, FontStyle.Bold) });
            window.Controls.Add(new Label { Left = 208, Top = 128, Width = 390, Height = 70,
                Text = complete ? "TIDRA was removed. Your worlds and Subnautica installation were kept."
                                : "This removes the launcher and its installed versions. Your worlds and Subnautica installation will be kept." });
            var cancel = new Button { Left = 208, Top = 232, Width = 174, Height = 40,
                Text = complete ? "CLOSE" : "KEEP TIDRA", DialogResult = DialogResult.Cancel };
            StyleAction(cancel, complete);
            window.Controls.Add(cancel);
            window.CancelButton = cancel;
            window.AcceptButton = cancel;
            if (!complete)
            {
                var remove = new Button { Left = 394, Top = 232, Width = 204, Height = 40,
                    Text = "UNINSTALL", DialogResult = DialogResult.OK };
                StyleAction(remove, true);
                window.Controls.Add(remove);
            }
            window.Shown += (_, __) => cancel.Focus();
            return window.ShowDialog() == DialogResult.OK;
        }
    }

    private static void RemoveInstalledVersions()
    {
        if (!Directory.Exists(Versions)) return;
        foreach (string directory in new[] { root, Versions })
            if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("The installation directory has been redirected.");

        var installed = Directory.EnumerateDirectories(Versions).Where(directory =>
        {
            int version;
            return int.TryParse(Path.GetFileName(directory), out version) &&
                string.Equals(VersionPath(version), directory, StringComparison.OrdinalIgnoreCase) && Installed(version);
        }).ToArray();
        foreach (string directory in installed)
            VerifyRemovalTree(directory);
        foreach (string directory in installed)
            Directory.Delete(directory, true);
        if (!Directory.EnumerateFileSystemEntries(Versions).Any()) Directory.Delete(Versions);
    }

    private static void VerifyRemovalTree(string directory)
    {
        if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) != 0)
            throw new IOException("The installation contains a redirected directory.");
        foreach (string child in Directory.EnumerateFileSystemEntries(directory))
        {
            FileAttributes attributes = File.GetAttributes(child);
            if ((attributes & FileAttributes.ReparsePoint) != 0)
                throw new IOException("The installation contains a redirected file.");
            if ((attributes & FileAttributes.Directory) != 0) VerifyRemovalTree(child);
        }
    }

    private static void RemoveShortcut(string name, string expectedTarget)
    {
        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), name);
        if (!File.Exists(path)) return;
        dynamic shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell", true));
        dynamic shortcut = shell.CreateShortcut(path);
        if (string.Equals((string)shortcut.TargetPath, expectedTarget, StringComparison.OrdinalIgnoreCase)) File.Delete(path);
    }

    private static void RegisterShortcut()
    {
        string source = Application.ExecutablePath;
        string installed = HubPath;
        if (!string.Equals(source, installed, StringComparison.OrdinalIgnoreCase)) File.Copy(source, installed, true);
        string shortcutFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), "TIDRA.lnk");
        Type shellType = Type.GetTypeFromProgID("WScript.Shell", true);
        dynamic shell = Activator.CreateInstance(shellType);
        dynamic link = shell.CreateShortcut(shortcutFile);
        link.TargetPath = installed;
        link.WorkingDirectory = root;
        link.Description = "Open TIDRA and check for updates";
        link.IconLocation = LauncherPath(VersionPath(Latest())) + ",0";
        link.Save();
        RegisterUninstall();
        RemoveShortcut("Abyss Signal.lnk", HubPath);
        string previousShortcut = Path.Combine(Path.GetDirectoryName(shortcutFile), "TIDRA - Deep Current.lnk");
        if (File.Exists(previousShortcut))
        {
            dynamic previousLink = shell.CreateShortcut(previousShortcut);
            if (string.Equals((string)previousLink.TargetPath, Path.Combine(root, "TIDRA Hub.exe"), StringComparison.OrdinalIgnoreCase))
                File.Delete(previousShortcut);
        }
    }

    private static void StyleAction(Button button, bool primary)
    {
        button.FlatStyle = FlatStyle.Flat;
        button.UseVisualStyleBackColor = false;
        button.BackColor = primary ? Color.FromArgb(255, 182, 96) : Color.FromArgb(18, 55, 70);
        button.ForeColor = primary ? Color.FromArgb(10, 27, 38) : Color.FromArgb(215, 247, 249);
        button.FlatAppearance.BorderColor = primary ? Color.FromArgb(255, 202, 132) : Color.FromArgb(73, 156, 168);
        button.Cursor = Cursors.Hand;
    }

    private sealed class OceanPanel : Panel
    {
        private readonly Bitmap artwork;

        public OceanPanel()
        {
            DoubleBuffered = true;
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("abyss.art"))
            {
                if (stream != null)
                    using (Image image = Image.FromStream(stream))
                        artwork = new Bitmap(image);
            }
        }

        protected override void OnPaint(PaintEventArgs args)
        {
            base.OnPaint(args);
            Graphics g = args.Graphics;
            g.Clear(Color.FromArgb(10, 38, 54));
            if (artwork != null)
            {
                int sourceWidth = artwork.Height * Width / Height;
                int left = (artwork.Width - sourceWidth) * 4 / 5;
                g.DrawImage(artwork, ClientRectangle, new Rectangle(left, 0, sourceWidth, artwork.Height), GraphicsUnit.Pixel);
            }
            using (var tint = new System.Drawing.Drawing2D.LinearGradientBrush(ClientRectangle,
                Color.FromArgb(185, 5, 22, 34), Color.FromArgb(42, 5, 22, 34), 90f))
                g.FillRectangle(tint, ClientRectangle);
            using (var line = new Pen(Color.FromArgb(89, 185, 194)))
            {
                g.DrawLine(line, Width - 1, 0, Width - 1, Height);
                g.DrawLine(line, 16, 60, 68, 60);
            }
            using (var brand = new Font("Segoe UI", 17, FontStyle.Bold))
            using (var small = new Font("Segoe UI", 8, FontStyle.Bold))
            {
                TextRenderer.DrawText(g, "TIDRA", brand, new Point(13, 18), Color.White);
                TextRenderer.DrawText(g, "EXPEDITION SYSTEMS", small, new Point(14, 68), Color.PaleTurquoise);
                TextRenderer.DrawText(g, "SUBNAUTICA LEGACY", small, new Point(14, Height - 35), Color.White);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && artwork != null) artwork.Dispose();
            base.Dispose(disposing);
        }
    }

    private sealed class SetupWizard : Form
    {
        private readonly Label heading = new Label { Left = 180, Top = 26, Width = 392, Height = 66 };
        private readonly Label body = new Label { Left = 180, Top = 103, Width = 392, Height = 90 };
        private readonly Label status = new Label { Left = 180, Top = 207, Width = 392, Height = 44 };
        private readonly ProgressBar progress = new ProgressBar { Left = 180, Top = 258, Width = 390, Height = 20, Visible = false };
        private readonly Button next = new Button { Text = "Install", Left = 381, Top = 13, Width = 88, Height = 28 };
        private readonly Button cancel = new Button { Text = "Cancel", Left = 476, Top = 13, Width = 88, Height = 28 };
        private readonly CheckBox launch = new CheckBox { Text = "Launch TIDRA", Checked = true, Left = 180, Top = 254, Width = 360 };
        private bool busy;

        public SetupWizard()
        {
            Text = "TIDRA Setup";
            ClientSize = new Size(624, 382);
            Font = new Font("Segoe UI", 9);
            BackColor = Color.FromArgb(8, 25, 38);
            ForeColor = Color.FromArgb(219, 245, 249);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            heading.Text = "Welcome to the TIDRA\r\nSetup Wizard";
            heading.Font = new Font("Segoe UI", 17, FontStyle.Bold);
            heading.ForeColor = Color.White;
            status.ForeColor = Color.FromArgb(133, 231, 229);
            body.Text = "Setup checks for the latest release, installs TIDRA and adds a Start menu shortcut.\r\n\r\nYour saved worlds stay in place.";
            status.Text = "Version: " + VersionLabel(Math.Max(EmbeddedVersion, Latest()));
            var side = new OceanPanel { Left = 0, Top = 0, Width = 156, Height = 327 };
            var footer = new Panel { Left = 0, Top = 327, Width = 624, Height = 55, BackColor = Color.FromArgb(12, 40, 54) };
            footer.Controls.Add(new Label { Left = 18, Top = 16, Width = 230, Height = 24,
                ForeColor = Color.FromArgb(133, 231, 229), Text = "TIDRA  /  SETUP" });
            next.Left = 414;
            cancel.Left = 512;
            StyleAction(next, true);
            StyleAction(cancel, false);
            footer.Controls.AddRange(new Control[] { next, cancel });
            Controls.AddRange(new Control[] { side, heading, body, status, progress, launch, footer });
            AcceptButton = next;
            CancelButton = cancel;
            cancel.Click += (_, __) => Close();
            FormClosing += (_, args) => args.Cancel = busy;
            next.Click += async (_, __) => await Advance();
        }

        private async Task Advance()
        {
            busy = true;
            next.Enabled = false;
            cancel.Enabled = false;
            launch.Visible = false;
            heading.Text = "Installing TIDRA";
            status.Top = 207;
            body.Text = "Please wait while Setup installs the application.";
            status.Text = "Preparing installation...";
            progress.Visible = true;
            progress.Value = 0;
            var report = new Progress<Tuple<int, string>>(item =>
            {
                progress.Style = item.Item1 < 0 ? ProgressBarStyle.Marquee : ProgressBarStyle.Continuous;
                if (item.Item1 >= 0) progress.Value = item.Item1;
                status.Text = item.Item2;
            });
            try
            {
                string source = UpdateSource();
                Action<int, string> reportProgress = (percent, message) =>
                    ((IProgress<Tuple<int, string>>)report).Report(Tuple.Create(percent, message));
                if (source.Length > 0)
                {
                    status.Text = "Checking for the latest version...";
                    progress.Style = ProgressBarStyle.Marquee;
                    try
                    {
                        SourceUri(source);
                        await Task.Run(() => TidraSetup.Update(source, reportProgress, EmbeddedVersion));
                        File.WriteAllText(FeedFile, source);
                    }
                    catch (Exception)
                    {
                        int fallback = Math.Max(EmbeddedVersion, Latest());
                        DialogResult choice = MessageBox.Show(this,
                            "The update service could not be reached or verified.\r\n\r\nContinue with " + VersionLabel(fallback) + "?",
                            "TIDRA Setup", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                        if (choice != DialogResult.Yes)
                        {
                            heading.Text = "Update check unsuccessful";
                            body.Text = "You can retry the check or close Setup.";
                            progress.Visible = false;
                            status.Text = "";
                            next.Text = "Retry";
                            cancel.Enabled = true;
                            return;
                        }
                    }
                }
                await Task.Run(() => InstallEmbedded(reportProgress));
                RegisterShortcut();
                if (launch.Checked) OpenFromShortcut();
                busy = false;
                Close();
            }
            catch (Exception error)
            {
                heading.Text = "Setup could not complete";
                body.Text = "You can retry the installation or close Setup.";
                status.Text = error.Message;
                progress.Visible = false;
                next.Text = "Retry";
                cancel.Enabled = true;
            }
            finally
            {
                busy = false;
                if (!IsDisposed)
                {
                    next.Enabled = true;
                    launch.Visible = true;
                }
            }
        }
    }

    private sealed class UpdateWindow : Form
    {
        private readonly Label status = new Label { Left = 218, Top = 210, Width = 402, Height = 48 };
        private readonly ProgressBar progressBar = new ProgressBar { Left = 218, Top = 263, Width = 402, Height = 10, Visible = false };
        private readonly Button exit = new Button { Left = 218, Top = 297, Width = 122, Height = 40, Text = "EXIT", DialogResult = DialogResult.Cancel };
        private readonly Button update = new Button { Left = 354, Top = 297, Width = 266, Height = 40, Text = "UPDATE AND OPEN" };
        private readonly int required;
        private readonly string source;
        private readonly Release available;
        private bool busy;

        public UpdateWindow(int required, string source, Release available)
        {
            this.required = required;
            this.source = source;
            this.available = available;
            Text = "TIDRA | Required Update";
            ClientSize = new Size(650, 362);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(8, 26, 39);
            ForeColor = Color.FromArgb(190, 222, 230);
            Font = new Font("Segoe UI", 10);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(new OceanPanel { Left = 0, Top = 0, Width = 188, Height = ClientSize.Height, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left });
            Controls.Add(new Label { Left = 218, Top = 29, Width = 402, Height = 23,
                Text = "TIDRA   /   SYSTEM UPDATE", ForeColor = Color.PaleTurquoise });
            Controls.Add(new Label { Left = 214, Top = 52, Width = 410, Height = 58,
                Text = "Update required", ForeColor = Color.White, Font = new Font("Segoe UI", 29, FontStyle.Bold) });
            Controls.Add(new Label { Left = 218, Top = 116, Width = 402, Height = 34,
                Text = VersionLabel(Latest()) + "    >    " + VersionLabel(required),
                TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.FromArgb(19, 60, 75), ForeColor = Color.PaleTurquoise });
            Controls.Add(new Label { Left = 218, Top = 163, Width = 402, Height = 42,
                Text = "Install the latest version to open TIDRA." });
            Controls.AddRange(new Control[] { status, progressBar, exit, update });
            status.Text = available != null && available.Version >= required
                ? "Update ready to download."
                : "Connect to the update service, then try again.";
            StyleAction(exit, false);
            StyleAction(update, true);
            AcceptButton = update;
            CancelButton = exit;
            update.Click += async (_, __) => await ApplyUpdate();
            FormClosing += (_, args) => args.Cancel = busy;
        }

        private async Task ApplyUpdate()
        {
            busy = true;
            update.Enabled = false;
            exit.Enabled = false;
            status.Text = "Preparing the update...";
            progressBar.Visible = true;
            var report = new Progress<Tuple<int, string>>(item =>
            {
                if (IsDisposed) return;
                progressBar.Style = item.Item1 < 0 ? ProgressBarStyle.Marquee : ProgressBarStyle.Continuous;
                if (item.Item1 >= 0) progressBar.Value = item.Item1;
                status.Text = item.Item2;
            });
            try
            {
                await Task.Run(() =>
                {
                    Release release = available != null && available.Version >= required ? available : ReadRelease(source);
                    if (release.Version < required) throw new IOException("The required version is not available.");
                    InstallRelease(release,
                        (percent, message) => ((IProgress<Tuple<int, string>>)report).Report(Tuple.Create(percent, message)));
                });
                busy = false;
                DialogResult = DialogResult.OK;
            }
            catch (Exception)
            {
                status.Text = "The update could not be installed. Check your connection and try again.";
                update.Text = "RETRY UPDATE";
            }
            finally
            {
                busy = false;
                if (!IsDisposed)
                {
                    progressBar.Visible = false;
                    update.Enabled = true;
                    exit.Enabled = true;
                }
            }
        }
    }
}
