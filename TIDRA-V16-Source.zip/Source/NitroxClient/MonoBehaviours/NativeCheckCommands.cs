using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using NitroxClient.Communication.Abstract;
using NitroxClient.GameLogic;
using NitroxClient.GameLogic.PlayerLogic;
using NitroxModel.Core;
using NitroxModel.DataStructures;
using NitroxUser = NitroxModel.Helper.NitroxUser;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    // Local test fixture. Commands are handled on Unity's main thread.
    public sealed class NativeCheckCommands : MonoBehaviour
    {
        public static string CommandDirectory => Path.Combine(NitroxUser.LauncherPath, "LocalCheckCommands");
        public static bool ExecutingConsoleCommand { get; private set; }
        private string inbox;
        private string reply;
        private float nextPoll;

        private void Awake()
        {
            IMultiplayerSession session = NitroxServiceLocator.LocateService<IMultiplayerSession>();
            string directory = CommandDirectory;
            if (Environment.GetEnvironmentVariable("DEEP_CURRENT_NATIVE_CHECKS") != "1" ||
                !IPAddress.TryParse(session.IpAddress, out IPAddress address) || !IPAddress.IsLoopback(address) ||
                !Directory.Exists(directory))
            {
                enabled = false;
                return;
            }

            LocalPlayer player = NitroxServiceLocator.LocateService<LocalPlayer>();
            string prefix = Path.Combine(directory, player.PlayerId.ToString(CultureInfo.InvariantCulture));
            inbox = prefix + ".cmd";
            reply = prefix + ".result";
            try
            {
                File.WriteAllText(reply, $"Ready: {player.PlayerName} (ID {player.PlayerId})");
            }
            catch (IOException error)
            {
                Debug.LogWarning("[TIDRA_CHECK] Could not initialize the mailbox: " + error.Message);
                enabled = false;
            }
        }

        private void Update()
        {
            if (Time.unscaledTime < nextPoll)
            {
                return;
            }
            nextPoll = Time.unscaledTime + 0.25f;
            if (!File.Exists(inbox) || !Player.main || !Inventory.main)
            {
                return;
            }

            try
            {
                string command = File.ReadAllText(inbox);
                File.Delete(inbox);
                string result = Execute(command);
                File.WriteAllText(reply, result);
                Debug.Log("[TIDRA_CHECK] " + result);
            }
            catch (Exception error)
            {
                string result = "[TIDRA_CHECK] " + error.Message;
                Debug.LogWarning(result);
                try
                {
                    File.WriteAllText(reply, result);
                }
                catch (IOException)
                {
                    // Keep the command failure in the game log if the reply file is unavailable.
                }
            }
        }

        private static string Execute(string command)
        {
            string[] args = command.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
            string verb = args.FirstOrDefault()?.ToLowerInvariant();
            Player player = Player.main;
            Vector3 position = player.transform.position;

            switch (verb)
            {
                case "status" when args.Length == 1:
                    return $"position={position} aim={player.camRoot.GetAimingTransform().forward} cinematic={player.cinematicModeActive} inputEnabled={AvatarInputHandler.main.enabled} camera={MainCamera.camera.transform.eulerAngles} root={player.camRoot.transform.eulerAngles} held={Inventory.main.GetHeldTool()}";
                case "look" when args.Length == 4:
                    Vector3 target = ReadPoint(args);
                    if ((target - MainCameraControl.main.transform.position).sqrMagnitude < 0.0001f)
                    {
                        throw new ArgumentException("Look target must differ from the camera position.");
                    }
                    MainCameraControl.main.LookAt(target);
                    return $"LookAt requested: {target}";
                case "view" when args.Length == 3:
                    Vector3 view = ReadPoint(new[] { "view", args[1], args[2], "0" });
                    if (Mathf.Abs(view.y) > 80f || player.GetVehicle() || player.isPiloting || player.cinematicModeActive)
                        throw new InvalidOperationException("View requires pitch within 80 degrees, outside vehicles and cinematics.");
                    player.transform.rotation = Quaternion.Euler(0f, view.x, 0f);
                    MainCameraControl.main.rotationX = 0f;
                    MainCameraControl.main.rotationY = -view.y;
                    return $"Native camera view requested: yaw={view.x} pitch={view.y}";
                case "move" when args.Length == 4:
                    Vector3 destination = ReadPoint(args);
                    if ((destination - position).sqrMagnitude > 25f * 25f || player.GetVehicle() || player.isPiloting || player.cinematicModeActive)
                    {
                        throw new InvalidOperationException("Move requires a nearby target, outside vehicles and cinematics.");
                    }
                    player.SetPosition(destination);
                    return $"SetPosition requested: {destination}";
                case "remote" when args.Length == 1:
                    return string.Join("\n", NitroxServiceLocator.LocateService<PlayerManager>().GetAll()
                        .Select(remote => DescribeRemote(remote)));
                case "cells" when args.Length == 1:
                    return NitroxServiceLocator.LocateService<GameLogic.Terrain>().DescribeSync();
                case "resynccells" when args.Length == 1:
                    NitroxServiceLocator.LocateService<GameLogic.Terrain>().ResyncVisibleCells();
                    return "Visible cell reconciliation scheduled.";
                case "equip" when args.Length == 2:
                    TechType toolType = (TechType)Enum.Parse(typeof(TechType), args[1], true);
                    InventoryItem held = Inventory.main.container.FirstOrDefault(item => item.item.GetTechType() == toolType);
                    if (held == null || !held.item.GetComponent<PlayerTool>())
                        throw new InvalidOperationException("The requested tool must already be in your inventory.");
                    // SelectImmediate toggles an already selected slot off. The
                    // fixture must draw the requested tool even on repeated calls.
                    Inventory.main.quickSlots.DeselectImmediate();
                    Inventory.main.quickSlots.Bind(0, held);
                    Inventory.main.quickSlots.SelectImmediate(0);
                    return $"Requested {toolType}; held={Inventory.main.GetHeldTool()}";
                case "console" when args.Length > 1:
                    ExecutingConsoleCommand = true;
                    try
                    {
                        DevConsole.SendConsoleCommand(command.Substring(command.IndexOf(' ') + 1).Trim());
                    }
                    finally
                    {
                        ExecutingConsoleCommand = false;
                    }
                    return "Submitted to the native game console.";
                case "scene" when args.Length == 1:
                    return string.Join("\n", UnityEngine.Object.FindObjectsOfType<Vehicle>()
                        .Select(vehicle => $"vehicle={vehicle.GetType().Name} position={vehicle.transform.position}"))
                        + "\n" + string.Join("\n", UnityEngine.Object.FindObjectsOfType<Constructable>()
                        .Where(piece => (piece.transform.position - position).sqrMagnitude < 2500f)
                        .Select(piece => $"build={piece.techType} position={piece.transform.position} complete={piece.constructed}"));
                case "near" when args.Length == 1:
                    return string.Join("\n", NitroxEntity.GetGameObjects()
                        .Where(pair => IsWorldPickup(pair.Value, position))
                        .OrderBy(pair => (pair.Value.transform.position - position).sqrMagnitude)
                        .Take(16)
                        .Select(pair => $"{pair.Key} {pair.Value.GetComponent<Pickupable>().GetTechType()} {pair.Value.transform.position}"));
                case "inventory" when args.Length == 1:
                    return string.Join("\n", Inventory.main.container
                        .Select(item => $"{item.item.GetTechType()} {(NitroxEntity.TryGetEntityFrom(item.item.gameObject, out NitroxEntity entity) ? entity.Id.ToString() : "no-id")}"));
                case "inspect" when args.Length == 2:
                    return ReportItem(new NitroxId(Guid.Parse(args[1])), position);
                case "entity" when args.Length == 2:
                    NitroxId observedId = new NitroxId(Guid.Parse(args[1]));
                    if (!NitroxEntity.TryGetObjectFrom(observedId, out GameObject observed) || !observed)
                        return $"id={observedId} exists=False";
                    SwimBehaviour swim = observed.GetComponent<SwimBehaviour>();
                    return $"id={observedId} exists=True position={observed.transform.position} remote={!!observed.GetComponent<RemotelyControlled>()} swimEnabled={(swim ? swim.enabled.ToString() : "none")}";
                case "pickup" when args.Length == 2:
                    NitroxId id = new NitroxId(Guid.Parse(args[1]));
                    if (!NitroxEntity.TryGetObjectFrom(id, out GameObject item) || !IsWorldPickup(item, position) ||
                        (item.transform.position - position).sqrMagnitude > 3f * 3f || player.cinematicModeActive)
                    {
                        throw new InvalidOperationException("Pickup requires a visible world item within three metres.");
                    }
                    bool accepted = Inventory.main.Pickup(item.GetComponent<Pickupable>(), false);
                    return $"nativePickup={accepted} {ReportItem(id, position)}";
                default:
                    throw new ArgumentException("Use status, look x y z, view yaw pitch, move x y z, remote, equip type, scene, near, inventory, inspect id, pickup id, or console command.");
            }
        }

        private static string DescribeRemote(RemotePlayer remote)
        {
            Animator animator = remote.PlayerModel.GetComponent<Animator>();
            return $"name={remote.PlayerName} position={remote.Body.transform.position} rotation={remote.Body.transform.eulerAngles} " +
                $"aim={remote.AnimationController.AimingRotation.eulerAngles} modelActive={remote.PlayerModel.activeInHierarchy} " +
                $"animatorEnabled={animator.enabled} speed={animator.speed} controller={(animator.runtimeAnimatorController ? animator.runtimeAnimatorController.name : "missing")} " +
                $"state={animator.GetCurrentAnimatorStateInfo(0).fullPathHash} time={animator.GetCurrentAnimatorStateInfo(0).normalizedTime} " +
                string.Join(" ", new[] { "move_speed", "move_speed_x", "move_speed_y", "move_speed_z", "view_pitch" }
                    .Select(parameter => $"{parameter}={animator.GetFloat(parameter).ToString("F3", CultureInfo.InvariantCulture)}")) + " " +
                $"inventory=[{string.Join(",", remote.Inventory.Select(item => $"{item.item.GetTechType()}:{NitroxEntity.GetId(item.item.gameObject)}:{item.item.gameObject.activeSelf}:{item.item.transform.IsChildOf(remote.ItemAttachPoint)}"))}] " +
                string.Join(" ", animator.parameters.Where(parameter => parameter.type == AnimatorControllerParameterType.Bool)
                    .Select(parameter => $"{parameter.name}={animator.GetBool(parameter.nameHash)}"));
        }

        private static string ReportItem(NitroxId id, Vector3 position)
        {
            bool inInventory = Inventory.main.container.Any(item =>
                NitroxEntity.TryGetEntityFrom(item.item.gameObject, out NitroxEntity entity) && entity.Id == id);
            bool exists = NitroxEntity.TryGetObjectFrom(id, out GameObject gameObject) && gameObject;
            bool inWorld = exists && IsWorldPickup(gameObject, position);
            return $"id={id} exists={exists} nearbyWorld={inWorld} localInventory={inInventory}";
        }

        private static bool IsWorldPickup(GameObject gameObject, Vector3 position)
        {
            return gameObject && gameObject.activeInHierarchy && gameObject.GetComponent<Pickupable>() &&
                   (gameObject.transform.position - position).sqrMagnitude <= 25f * 25f &&
                   !gameObject.transform.IsChildOf(Player.main.transform) &&
                   !gameObject.GetComponentInParent<RemotePlayerIdentifier>(true);
        }

        private static Vector3 ReadPoint(string[] args)
        {
            float ReadCoordinate(int index)
            {
                float value = float.Parse(args[index], CultureInfo.InvariantCulture);
                if (float.IsNaN(value) || float.IsInfinity(value) || Mathf.Abs(value) > 10000f)
                {
                    throw new ArgumentException("Coordinates must be finite and inside the test range.");
                }
                return value;
            }
            return new Vector3(ReadCoordinate(1), ReadCoordinate(2), ReadCoordinate(3));
        }
    }
}
