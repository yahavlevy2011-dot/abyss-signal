using System;
using System.Collections;
using System.Collections.Generic;
using NitroxClient.Communication.Abstract;
using NitroxClient.Communication.MultiplayerSession;
using NitroxClient.Map;
using NitroxClient.MonoBehaviours;
using NitroxModel.DataStructures.GameLogic;
using NitroxModel.Packets;
using NitroxModel_Subnautica.DataStructures;
using UnityEngine;
using WorldStreaming;

namespace NitroxClient.GameLogic
{
    public class Terrain
    {
        private readonly IMultiplayerSession multiplayerSession;
        private readonly IPacketSender packetSender;
        private readonly VisibleCells visibleCells;

        private bool cellsPendingSync;
        private int sentUpdates;
        private readonly HashSet<AbsoluteEntityCell> added = new();
        private readonly HashSet<AbsoluteEntityCell> removed = new();

        public Terrain(IMultiplayerSession multiplayerSession, IPacketSender packetSender, VisibleCells visibleCells)
        {
            this.multiplayerSession = multiplayerSession;
            this.packetSender = packetSender;
            this.visibleCells = visibleCells;
        }

        public void CellLoaded(Int3 batchId, Int3 cellId, int level)
        {
            AbsoluteEntityCell cell = new(batchId.ToDto(), cellId.ToDto(), level);
            if (visibleCells.Contains(cell)) return;
            visibleCells.Add(cell);
            if (!removed.Remove(cell)) added.Add(cell);
            ScheduleCellSync();
        }

        public void CellUnloaded(Int3 batchId, Int3 cellId, int level)
        {
            AbsoluteEntityCell cell = new(batchId.ToDto(), cellId.ToDto(), level);
            if (!visibleCells.Contains(cell)) return;
            visibleCells.Remove(cell);
            if (!added.Remove(cell)) removed.Add(cell);
            ScheduleCellSync();
        }

        private void ScheduleCellSync()
        {
            if (cellsPendingSync) return;
            cellsPendingSync = true;
            LargeWorldStreamer.main.StartCoroutine(SyncCells());
        }

        public void ResyncVisibleCells()
        {
            // Cells may have loaded before the initial player/world sync finished.
            // Reconcile the current snapshot once the player is fully initialized.
            added.UnionWith(visibleCells.GetSnapshot());
            added.ExceptWith(removed);
            ScheduleCellSync();
        }

        public string DescribeSync() => $"visible={visibleCells.GetSnapshot().Length} pendingAdded={added.Count} pendingRemoved={removed.Count} scheduled={cellsPendingSync} sentUpdates={sentUpdates} stage={multiplayerSession.CurrentState.CurrentStage}";

        private IEnumerator SyncCells()
        {
            try
            {
                var delay = new WaitForSecondsRealtime(0.12f);
                while (Multiplayer.Active)
                {
                    yield return delay;
                    if (added.Count == 0 && removed.Count == 0) yield break;
                    if (multiplayerSession.CurrentState.CurrentStage != MultiplayerSessionConnectionStage.SESSION_JOINED ||
                        !Multiplayer.Main.InitialSyncCompleted)
                        continue;

                    CellVisibilityChanged update = new(multiplayerSession.Reservation.PlayerId,
                        System.Linq.Enumerable.ToArray(added), System.Linq.Enumerable.ToArray(removed));
                    if (!packetSender.Send(update)) continue;
                    sentUpdates++;
                    added.Clear();
                    removed.Clear();
                    yield break;
                }
            }
            finally
            {
                cellsPendingSync = false;
            }
        }

        /// <summary>
        /// Forces world streamer's to load the terrain around the MainCamera and waits until it's done to unfreeze the player.
        /// </summary>
        public static IEnumerator WaitForWorldLoad()
        {
            // In WorldStreamer.CreateStreamers() three coroutines are created to constantly call UpdateCenter() on the streamers
            // We force these updates so that the world streamer gets busy instantly
            WorldStreamer streamerV2 = LargeWorldStreamer.main.streamerV2;
            // Sometimes, the world streamers can't find any cells to load and will throw an error, in which case we just skip the cell loading
            try
            {
                streamerV2.UpdateStreamingCenter(MainCamera.camera.transform.position);
                streamerV2.octreesStreamer.UpdateCenter(streamerV2.streamingCenter);
                streamerV2.lowDetailOctreesStreamer.UpdateCenter(streamerV2.streamingCenter);
                streamerV2.clipmapStreamer.UpdateCenter(streamerV2.streamingCenter);
            } catch (Exception) { }

            yield return new WaitUntil(() => LargeWorldStreamer.main.IsWorldSettled());
            Player.main.cinematicModeActive = false;
        }
    }
}
