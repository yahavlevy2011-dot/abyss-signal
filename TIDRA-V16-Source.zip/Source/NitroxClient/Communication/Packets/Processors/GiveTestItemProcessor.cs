using System;
using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxModel.Packets;
using UnityEngine;
using Object = UnityEngine.Object;

namespace NitroxClient.Communication.Packets.Processors
{
    internal class GiveTestItemProcessor : ClientPacketProcessor<GiveTestItem>
    {
        public override void Process(GiveTestItem packet)
        {
            if (packet.Count < 1 || packet.Count > GiveTestItem.MaxCount) return;
            if (!Inventory.main || !Player.main || Player.main.cinematicModeActive)
            {
                Log.InGame("GIVE: wait until your player is ready, then try again.");
                return;
            }

            if (!Enum.TryParse(packet.Item, true, out TechType techType) ||
                techType == TechType.None || !Enum.IsDefined(typeof(TechType), techType))
            {
                Log.InGame($"GIVE: unknown item '{packet.Item}'.");
                return;
            }

            GameObject prefab = CraftData.GetPrefabForTechType(techType, false);
            if (!prefab || !prefab.GetComponent<Pickupable>())
            {
                Log.InGame($"GIVE: {techType} cannot be placed in the inventory.");
                return;
            }

            int given = 0;
            while (given < packet.Count)
            {
                GameObject item = Object.Instantiate(prefab, Player.main.transform.position, Quaternion.identity);
                if (!Inventory.main.Pickup(item.GetComponent<Pickupable>(), false))
                {
                    Object.Destroy(item);
                    break;
                }

                given++;
            }

            Log.InGame($"GIVE: added {given}/{packet.Count} x {techType} to your inventory.");
        }
    }
}
