using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxModel.Packets;

namespace NitroxClient.Communication.Packets.Processors
{
    internal sealed class TidraOpeningStatusProcessor : ClientPacketProcessor<TidraOpeningStatus>
    {
        public override void Process(TidraOpeningStatus packet) => MultiplayerOpening.Receive(packet);
    }
}
