from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
import json

root = Path(__file__).resolve().parent
publish = root / 'abyss75-publish'
source = Path('C:/Users/Yahav/Documents/Codex/2026-10-31/referenced-chatgpt-conversation-this-is-an-2/outputs/DeepCurrent-Legacy')
output = publish / 'TIDRA-V1.0.11.zip'
with ZipFile(publish / 'TIDRA-V1.0.10.zip') as previous:
    files = {name: previous.read(name) for name in previous.namelist() if not name.endswith('/')}
files.pop('MANIFEST_SHA256.json', None)
overlays = {
    'AbyssSignal.exe': root / 'tidra-launcher-next' / 'NitroxLauncher.exe',
    'lib/NitroxClient.dll': source / 'NitroxClient/bin/Debug/NitroxClient.dll',
    'lib/NitroxModel.dll': source / 'NitroxModel/bin/Debug/NitroxModel.dll',
    'lib/NitroxModel-Subnautica.dll': source / 'NitroxModel-Subnautica/bin/Debug/NitroxModel-Subnautica.dll',
    'lib/NitroxPatcher.dll': source / 'NitroxPatcher/bin/Debug/NitroxPatcher.dll',
    'lib/NitroxServer.dll': source / 'NitroxServer/bin/Debug/NitroxServer.dll',
}
for name, path in overlays.items():
    files[name] = path.read_bytes()
notes = (
    'TIDRA 1.0.11 | Subnautica Legacy 68598\n'
    'Friends Network: fixed scrolling, saved local friend contacts and profile name, API-key status, '
    'approved-device list and network removal. Storage: accept state messages with a stable path or '
    'position when a native ID is unavailable. Fixed a misleading friend-save success message.\n'
    'Code build passed. Two-computer gameplay is pending player testing.\n'
).encode()
files['RELEASE_NOTES.txt'] = notes
files['READ_FIRST_HE.txt'] = (
    'TIDRA 1.0.11 | Subnautica Legacy 68598\n'
    'מסך Friends Network עודכן: גלילה, רשימת חברים מקומית, חיווי למפתח API והסרת מכשירים מהרשת. '
    'סנכרון מצב ה-Storage תוקן בשרת כאשר חסר מזהה פנימי. נדרשת בדיקה במשחק עם שני שחקנים.\n'
).encode()
files['MANIFEST_SHA256.json'] = json.dumps(
    {name: sha256(data).hexdigest() for name, data in sorted(files.items())}, indent=2
).encode()
with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
    for name, data in files.items(): archive.writestr(name, data)
with ZipFile(output) as archive:
    assert archive.testzip() is None
    manifest = json.loads(archive.read('MANIFEST_SHA256.json'))
    assert all(sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())

with ZipFile(publish / 'TIDRA-V1.0.10-Source.zip') as previous:
    sources = {name: previous.read(name) for name in previous.namelist() if not name.endswith('/')}
for file in source.rglob('*'):
    if not file.is_file() or file.suffix.lower() not in {'.cs', '.csproj', '.xaml', '.props', '.targets'}:
        continue
    relative = file.relative_to(source)
    if any(part.lower() in {'bin', 'obj', '.git', 'packages', 'generated_files'} for part in relative.parts):
        continue
    sources['Source/' + relative.as_posix()] = file.read_bytes()
sources['Source/Installer/package-v1011.py'] = Path(__file__).read_bytes()
sources['RELEASE_NOTES.txt'] = notes
source_output = publish / 'TIDRA-V1.0.11-Source.zip'
with ZipFile(source_output, 'w', ZIP_DEFLATED) as archive:
    for name, data in sorted(sources.items()): archive.writestr(name, data)
with ZipFile(source_output) as archive: assert archive.testzip() is None

digest = sha256(output.read_bytes()).hexdigest()
(publish / 'catalog.txt').write_text(f'121\n{output.name}\n{digest}\n', encoding='ascii')
(publish / 'index.html').write_text(
    '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    '<title>TIDRA V1.0.11</title><style>body{background:#071c29;color:#e5f8ff;font:18px system-ui;max-width:760px;margin:10vh auto;padding:24px}a{color:#6ce6ff}</style>'
    '<h1>TIDRA V1.0.11</h1><p>Subnautica Legacy 68598 · build 121</p>'
    '<p><a href="TIDRA-Setup.exe">Download Windows installer</a></p>'
    '<p>Friends Network usability and storage-state sync update. Two-computer gameplay needs player testing.</p>'
    '<p>No game files included. Original multiplayer engine attribution and license are preserved.</p>'
    '<p><a href="TIDRA-V1.0.11-Source.zip">Source and license</a> · <a href="catalog.txt">Update catalog</a></p></html>',
    encoding='utf-8')
print(output)
print('sha256=' + digest)
