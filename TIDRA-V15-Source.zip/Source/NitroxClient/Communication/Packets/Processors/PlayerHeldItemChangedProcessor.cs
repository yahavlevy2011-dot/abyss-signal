using System;
using System.Reflection;
using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.GameLogic;
using NitroxClient.MonoBehaviours;
using NitroxModel.DataStructures.Util;
using NitroxModel.Helper;
using NitroxModel.Packets;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors
{
    public class PlayerHeldItemChangedProcessor : ClientPacketProcessor<PlayerHeldItemChanged>
    {
        private readonly FieldInfo inventoryItemFromPickupable = typeof(Pickupable).GetField("inventoryItem", BindingFlags.NonPublic | BindingFlags.Instance);
        private readonly MethodInfo setHandIK = typeof(PlayerTool).GetMethod("SetHandIKTargetsEnabled", BindingFlags.NonPublic | BindingFlags.Instance);

        private int defaultLayer;
        private int viewModelLayer;
        private readonly PlayerManager playerManager;

        public PlayerHeldItemChangedProcessor(PlayerManager playerManager)
        {
            this.playerManager = playerManager;

            if (NitroxEnvironment.IsNormal)
            {
                SetupLayers();
            }
        }

        private void SetupLayers()
        {
            defaultLayer = LayerMask.NameToLayer("Default");
            // A remote tool is a world object. The first-person-only layer can
            // be excluded by the observer's world camera or render over UI.
            viewModelLayer = defaultLayer;
        }

        public override void Process(PlayerHeldItemChanged packet)
        {
            Optional<RemotePlayer> opPlayer = playerManager.Find(packet.PlayerId);
            if (!opPlayer.HasValue) return;

            Optional<GameObject> opItem = NitroxEntity.GetObjectFrom(packet.ItemId);
            if (!opItem.HasValue) return;

            Pickupable pickupable = opItem.Value.GetComponent<Pickupable>();
            if (!pickupable) return;

            InventoryItem inventoryItem = (InventoryItem)inventoryItemFromPickupable.GetValue(pickupable);
            if (inventoryItem == null) return;

            ItemsContainer inventory = opPlayer.Value.Inventory;
            PlayerTool tool = opItem.Value.GetComponent<PlayerTool>();

            // Copied from QuickSlots
            switch (packet.Type)
            {
                case PlayerHeldItemChanged.ChangeType.DRAW_AS_TOOL:
                    if (!tool || (opItem.Value.activeSelf && opItem.Value.transform.IsChildOf(opPlayer.Value.ItemAttachPoint))) break;
                    opItem.Value.transform.SetParent(opPlayer.Value.ItemAttachPoint, false);
                    ModelPlug.PlugIntoSocket(tool, opPlayer.Value.ItemAttachPoint);
                    Utils.SetLayerRecursively(opItem.Value, viewModelLayer);
                    foreach (Animator componentsInChild in tool.GetComponentsInChildren<Animator>())
                    {
                        componentsInChild.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                    }
                    if (tool.mainCollider)
                    {
                        tool.mainCollider.enabled = false;
                    }
                    tool.GetComponent<Rigidbody>().isKinematic = true;
                    opItem.Value.SetActive(true);
                    setHandIK?.Invoke(tool, new object[] { true });
                    SafeAnimator.SetBool(opPlayer.Value.ArmsController.GetComponent<Animator>(), "holding_tool", true);
                    SafeAnimator.SetBool(opPlayer.Value.ArmsController.GetComponent<Animator>(), $"holding_{tool.animToolName}", true);
                    opPlayer.Value.AnimationController["using_tool_first"] = packet.IsFirstTime != null;

                    if (opItem.Value.TryGetComponent(out FPModel fpModelDraw)) //FPModel needs to be updated 
                    {
                        fpModelDraw.OnEquip(null, null);
                    }
                    break;

                case PlayerHeldItemChanged.ChangeType.HOLSTER_AS_TOOL:
                    Validate.IsTrue(tool);
                    opItem.Value.SetActive(false);
                    Utils.SetLayerRecursively(opItem.Value, defaultLayer);
                    if (tool.mainCollider)
                    {
                        tool.mainCollider.enabled = true;
                    }
                    tool.GetComponent<Rigidbody>().isKinematic = false;
                    inventoryItem.item.Reparent(inventory.tr);
                    foreach (Animator componentsInChild in tool.GetComponentsInChildren<Animator>())
                    {
                        componentsInChild.cullingMode = AnimatorCullingMode.CullUpdateTransforms;
                    }
                    SafeAnimator.SetBool(opPlayer.Value.ArmsController.GetComponent<Animator>(), $"holding_{tool.animToolName}", false);
                    setHandIK?.Invoke(tool, new object[] { false });
                    SafeAnimator.SetBool(opPlayer.Value.ArmsController.GetComponent<Animator>(), "holding_tool", false);
                    opPlayer.Value.AnimationController["using_tool_first"] = false;

                    if (opItem.Value.TryGetComponent(out FPModel fpModelHolster)) //FPModel needs to be updated 
                    {
                        fpModelHolster.OnUnequip(null, null);
                    }

                    break;

                case PlayerHeldItemChanged.ChangeType.DRAW_AS_ITEM:
                    inventoryItem.item.Reparent(opPlayer.Value.ItemAttachPoint);
                    inventoryItem.item.SetVisible(true);
                    Utils.SetLayerRecursively(inventoryItem.item.gameObject, viewModelLayer);
                    break;

                case PlayerHeldItemChanged.ChangeType.HOLSTER_AS_ITEM:
                    inventoryItem.item.Reparent(inventory.tr);
                    inventoryItem.item.SetVisible(false);
                    Utils.SetLayerRecursively(inventoryItem.item.gameObject, defaultLayer);
                    break;

                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}
