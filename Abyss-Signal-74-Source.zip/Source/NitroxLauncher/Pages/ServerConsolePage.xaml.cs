using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using NitroxLauncher.Models;
using NitroxLauncher.Models.Events;

namespace NitroxLauncher.Pages
{
    public partial class ServerConsolePage : PageBase
    {
        private readonly List<string> commandLinesHistory = new();
        private readonly StringBuilder serverOutput = new("");
        private string commandInputText;
        private int commandHistoryIndex;

        public string ServerStatus => LauncherLogic.Server.StatusLabel + "  /  " +
            (LauncherLogic.Server.ActiveWorld ?? "Default world");
        public string Roster { get; private set; } = "Waiting for server…";

        public string ServerOutput
        {
            get => serverOutput.ToString();
            set
            {
                serverOutput.AppendLine(value);
                if (serverOutput.Length > 48000)
                {
                    serverOutput.Remove(0, serverOutput.Length - 40000);
                }
                OnPropertyChanged();
                Dispatcher?.BeginInvoke(new Action(() => ConsoleWindowScrollView.ScrollToEnd()));
            }
        }

        public string CommandInputText
        {
            get => commandInputText;
            set
            {
                commandInputText = value;
                OnPropertyChanged();
            }
        }

        public int CommandHistoryIndex
        {
            get => commandHistoryIndex;
            set
            {
                commandHistoryIndex = Math.Min(Math.Max(value, 0), commandLinesHistory.Count);
                if (commandHistoryIndex >= commandLinesHistory.Count)
                {
                    // Out of bounds index means command history is disabled
                    CommandInputText = string.Empty;
                }
                else
                {
                    CommandInputText = commandLinesHistory[commandHistoryIndex];
                    // Move cursor at the end of the text
                    CommandInput.SelectionStart = CommandInputText.Length;
                    CommandInput.SelectionLength = 0;
                }

                OnPropertyChanged();
            }
        }

        public ServerConsolePage()
        {
            InitializeComponent();

            LauncherLogic.Server.ServerStarted += ServerStarted;
            LauncherLogic.Server.ServerDataReceived += ServerDataReceived;

            DispatcherTimer telemetry = new() { Interval = TimeSpan.FromSeconds(3) };
            telemetry.Tick += (_, _) =>
            {
                OnPropertyChanged(nameof(ServerStatus));
                if (LauncherLogic.Server.IsListening)
                {
                    LauncherLogic.Server.SendServerCommand("list --tidra-roster");
                }
            };
            Unloaded += (_, _) => telemetry.Stop();

            Loaded += (sender, args) =>
            {
                telemetry.Start();
                Roster = LauncherLogic.Server.PlayerRoster ?? "Waiting for server…";
                OnPropertyChanged(nameof(Roster));
                OnPropertyChanged(nameof(ServerStatus));
                if (LauncherLogic.Server.IsListening)
                {
                    LauncherLogic.Server.SendServerCommand("list --tidra-roster");
                }
                CommandInput.Focus();
            };
        }

        private void ServerStarted(object sender, ServerStartEventArgs e)
        {
            serverOutput.Clear();
            Roster = "Waiting for server…";
            OnPropertyChanged(nameof(Roster));
            OnPropertyChanged(nameof(ServerOutput));
        }

        private void ServerDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (e.Data == null)
            {
                return;
            }

            Dispatcher.BeginInvoke(new Action(() =>
            {
                const string prefix = "TIDRA_ROSTER ";
                if (e.Data.StartsWith(prefix, StringComparison.Ordinal))
                {
                    Roster = LauncherLogic.Server.PlayerRoster;
                    OnPropertyChanged(nameof(Roster));
                    return;
                }

                ServerOutput = e.Data;
            }));
        }

        private void SendCommandInputToServer()
        {
            if (string.IsNullOrWhiteSpace(CommandInputText))
            {
                return;
            }

            ServerOutput = "> " + CommandInputText;
            LauncherLogic.Server.SendServerCommand(CommandInputText);

            // Deduplication of command history
            if (!string.IsNullOrWhiteSpace(CommandInputText) && CommandInputText != commandLinesHistory.LastOrDefault())
            {
                commandLinesHistory.Add(CommandInputText);
            }

            HideCommandHistory();
        }

        private void HideCommandHistory()
        {
            CommandHistoryIndex = commandLinesHistory.Count;
        }

        private void CommandButton_OnClick(object sender, RoutedEventArgs e)
        {
            SendCommandInputToServer();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            ServerOutput = "> save";
            LauncherLogic.Server.SendServerCommand("save");
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            // Suggest referencing NitroxServer.ConsoleCommands.ExitCommand.name, but the class is internal
            LauncherLogic.Server.SendServerCommand("stop");
            commandLinesHistory.Add("stop");
            HideCommandHistory();
        }

        private void CommandLine_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;

            switch (e.Key)
            {
                case Key.Enter:
                    SendCommandInputToServer();
                    break;

                case Key.Escape:
                    HideCommandHistory();
                    break;

                case Key.Up:
                    CommandHistoryIndex--;
                    break;

                case Key.Down:
                    CommandHistoryIndex++;
                    break;

                default:
                    e.Handled = false;
                    break;
            }
        }
    }
}



