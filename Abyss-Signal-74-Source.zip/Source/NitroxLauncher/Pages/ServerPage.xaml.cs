using System;
using System.Windows;
using System.IO;
using System.Linq;
using NitroxModel.Helper;
using NitroxLauncher.Models;

namespace NitroxLauncher.Pages
{
    public partial class ServerPage : PageBase
    {
        public string StartButtonSubtitle => "LEGACY 68598";
        private const string DefaultWorldLabel = "Use server default";
        private bool IsServerExternal => LauncherLogic.Config.IsExternalServer;

        public ServerPage()
        {
            InitializeComponent();

            WorldSelector.Items.Add(DefaultWorldLabel);
            WorldSelector.SelectedIndex = 0;
            System.Windows.Threading.DispatcherTimer timer = new() { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (_, _) => RefreshStatus();
            Loaded += (_, _) =>
            {
                RefreshWorlds();
                RefreshStatus();
                timer.Start();
            };
            Unloaded += (_, _) => timer.Stop();

            RBIsDocked.IsChecked = !IsServerExternal;
            RBIsExternal.IsChecked = IsServerExternal;
        }

        private void RefreshStatus()
        {
            HostStatus.Text = LauncherLogic.Server.StatusLabel + "  /  FOUR PLAYER CAPACITY";
            StartServerButton.IsEnabled = !LauncherLogic.Server.IsServerRunning;
        }

        private void RefreshWorlds()
        {
            string root = Path.GetDirectoryName(DeepCurrentLegacy.WorldDirectory("world"));
            if (!Directory.Exists(root))
            {
                return;
            }

            foreach (string name in Directory.EnumerateDirectories(root).Select(Path.GetFileName).OrderBy(name => name))
            {
                if (!WorldSelector.Items.Contains(name))
                {
                    WorldSelector.Items.Add(name);
                }
            }
        }

        private void StartServer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = WorldSelector.Text.Trim();
                bool useDefault = name == DefaultWorldLabel;
                if (!useDefault &&
                    (string.IsNullOrEmpty(name) || name == "." || name == ".." ||
                     name.EndsWith(".") || name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0))
                {
                    MessageBox.Show("Enter a world name without slashes or special characters.", "World name");
                    return;
                }

                HostError.Text = string.Empty;
                bool existingSave = false;
                if (!useDefault)
                {
                    string worldPath = DeepCurrentLegacy.WorldDirectory(name);
                    existingSave = new[] { "WorldData.json", "WorldData.nitrox", "Version.json", "Version.nitrox" }
                        .Any(file => File.Exists(Path.Combine(worldPath, file)));
                }

                LauncherLogic.Server.StartServer(RBIsExternal.IsChecked == true, useDefault ? null : name,
                    requireExistingWorld: existingSave);
                RefreshStatus();
            }
            catch (Exception ex)
            {
                HostError.Text = ex.Message;
            }
        }

        private void RBServer_Clicked(object sender, RoutedEventArgs e)
        {
            LauncherLogic.Config.IsExternalServer = RBIsExternal.IsChecked ?? true;
        }
    }
}


