using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using NitroxLauncher.Models;
using NitroxModel;
using NitroxModel.Discovery;
using NitroxModel.Helper;

namespace NitroxLauncher.Pages
{
    public partial class LaunchGamePage : PageBase
    {
        public string PlatformToolTip => GamePlatform.GetAttribute<DescriptionAttribute>()?.Description ?? "Unknown";
        public Platform GamePlatform => NitroxUser.GamePlatform?.Platform ?? Platform.NONE;
        public string Version => $"{LauncherLogic.ReleasePhase} {LauncherLogic.Version}";

        public string GameStatus => DeepCurrentLegacy.IsSupportedDirectory(LauncherLogic.Config.SubnauticaPath)
            ? "GAME · LEGACY READY" : "GAME · CHECK SETTINGS";
        public string ServerStatus => LauncherLogic.Server.StatusLabel;
        private readonly DispatcherTimer statusTimer = new() { Interval = TimeSpan.FromSeconds(1) };
        private string scene = "deep_current";
        private Storyboard Motion => (Storyboard)FindResource("DeepCurrentMotion");
        private bool videoPaused;

        public LaunchGamePage()
        {
            InitializeComponent();
            statusTimer.Tick += (_, _) => OnPropertyChanged(nameof(ServerStatus));

            Loaded += (s, e) =>
            {
                LauncherLogic.Config.PropertyChanged += LogicPropertyChanged;
                LogicPropertyChanged(null, null);


                ShowDiveScene(scene);
                OnPropertyChanged(nameof(ServerStatus));
                statusTimer.Start();
            };

            Unloaded += (s, e) =>
            {
                LauncherLogic.Config.PropertyChanged -= LogicPropertyChanged;
                statusTimer.Stop();
                Motion.Remove(this);
                DiveVideo.Close();
                DiveVideo.Source = null;
            };
        }

        private static string MediaPath(string name, string extension) =>
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "DiveMedia", name + extension);

        private static ImageSource LoadPoster(string name)
        {
            string path = MediaPath(name, ".jpg");
            return File.Exists(path) ? new BitmapImage(new Uri(path)) : null;
        }

        private void ShowDiveScene(string name)
        {
            scene = name;
            DiveVideo.Close();
            DiveVideo.Visibility = Visibility.Hidden;
            DivePoster.Source = LoadPoster(name);
            Motion.Remove(this);
            Particles.Visibility = name == "deep_current" ? Visibility.Visible : Visibility.Collapsed;
            if (name == "deep_current")
            {
                DiveVideo.Source = null;
                VideoToggle.IsEnabled = true;
                VideoToggle.Content = videoPaused ? "Resume motion" : "Pause motion";
                Motion.Begin(this, true);
                if (videoPaused)
                {
                    Motion.Pause(this);
                }
                return;
            }

            string videoPath = MediaPath(name, ".mp4");
            VideoToggle.IsEnabled = File.Exists(videoPath);
            VideoToggle.Content = videoPaused ? "Play video" : "Pause video";
            DiveVideo.Source = VideoToggle.IsEnabled ? new Uri(videoPath) : null;
            if (VideoToggle.IsEnabled && !videoPaused)
            {
                DiveVideo.Play();
            }
        }

        private void DiveScene_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button { Tag: string name })
            {
                ShowDiveScene(name);
            }
        }

        private void VideoToggle_Click(object sender, RoutedEventArgs e)
        {
            videoPaused = !videoPaused;
            if (scene == "deep_current")
            {
                VideoToggle.Content = videoPaused ? "Resume motion" : "Pause motion";
                if (videoPaused)
                {
                    Motion.Pause(this);
                }
                else
                {
                    Motion.Resume(this);
                }
                return;
            }
            VideoToggle.Content = videoPaused ? "Play video" : "Pause video";
            if (videoPaused)
            {
                DiveVideo.Pause();
            }
            else
            {
                DiveVideo.Play();
            }
        }

        private void DiveVideo_Opened(object sender, RoutedEventArgs e) => DiveVideo.Visibility = Visibility.Visible;

        private void DiveVideo_Ended(object sender, RoutedEventArgs e)
        {
            DiveVideo.Position = TimeSpan.Zero;
            if (!videoPaused)
            {
                DiveVideo.Play();
            }
        }

        private void DiveVideo_Failed(object sender, ExceptionRoutedEventArgs e)
        {
            DiveVideo.Visibility = Visibility.Hidden;
            VideoToggle.IsEnabled = false;
            VideoToggle.Content = "Still image";
        }

        private async void SinglePlayerButton_Click(object sender, RoutedEventArgs e)
        {
            SetLaunching(PlaySingleplayer);

            try
            {
                await LauncherLogic.Instance.StartSingleplayerAsync();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error while starting in singleplayer mode", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                SetLaunching(null);
            }
        }

        private async void MultiplayerButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            switch (GamePlatform)
            {
                case Platform.MICROSOFT:
                    button.Background = new SolidColorBrush(Colors.Red);
                    MessageBox.Show("Sorry, due to technical problems Nitrox isn't yet compatible with Subnautica on Microsoft Store\n\nWe're doing our best to give you the opportunity to be able to play again soon.", "Error while starting in multiplayer mode", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;

                case Platform.STEAM:

                    if (!NitroxUser.IsNewestSubnautica.GetValueOrDefault(false))
                    {
                        break;
                    }

                    button.Background = new SolidColorBrush(Colors.Red);
                    MessageBox.Show(
                        "Due to Subnautica's recent update \"Living Large\", Nitrox is currently not compatible.\nHowever you can still use older version of Subnautica in order to play Nitrox. You can do so by following these steps.\n\nENSURE NITROX AND SUBNAUTICA ARE CLOSED BEFORE PROCEEDING!\n\nChanging Subnautica to Legacy Build on STEAM:\n\n1. Right click Subnautica in Steam\n2. Click Properties\n3. Click Betas\n4. Select Legacy - Public legacy builds\n5. Close it out and let Steam download and install the Legacy version of Subnautica\n6. Run Subnautica through Steam (It will say \"Subnautica [legacy]\" in your library if you did it right)\n7. Launch Subnautica through Nitrox to play.",
                        "Nitrox requires your attention",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information
                    );
                    return;

                case Platform.EPIC:

                    if (!NitroxUser.IsNewestSubnautica.GetValueOrDefault(false))
                    {
                        break;
                    }

                    button.Background = new SolidColorBrush(Colors.Red);
                    MessageBox.Show("Due to Subnautica's recent update \"Living Large\", Epic Games is currently not compatible with Nitrox.\n\nWe are working on an update we do not have an estimate as to when it is done.", "Error while starting in multiplayer mode", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
            }

            SetLaunching(PlayMultiplayer);

            try
            {
                await LauncherLogic.Instance.StartMultiplayerAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error while starting in multiplayer mode", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                SetLaunching(null);
            }
        }

        private void SetLaunching(Button active)
        {
            PlayMultiplayer.IsEnabled = active == null;
            PlaySingleplayer.IsEnabled = active == null;
            PlayMultiplayer.Content = active == PlayMultiplayer ? "LAUNCHING…" : "PLAY MULTIPLAYER";
            PlaySingleplayer.Content = active == PlaySingleplayer ? "LAUNCHING…" : "SINGLEPLAYER";
        }

        private void LogicPropertyChanged(object sender, PropertyChangedEventArgs args)
        {
            OnPropertyChanged(nameof(GameStatus));
            OnPropertyChanged(nameof(GamePlatform));
            OnPropertyChanged(nameof(PlatformToolTip));
        }
    }
}


