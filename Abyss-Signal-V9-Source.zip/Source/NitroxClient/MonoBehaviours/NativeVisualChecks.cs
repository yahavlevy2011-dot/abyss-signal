using System;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    // Opt-in, bounded native integration fixture. Inactive in ordinary games.
    public class NativeVisualChecks : MonoBehaviour
    {
        private static float sprayUntil;
        public static GameObject SerializationFaultTarget { get; private set; }
        public const string SerializationFailureMessage = "DC explicit serialization failure injection";
        public static bool SprayInputActive =>
            Environment.GetEnvironmentVariable("DEEP_CURRENT_NATIVE_CHECKS") == "1" &&
            Time.unscaledTime < sprayUntil;

        public void Awake()
        {
            if (Environment.GetEnvironmentVariable("DEEP_CURRENT_NATIVE_CHECKS") != "1")
            { enabled = false; return; }
            DevConsole.RegisterConsoleCommand(this, "dc_spraycheck", false, false);
            DevConsole.RegisterConsoleCommand(this, "dc_slotssetup", false, false);
            DevConsole.RegisterConsoleCommand(this, "dc_slotsreport", false, false);
            DevConsole.RegisterConsoleCommand(this, "dc_slotsclear", false, false);
            DevConsole.RegisterConsoleCommand(this, "dc_serializationcheck", false, false);
        }

        public void OnConsoleCommand_dc_spraycheck(NotificationCenter.Notification data)
        {
            if (Environment.GetEnvironmentVariable("DEEP_CURRENT_NATIVE_CHECKS") != "1") return;
            var tool = Player.main.GetComponentInChildren<FireExtinguisher>();
            if (!tool) { Debug.LogError("[DC_CHECK] FAIL: draw a native extinguisher first."); return; }
            sprayUntil = Time.unscaledTime + 8f;
            Debug.Log("[DC_CHECK] Native extinguisher input held for 8 seconds; starting fuel=" + tool.fuel);
        }

        public void OnConsoleCommand_dc_slotssetup(NotificationCenter.Notification data)
        {
            if (Environment.GetEnvironmentVariable("DEEP_CURRENT_NATIVE_CHECKS") != "1") return;
            InventoryItem extinguisher = null;
            var flares = new System.Collections.Generic.List<InventoryItem>();
            foreach (InventoryItem item in Inventory.main.container)
            {
                if (item.item.GetTechType() == TechType.FireExtinguisher) extinguisher = item;
                if (item.item.GetTechType() == TechType.Flare) flares.Add(item);
            }
            if (extinguisher == null || flares.Count < 2)
            { Debug.LogError("[DC_CHECK] FAIL: quick-slot fixture needs an existing extinguisher and two existing flares; nothing changed."); return; }
            var slots = Inventory.main.quickSlots;
            for (int i = 0; i < slots.binding.Length; i++) slots.Unbind(i);
            slots.Bind(0, extinguisher); slots.Bind(1, flares[0]); slots.Bind(2, flares[1]);

            Debug.Log("[DC_CHECK] Quick-slot fixture configured existing owned items, with two distinct flares and two empty slots.");
            OnConsoleCommand_dc_slotsreport(data);
        }

        public void OnConsoleCommand_dc_slotsreport(NotificationCenter.Notification data)
        {
            if (Environment.GetEnvironmentVariable("DEEP_CURRENT_NATIVE_CHECKS") != "1") return;
            string actual = string.Join("|", NitroxClient.GameLogic.StableQuickSlots.Capture(Inventory.main.quickSlots));
            string expected = Environment.GetEnvironmentVariable("DEEP_CURRENT_EXPECTED_SLOTS");
            Debug.Log("[DC_CHECK] Quick-slot identities=" + actual);
            if (!string.IsNullOrEmpty(expected))
                Debug.Log("[DC_CHECK] Quick-slot reload " + (actual == expected ? "PASS" : "FAIL"));
            Debug.Log("[DC_CHECK] Cinematic movement lock=" + Player.main.cinematicModeActive);
        }

        public void OnConsoleCommand_dc_slotsclear(NotificationCenter.Notification data)
        {
            if (Environment.GetEnvironmentVariable("DEEP_CURRENT_NATIVE_CHECKS") != "1") return;
            Inventory.main.quickSlots.Unbind(0);
            Debug.Log("[DC_CHECK] Direct native Unbind(0) executed.");
            OnConsoleCommand_dc_slotsreport(data);
        }

        public void OnConsoleCommand_dc_serializationcheck(NotificationCenter.Notification data)
        {
            if (Environment.GetEnvironmentVariable("DEEP_CURRENT_NATIVE_CHECKS") != "1") return;
            var parent = new GameObject("DC_SerializationProbeParent");
            var child = new GameObject("DC_SerializationProbeChild");
            child.transform.SetParent(parent.transform, false);
            var identifier = parent.AddComponent<PrefabIdentifier>();
            identifier.Id = Guid.NewGuid().ToString();
            var idField = typeof(UniqueIdentifier).GetField("id", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            string original = (string)idField.GetValue(identifier);
            bool passed = true;
            try
            {
                foreach (string expected in new[] { original, NitroxClient.GameLogic.Helper.SerializationHelper.ID_IGNORE_KEY })
                {
                    idField.SetValue(identifier, expected);
                    SerializationFaultTarget = child;
                    bool injected = false;
                    try { NitroxClient.GameLogic.Helper.SerializationHelper.GetBytesWithoutParent(child); }
                    catch (InvalidOperationException ex) when (ex.Message == SerializationFailureMessage) { injected = true; }
                    passed &= injected && (string)idField.GetValue(identifier) == expected;
                }
                Debug.Log("[DC_CHECK] Parent identifier exception and nested-state restoration " + (passed ? "PASS" : "FAIL"));
            }
            finally
            {
                SerializationFaultTarget = null;
                idField.SetValue(identifier, original);
                UnityEngine.Object.DestroyImmediate(parent);
            }
        }

        public void OnDestroy() { sprayUntil = 0; SerializationFaultTarget = null; }
    }
}

