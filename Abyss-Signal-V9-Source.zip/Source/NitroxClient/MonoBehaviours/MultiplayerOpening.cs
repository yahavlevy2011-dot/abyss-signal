using System.Collections;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    public static class MultiplayerOpening
    {
        public static EscapePod PlayingPod { get; private set; }
        private static uGUI_SceneIntro intro;

        public static IEnumerator Play()
        {
            EscapePod pod = EscapePod.main;
            uGUI ui = uGUI.main;
            if (!Multiplayer.Active || !Player.main || !pod || Player.main.currentEscapePod != pod ||
                !pod.introCinematic || !pod.escapePodCinematicControl || !ui || !ui.intro || ui.intro.showing)
            {
                yield break;
            }

            intro = ui.intro;
            PlayingPod = pod;
            pod.startedIntroCinematic = false;
            try
            {
                intro.Play();
                float deadline = Time.realtimeSinceStartup + 180f;
                while (Multiplayer.Active && intro && intro.showing && Time.realtimeSinceStartup < deadline)
                {
                    yield return null;
                }
            }
            finally
            {
                Stop();
            }
        }

        public static void Stop()
        {
            if (!PlayingPod && !intro)
            {
                return;
            }

            try
            {
                if (intro && intro.showing)
                {
                    intro.Stop(true);
                }
            }
            finally
            {
                PlayingPod = null;
                intro = null;
            }
        }
    }
}
