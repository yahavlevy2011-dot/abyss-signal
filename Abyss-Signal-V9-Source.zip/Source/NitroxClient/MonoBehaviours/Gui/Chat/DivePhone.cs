using System;
using System.IO;
using UnityEngine;

namespace NitroxClient.MonoBehaviours.Gui.Chat;

public class DivePhone : MonoBehaviour
{
    private Camera lens;
    private RenderTexture preview;

    public static void Toggle(GameObject player)
    {
        DivePhone phone = player.GetComponent<DivePhone>();
        if (phone) phone.enabled = !phone.enabled;
        else player.AddComponent<DivePhone>();
    }

    private void LateUpdate()
    {
        Camera source = MainCamera.camera;
        if (!source)
        {
            return;
        }

        if (!lens)
        {
            GameObject cameraObject = new("Abyss Signal camera");
            cameraObject.transform.SetParent(transform);
            lens = cameraObject.AddComponent<Camera>();
            lens.clearFlags = source.clearFlags;
            lens.backgroundColor = source.backgroundColor;
            lens.cullingMask = source.cullingMask;
            lens.farClipPlane = source.farClipPlane;
            lens.nearClipPlane = 0.05f;
            lens.fieldOfView = 52f;
            preview = new RenderTexture(960, 540, 16);
            lens.targetTexture = preview;
        }

        Transform view = source.transform;
        lens.transform.SetPositionAndRotation(view.position + view.forward * 2.2f + view.up * .1f,
            Quaternion.LookRotation(-view.forward, view.up));
        if (AvatarInputHandler.main.IsEnabled() && UnityEngine.Input.GetKeyDown(KeyCode.F9))
        {
            Capture();
        }
    }

    private void OnGUI()
    {
        if (!preview)
        {
            return;
        }

        float width = Mathf.Min(300, Screen.width / 3f);
        float height = width * 9 / 16;
        Rect rect = new(Screen.width - width - 24, Screen.height - height - 90, width, height);
        GUI.DrawTexture(rect, preview);
        GUI.Box(new Rect(rect.x, rect.yMax, width, 28), "ABYSS SIGNAL CAMERA   ·   F9 photo   ·   !phone close");
    }

    private void Capture()
    {
        RenderTexture previous = RenderTexture.active;
        Texture2D photo = null;
        try
        {
            RenderTexture.active = preview;
            photo = new Texture2D(preview.width, preview.height, TextureFormat.RGB24, false);
            photo.ReadPixels(new Rect(0, 0, preview.width, preview.height), 0, 0);
            photo.Apply();
            string directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Abyss Signal", "Captures");
            Directory.CreateDirectory(directory);
            string path = Path.Combine(directory, $"AbyssSignal_{DateTime.UtcNow:yyyyMMdd_HHmmss_fff}.png");
            File.WriteAllBytes(path, photo.EncodeToPNG());
            Log.InGame("Photo saved to Pictures / Abyss Signal / Captures");
        }
        catch (Exception error)
        {
            Log.Error(error, "Could not save Abyss Signal photo");
            Log.InGame("Could not save photo.");
        }
        finally
        {
            RenderTexture.active = previous;
            Destroy(photo);
        }
    }

    private void OnDisable()
    {
        if (lens)
        {
            lens.enabled = false;
            lens.targetTexture = null;
            Destroy(lens.gameObject);
            lens = null;
        }
        if (preview)
        {
            preview.Release();
            Destroy(preview);
            preview = null;
        }
    }
}


