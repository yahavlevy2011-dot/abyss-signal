using System.Linq;
using NitroxClient.Communication.Abstract;
using NitroxClient.GameLogic;
using NitroxModel.Core;
using UnityEngine;

namespace NitroxClient.MonoBehaviours;

public class PlayerRosterHud : MonoBehaviour
{
    private PlayerManager players;
    private IMultiplayerSession session;
    private GUIStyle rowStyle;

    private void Awake()
    {
        players = NitroxServiceLocator.LocateService<PlayerManager>();
        session = NitroxServiceLocator.LocateService<IMultiplayerSession>();
    }

    private void OnGUI()
    {
        if (Event.current.type != EventType.Repaint || !Multiplayer.Active ||
            !Multiplayer.Main.InitialSyncCompleted || !Player.main)
        {
            return;
        }

        rowStyle ??= new GUIStyle(GUI.skin.label)
        {
            richText = false,
            clipping = TextClipping.Clip,
            alignment = TextAnchor.MiddleLeft
        };

        RemotePlayer[] remotePlayers = players.GetAll().OrderBy(player => player.PlayerId).ToArray();
        const float width = 210f;
        const float rowHeight = 22f;
        float x = Screen.width - width - 20f;
        const float y = 20f;
        GUI.Box(new Rect(x, y, width, rowHeight * (remotePlayers.Length + 2) + 8f), GUIContent.none);
        Rect row = new(x + 10f, y + 4f, width - 20f, rowHeight);
        GUI.Label(row, $"PLAYERS  {remotePlayers.Length + 1}/{session.SessionPolicy.MaxConnections}", rowStyle);
        row.y += rowHeight;
        GUI.Label(row, $"{session.AuthenticationContext.Username} (YOU)", rowStyle);
        foreach (RemotePlayer player in remotePlayers)
        {
            row.y += rowHeight;
            GUI.Label(row, player.PlayerName, rowStyle);
        }
    }
}
