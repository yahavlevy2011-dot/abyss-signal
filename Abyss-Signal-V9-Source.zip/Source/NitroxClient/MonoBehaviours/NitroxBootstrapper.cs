﻿using System;
using NitroxModel.Helper;
using NitroxClient.MonoBehaviours.Discord;
using NitroxClient.MonoBehaviours.Gui.MainMenu;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    public class NitroxBootstrapper : MonoBehaviour
    {
        internal static NitroxBootstrapper Instance;
        private int targetFrameRate;

        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            Instance = this;
            gameObject.AddComponent<SceneCleanerPreserve>();
            gameObject.AddComponent<MainMenuMods>();
            gameObject.AddComponent<DiscordClient>();

            int configuredRate;
            if (!int.TryParse(Environment.GetEnvironmentVariable(DeepCurrentLegacy.FrameRateVariable), out configuredRate) ||
                (configuredRate != 0 && (configuredRate < 30 || configuredRate > 240)))
            {
                configuredRate = DeepCurrentLegacy.DefaultFrameRate;
            }
            targetFrameRate = configuredRate == 0 ? -1 : configuredRate;
            ApplyFramePacing();
            Log.Info($"TIDRA frame limit: {configuredRate} (0 = unlimited), background rendering enabled.");

            CreateDebugger();
        }

        private void LateUpdate()
        {
            ApplyFramePacing();
        }

        private void ApplyFramePacing()
        {
            if (!Application.runInBackground) Application.runInBackground = true;
            // On desktop Unity ignores targetFrameRate when v-sync is enabled.
            if (QualitySettings.vSyncCount != 0) QualitySettings.vSyncCount = 0;
            if (Application.targetFrameRate != targetFrameRate) Application.targetFrameRate = targetFrameRate;
        }

        private void CreateDebugger()
        {
            GameObject debugger = new GameObject();
            debugger.name = "Debug manager";
            debugger.AddComponent<NitroxDebugManager>();
            debugger.transform.SetParent(transform);
        }
    }
}
