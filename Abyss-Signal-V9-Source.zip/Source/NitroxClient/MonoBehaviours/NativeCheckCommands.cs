using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using NitroxClient.Communication.Abstract;
using NitroxClient.GameLogic;
using NitroxClient.GameLogic.PlayerLogic;
using NitroxModel.Core;
using NitroxModel.DataStructures;
using NitroxUser = NitroxModel.Helper.NitroxUser;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    // Local test fixture. Commands are handled on Unity's main thread.
    public sealed class NativeCheckCommands : MonoBehaviour
    {
        public static string CommandDirectory => Path.Combine(NitroxUser.LauncherPath, "LocalCheckCommands");
        private string inbox;
        private string reply;
        private float nextPoll;

        private void Awake()
        {
            IMultiplayerSession session = NitroxServiceLocator.LocateService<IMultiplayerSession>();
            string directory = CommandDirectory;
            if (!IPAddress.TryParse(session.IpAddress, out IPAddress address) || !IPAddress.IsLoopback(address) ||
                !Directory.Exists(directory))
            {
                enabled = false;
                return;
            }

            LocalPlayer player = NitroxServiceLocator.LocateService<LocalPlayer>();
            string prefix = Path.Combine(directory, player.PlayerId.ToString(CultureInfo.InvariantCulture));
            inbox = prefix + ".cmd";
            reply = prefix + ".result";
            try
            {
                File.WriteAllText(reply, $"Ready: {player.PlayerName} (ID {player.PlayerId})");
            }
            catch (IOException error)
            {
                Debug.LogWarning("[TIDRA_CHECK] Could not initialize the mailbox: " + error.Message);
                enabled = false;
            }
        }

        private void Update()
        {
            if (Time.unscaledTime < nextPoll)
            {
                return;
            }
            nextPoll = Time.unscaledTime + 0.25f;
            if (!File.Exists(inbox) || !Player.main || !Inventory.main)
            {
                return;
            }

            try
            {
                string command = File.ReadAllText(inbox);
                File.Delete(inbox);
                string result = Execute(command);
                File.WriteAllText(reply, result);
                Debug.Log("[TIDRA_CHECK] " + result);
            }
            catch (Exception error)
            {
                string result = "[TIDRA_CHECK] " + error.Message;
                Debug.LogWarning(result);
                try
                {
                    File.WriteAllText(reply, result);
                }
                catch (IOException)
                {
                    // Keep the command failure in the game log if the reply file is unavailable.
                }
            }
        }

        private static string Execute(string command)
        {
            string[] args = command.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
            string verb = args.FirstOrDefault()?.ToLowerInvariant();
            Player player = Player.main;
            Vector3 position = player.transform.position;

            switch (verb)
            {
                case "status" when args.Length == 1:
                    return $"position={position} aim={player.camRoot.GetAimingTransform().forward} cinematic={player.cinematicModeActive}";
                case "look" when args.Length == 4:
                    Vector3 target = ReadPoint(args);
                    if ((target - MainCameraControl.main.transform.position).sqrMagnitude < 0.0001f)
                    {
                        throw new ArgumentException("Look target must differ from the camera position.");
                    }
                    MainCameraControl.main.LookAt(target);
                    return $"LookAt requested: {target}";
                case "move" when args.Length == 4:
                    Vector3 destination = ReadPoint(args);
                    if ((destination - position).sqrMagnitude > 25f * 25f || player.GetVehicle() || player.isPiloting || player.cinematicModeActive)
                    {
                        throw new InvalidOperationException("Move requires a nearby target, outside vehicles and cinematics.");
                    }
                    player.SetPosition(destination);
                    return $"SetPosition requested: {destination}";
                case "near" when args.Length == 1:
                    return string.Join("\n", NitroxEntity.GetGameObjects()
                        .Where(pair => IsWorldPickup(pair.Value, position))
                        .OrderBy(pair => (pair.Value.transform.position - position).sqrMagnitude)
                        .Take(16)
                        .Select(pair => $"{pair.Key} {pair.Value.GetComponent<Pickupable>().GetTechType()} {pair.Value.transform.position}"));
                case "inventory" when args.Length == 1:
                    return string.Join("\n", Inventory.main.container
                        .Select(item => $"{item.item.GetTechType()} {(NitroxEntity.TryGetEntityFrom(item.item.gameObject, out NitroxEntity entity) ? entity.Id.ToString() : "no-id")}"));
                case "inspect" when args.Length == 2:
                    return ReportItem(new NitroxId(Guid.Parse(args[1])), position);
                case "pickup" when args.Length == 2:
                    NitroxId id = new NitroxId(Guid.Parse(args[1]));
                    if (!NitroxEntity.TryGetObjectFrom(id, out GameObject item) || !IsWorldPickup(item, position) ||
                        (item.transform.position - position).sqrMagnitude > 3f * 3f || player.cinematicModeActive)
                    {
                        throw new InvalidOperationException("Pickup requires a visible world item within three metres.");
                    }
                    bool accepted = Inventory.main.Pickup(item.GetComponent<Pickupable>(), false);
                    return $"nativePickup={accepted} {ReportItem(id, position)}";
                default:
                    throw new ArgumentException("Use status, look x y z, move x y z, near, inventory, inspect id, or pickup id.");
            }
        }

        private static string ReportItem(NitroxId id, Vector3 position)
        {
            bool inInventory = Inventory.main.container.Any(item =>
                NitroxEntity.TryGetEntityFrom(item.item.gameObject, out NitroxEntity entity) && entity.Id == id);
            bool exists = NitroxEntity.TryGetObjectFrom(id, out GameObject gameObject) && gameObject;
            bool inWorld = exists && IsWorldPickup(gameObject, position);
            return $"id={id} exists={exists} nearbyWorld={inWorld} localInventory={inInventory}";
        }

        private static bool IsWorldPickup(GameObject gameObject, Vector3 position)
        {
            return gameObject && gameObject.activeInHierarchy && gameObject.GetComponent<Pickupable>() &&
                   (gameObject.transform.position - position).sqrMagnitude <= 25f * 25f &&
                   !gameObject.transform.IsChildOf(Player.main.transform) &&
                   !gameObject.GetComponentInParent<RemotePlayerIdentifier>(true);
        }

        private static Vector3 ReadPoint(string[] args)
        {
            float ReadCoordinate(int index)
            {
                float value = float.Parse(args[index], CultureInfo.InvariantCulture);
                if (float.IsNaN(value) || float.IsInfinity(value) || Mathf.Abs(value) > 10000f)
                {
                    throw new ArgumentException("Coordinates must be finite and inside the test range.");
                }
                return value;
            }
            return new Vector3(ReadCoordinate(1), ReadCoordinate(2), ReadCoordinate(3));
        }
    }
}
