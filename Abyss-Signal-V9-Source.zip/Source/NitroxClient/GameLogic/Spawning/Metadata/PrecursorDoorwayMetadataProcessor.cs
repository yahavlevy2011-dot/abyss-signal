using NitroxClient.Communication.Abstract;
using NitroxModel.Core;
using NitroxModel.DataStructures.GameLogic.Entities.Metadata;
using NitroxModel.Packets;
using UnityEngine;

namespace NitroxClient.GameLogic.Spawning.Metadata
{
    public class PrecursorDoorwayMetadataProcessor : GenericEntityMetadataProcessor<PrecursorDoorwayMetadata>
    {
        public override void ProcessMetadata(GameObject gameObject, PrecursorDoorwayMetadata metadata)
        {
            if (!gameObject.TryGetComponent(out PrecursorDoorway doorway))
            {
                return;
            }

            IPacketSender sender = NitroxServiceLocator.LocateService<IPacketSender>();
            using (sender.Suppress<EntityMetadataUpdate>())
            {
                doorway.ToggleDoor(metadata.IsOpen);
            }
        }
    }
}

