using System;
using System.IO;
using System.Reflection;
using NitroxModel.Helper;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace NitroxClient.GameLogic
{
    // Deep Current: native scratch slots are not authoritative Nitrox worlds.
    // Keep each session/process separate from singleplayer and other clients.
    internal static class NativeSessionStorage
    {
        private static UserStoragePC storage;
        private static FieldInfo saveField,cacheField;
        private static string previousSave,previousCache;
        private static bool watching;
        internal static void Enter()
        {
            if(storage!=null)throw new InvalidOperationException("A private native session is already active.");
            var selected=PlatformUtils.main.GetUserStorage() as UserStoragePC;
            if(selected==null)throw new InvalidOperationException("Native PC storage is unavailable.");
            var saved=typeof(UserStoragePC).GetField("savePath",BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public);
            var cache=typeof(PlatformUtils).GetField("_temporaryCachePath",BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public);
            if(saved==null||cache==null)throw new MissingFieldException("Native session storage fields changed.");
            string oldSave=saved.GetValue(selected) as string,oldCache=cache.GetValue(null) as string;
            if(string.IsNullOrWhiteSpace(oldSave))throw new IOException("Original native save root could not be verified.");
            string session=Path.Combine(DeepCurrentLegacy.DataDirectory,"native-sessions",Guid.NewGuid().ToString("N"));
            string saves=Path.Combine(session,"SavedGames"),scratch=Path.Combine(session,"Cache");
            Directory.CreateDirectory(saves);Directory.CreateDirectory(scratch);
            if((File.GetAttributes(session)&FileAttributes.ReparsePoint)!=0)throw new IOException("Native session directory cannot be a directory link.");
            try
            {
                saved.SetValue(selected,saves);cache.SetValue(null,scratch);
                if((string)saved.GetValue(selected)!=saves||PlatformUtils.temporaryCachePath!=scratch)
                    throw new IOException("Native session isolation was not applied.");
            }
            catch{saved.SetValue(selected,oldSave);cache.SetValue(null,oldCache);throw;}
            storage=selected;saveField=saved;cacheField=cache;previousSave=oldSave;previousCache=oldCache;
            if(!watching){SceneManager.sceneLoaded+=OnSceneLoaded;watching=true;}
            Debug.Log("[DeepCurrent] Isolated native multiplayer slots and cache: "+session);
        }
        private static void OnSceneLoaded(Scene scene,LoadSceneMode mode)
        {
            // Leave the private paths active throughout Cleaner. Restore before
            // the main menu starts enumerating the original singleplayer slots.
            if(scene.name=="XMenu")Restore();
        }
        internal static void Restore()
        {
            if(storage==null)return;
            if(SaveLoadManager.main!=null&&SaveLoadManager.main.isSaving)
                throw new InvalidOperationException("Cannot restore native storage during an active save.");
            saveField.SetValue(storage,previousSave);cacheField.SetValue(null,previousCache);
            storage=null;saveField=cacheField=null;previousSave=previousCache=null;
            Debug.Log("[DeepCurrent] Original singleplayer storage restored.");
        }
    }
}
