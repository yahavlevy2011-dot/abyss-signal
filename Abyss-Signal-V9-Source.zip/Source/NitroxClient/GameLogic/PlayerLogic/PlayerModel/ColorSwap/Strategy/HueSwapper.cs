using NitroxClient.GameLogic.PlayerLogic.PlayerModel.Abstract;
using UnityEngine;

namespace NitroxClient.GameLogic.PlayerLogic.PlayerModel.ColorSwap.Strategy
{
    public class HueSwapper : IColorSwapStrategy
    {
        private readonly float replacementHue;
        private readonly float replacementSaturation;
        private readonly float replacementBrightness;

        public HueSwapper(Color playerColor)
        {
            Color.RGBToHSV(playerColor, out replacementHue, out replacementSaturation, out replacementBrightness);
        }

        public Color SwapColor(Color originalColor)
        {
            float currentAlpha = originalColor.a;
            Color.RGBToHSV(originalColor, out _, out float currentSaturation, out float currentBrightness);

            return Color
                .HSVToRGB(replacementHue, currentSaturation * replacementSaturation, currentBrightness * replacementBrightness)
                .WithAlpha(currentAlpha);
        }
    }
}
