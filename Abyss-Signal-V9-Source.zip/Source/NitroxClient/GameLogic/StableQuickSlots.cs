using System;
using NitroxClient.Communication.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxModel.Core;
using NitroxModel.Helper;
using NitroxModel.Packets;
using UnityEngine;
namespace NitroxClient.GameLogic
{
    // Native UniqueIdentifier values can be remapped when item trees are loaded.
    // Persist the item's network identity; resolve only against our own inventory.
    public static class StableQuickSlots
    {
        private static string[] pending;
        public static void Clear() => pending = null;
        public static void Queue(string[] keys) => pending = (string[])keys.Clone();
        public static string[] Capture(QuickSlots slots)
        {
            string[] keys = slots.SaveBinding();
            for (int i = 0; i < keys.Length; i++)
            {
                InventoryItem item = slots.binding[i];
                if (item != null && item.item && item.item.TryGetComponent(out NitroxEntity entity) && entity.Id != null)
                    keys[i] = QuickSlotKey.Encode(entity.Id);
                else keys[i] = keys[i] ?? "null";
            }
            return keys;
        }
        public static void ApplyPending()
        {
            string[] keys = pending;
            pending = null;
            if (keys == null || !Inventory.main) return;
            QuickSlots slots = Inventory.main.quickSlots;
            var sender = NitroxServiceLocator.LocateService<IPacketSender>();
            using (sender.Suppress<PlayerQuickSlotsBindingChanged>())
            {
                // Retain migration support for old saves using native identifiers.
                string[] legacy = new string[slots.binding.Length];
                for (int i = 0; i < legacy.Length; i++)
                    legacy[i] = i < keys.Length && keys[i] != null && !keys[i].StartsWith(QuickSlotKey.Prefix, StringComparison.Ordinal) ? keys[i] : "null";
                slots.RestoreBinding(legacy);
                for (int i = 0; i < Math.Min(keys.Length, slots.binding.Length); i++)
                {
                    if (!QuickSlotKey.TryDecode(keys[i], out var id)) continue;
                    foreach (InventoryItem candidate in Inventory.main.container)
                    {
                        if (candidate.item && candidate.item.TryGetComponent(out NitroxEntity entity) && entity.Id == id)
                        { slots.Bind(i, candidate); break; }
                    }
                }
                Inventory.main.serializedQuickSlots = slots.SaveBinding();
            }
            NitroxServiceLocator.LocateService<LocalPlayer>().BroadcastQuickSlotsBindingChanged(new System.Collections.Generic.List<string>(Capture(slots)));
            Debug.Log("[DeepCurrent] Applied saved quick-slot identities after initial synchronization.");
        }
    }
}
