using System.Collections.Generic;
using UnityEngine;

namespace NitroxClient.GameLogic
{
    // Render-only replica: never clone the native PDA behaviours or its UI,
    // which read Player.main and would control the observing player's menus.
    internal static class RemotePdaVisual
    {
        internal static GameObject Create(Transform remoteBody)
        {
            PDA pda = Player.main.GetPDA();
            if (!pda) return null;
            Transform localBody = NitroxModel.Core.NitroxServiceLocator.LocateService<LocalPlayer>().Body.transform;
            var path = new List<string>();
            Transform ancestor = pda.transform.parent;
            while (ancestor && ancestor != localBody)
            {
                path.Insert(0, ancestor.name);
                ancestor = ancestor.parent;
            }
            Transform anchor = ancestor == localBody
                ? (path.Count == 0 ? remoteBody : remoteBody.Find(string.Join("/", path))) : null;
            if (!anchor)
            {
                Debug.LogWarning("[DeepCurrent] Remote PDA anchor unavailable; visual not created.");
                return null;
            }
            GameObject visual = CopyGeometry(pda.transform, anchor);
            if (visual) visual.SetActive(false);
            return visual;
        }

        private static GameObject CopyGeometry(Transform source, Transform parent)
        {
            if (source.GetComponent<Canvas>()) return null;
            var node = new GameObject("DC_PDA_" + source.name);
            node.transform.SetParent(parent, false);
            node.transform.localPosition = source.localPosition;
            node.transform.localRotation = source.localRotation;
            node.transform.localScale = source.localScale;
            MeshFilter mesh = source.GetComponent<MeshFilter>();
            MeshRenderer renderer = source.GetComponent<MeshRenderer>();
            if (mesh && renderer)
            {
                node.AddComponent<MeshFilter>().sharedMesh = mesh.sharedMesh;
                var copy = node.AddComponent<MeshRenderer>();
                copy.sharedMaterials = renderer.sharedMaterials;
                copy.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            }
            foreach (Transform child in source) CopyGeometry(child, node.transform);
            return node;
        }
    }
}
