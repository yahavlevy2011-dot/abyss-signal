using NitroxClient.Communication.Abstract;
using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxClient.GameLogic;
using NitroxModel_Subnautica.DataStructures.GameLogic;
using NitroxModel_Subnautica.Packets;
using UnityEngine;
using NitroxClient.Unity.Helper;

namespace NitroxClient.Communication.Packets.Processors
{
    public class RocketPreflightCompleteProcessor : ClientPacketProcessor<RocketPreflightComplete>
    {
        private readonly IPacketSender packetSender;

        private readonly Vehicles vehicles;

        public RocketPreflightCompleteProcessor(IPacketSender packetSender, Vehicles vehicles)
        {
            this.packetSender = packetSender;
            this.vehicles = vehicles;
        }

        public override void Process(RocketPreflightComplete packet)
        {
            var model = vehicles.TryGetVehicle<NeptuneRocketModel>(packet.Id);
            if (model.HasValue) model.Value.TryCompleteSharedCheck(packet.FlightCheck);

            if (!NitroxEntity.TryGetObjectFrom(packet.Id, out GameObject gameObjectRocket) || !gameObjectRocket)
            {
                return;
            }

            switch (packet.FlightCheck)
            {
                //Preflights inside the cockpit, we do want to ignore TimeCapsule for now
                case PreflightCheck.LifeSupport:
                case PreflightCheck.PrimaryComputer:

                    CockpitSwitch[] cockpitSwitches = gameObjectRocket.GetComponentsInChildren<CockpitSwitch>(true);

                    foreach (CockpitSwitch cockpitSwitch in cockpitSwitches)
                    {
                        if (!cockpitSwitch.completed && cockpitSwitch.preflightCheck == packet.FlightCheck)
                        {
                            cockpitSwitch.animator.SetBool("Completed", true);
                            cockpitSwitch.completed = true;

                            CompletePreflightCheck(cockpitSwitch.preflightCheckSwitch);

                            if (cockpitSwitch.collision)
                            {
                                cockpitSwitch.collision.SetActive(false);
                            }
                        }
                    }

                    break;

                //CommunicationsArray, Hydraulics, AuxiliaryPowerUnit
                default:

                    ThrowSwitch[] throwSwitches = gameObjectRocket.GetComponentsInChildren<ThrowSwitch>(true);

                    foreach (ThrowSwitch throwSwitch in throwSwitches)
                    {
                        if (!throwSwitch.completed && throwSwitch.preflightCheck == packet.FlightCheck)
                        {
                            throwSwitch.animator.AliveOrNull()?.SetTrigger("Throw");
                            throwSwitch.completed = true;
                            CompletePreflightCheck(throwSwitch.preflightCheckSwitch);
                            throwSwitch.cinematicTrigger.showIconOnHandHover = false;
                            throwSwitch.triggerCollider.enabled = false;
                            throwSwitch.lamp.GetComponent<SkinnedMeshRenderer>().material = throwSwitch.completeMat;
                        }
                    }

                    break;
            }

        }

        private void CompletePreflightCheck(PreflightCheckSwitch preflightCheckSwitch)
        {
            using (packetSender.Suppress<RocketPreflightComplete>())
            {
                preflightCheckSwitch.preflightCheckManager.AliveOrNull()?.CompletePreflightCheck(preflightCheckSwitch.preflightCheck);   
            }
        }
    }
}

