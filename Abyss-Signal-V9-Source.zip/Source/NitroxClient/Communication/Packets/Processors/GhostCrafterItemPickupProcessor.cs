﻿using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxClient.Unity.Helper;
using NitroxModel.Packets;
using NitroxModel_Subnautica.DataStructures;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors
{
    public class GhostCrafterItemPickupProcessor : ClientPacketProcessor<GhostCrafterItemPickup>
    {
        public override void Process(GhostCrafterItemPickup packet)
        {
            GameObject gameObject = NitroxEntity.RequireObjectFrom(packet.GhostCrafterId);
            CrafterLogic crafterLogic = gameObject.RequireComponentInChildren<CrafterLogic>(true);

            TechType techType = packet.TechType.ToUnity();
            if (techType == TechType.None)
            {
                crafterLogic.Reset();
                return;
            }

            if (crafterLogic.craftingTechType == techType && packet.Remaining >= 0)
            {
                crafterLogic.linkedIndex = packet.LinkedIndex;
                crafterLogic.numCrafted = packet.Remaining;
            }
        }
    }
}
