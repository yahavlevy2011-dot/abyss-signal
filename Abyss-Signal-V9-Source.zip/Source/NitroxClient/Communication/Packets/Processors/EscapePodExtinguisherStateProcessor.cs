using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.GameLogic;
using NitroxModel.Packets;

namespace NitroxClient.Communication.Packets.Processors;

public class EscapePodExtinguisherStateProcessor : ClientPacketProcessor<EscapePodExtinguisherState>
{
    private readonly EscapePodManager pods;

    public EscapePodExtinguisherStateProcessor(EscapePodManager pods) => this.pods = pods;

    public override void Process(EscapePodExtinguisherState packet) => pods.ApplyExtinguisherState(packet);
}
