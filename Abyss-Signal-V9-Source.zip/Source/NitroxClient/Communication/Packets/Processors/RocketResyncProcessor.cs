using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxClient.GameLogic;
using NitroxModel.DataStructures;
using NitroxModel_Subnautica.DataStructures.GameLogic;
using NitroxModel_Subnautica.Packets;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors;

public class RocketResyncProcessor : ClientPacketProcessor<RocketResync>
{
    private readonly Vehicles vehicles;

    public RocketResyncProcessor(Vehicles vehicles)
    {
        this.vehicles = vehicles;
    }

    public override void Process(RocketResync packet)
    {
        var model = vehicles.TryGetVehicle<NeptuneRocketModel>(packet.RocketId);
        if (model.HasValue)
            model.Value.PreflightChecks = new ThreadSafeList<PreflightCheck>(packet.PreflightChecks);

        if (!NitroxEntity.TryGetObjectFrom(packet.RocketId, out GameObject gameObjectRocket) || !gameObjectRocket)
        {
            return;
        }

        RocketPreflightCheckManager manager = gameObjectRocket.GetComponentInChildren<RocketPreflightCheckManager>(true);
        if (!manager) return;

        bool timeCapsuleReady = manager.preflightChecks.Contains(PreflightCheck.TimeCapsule);
        manager.preflightChecks.Clear();
        manager.preflightChecks.UnionWith(packet.PreflightChecks);
        if (timeCapsuleReady) manager.preflightChecks.Add(PreflightCheck.TimeCapsule);

        if (!manager.ReturnRocketReadyForLaunch(false))
        {
            manager.CancelInvoke("RocketReady");
            manager.rocketReadyDelay = false;
        }
        else if (!manager.rocketReadyDelay && !manager.IsInvoking("RocketReady"))
        {
            manager.Invoke("RocketReady", 10f);
        }
        RocketPreflightCheckScreenElement[] screenElements = gameObjectRocket.GetComponentsInChildren<RocketPreflightCheckScreenElement>(true);
        CockpitSwitch[] cockpitSwitches = gameObjectRocket.GetComponentsInChildren<CockpitSwitch>(true);
        ThrowSwitch[] throwSwitches = gameObjectRocket.GetComponentsInChildren<ThrowSwitch>(true);

        foreach (RocketPreflightCheckScreenElement screenElement in screenElements)
        {
            if (manager.preflightChecks.Contains(screenElement.preflightCheck))
            {
                screenElement.SetPreflightCheckComplete(screenElement.preflightCheck);
            }
            else
            {
                screenElement.SetPreflightCheckIncomplete(screenElement.preflightCheck);
            }
        }
        foreach (CockpitSwitch cockpit in cockpitSwitches)
        {
            bool completed = manager.preflightChecks.Contains(cockpit.preflightCheck);
            // Reset cockpitSwitch state
            if (cockpit.collision) cockpit.collision.SetActive(true);
            cockpit.completed = false;
            cockpit.animator.SetBool("Completed", false);

            // Then enable if completed
            cockpit.completed = completed;
            cockpit.Start();
        }
        foreach (ThrowSwitch throwSwitch in throwSwitches)
        {
            bool completed = manager.preflightChecks.Contains(throwSwitch.preflightCheck);
            // Reset throwSwitch state
            throwSwitch.completed = false;
            throwSwitch.triggerCollider.enabled = true;
            throwSwitch.cinematicTrigger.showIconOnHandHover = true;
            throwSwitch.lamp.GetComponent<SkinnedMeshRenderer>().material = throwSwitch.incompleteMat;

            // Then enable if completed
            throwSwitch.completed = completed;
            throwSwitch.Start();
        }
    }
}


