using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxClient.GameLogic.Helper;
namespace Nitrox.Test.Client
{
    [TestClass, DoNotParallelize]
    public class SerializationFailureStateTest
    {
        [DataTestMethod]
        [DataRow(true)]
        [DataRow(false)]
        public void MalformedInputRestoresTheCallersSpawnPolicy(bool initial)
        {
            bool original = SerializationHelper.BLOCK_HAND_PLACED_DESERIALIZATION;
            try
            {
                SerializationHelper.BLOCK_HAND_PLACED_DESERIALIZATION = initial;
                Assert.ThrowsException<ArgumentNullException>(() => SerializationHelper.GetGameObject(null));
                Assert.AreEqual(initial, SerializationHelper.BLOCK_HAND_PLACED_DESERIALIZATION,
                    "A failed inventory read must not alter later world deserialization policy.");
            }
            finally { SerializationHelper.BLOCK_HAND_PLACED_DESERIALIZATION = original; }
        }
    }
}
