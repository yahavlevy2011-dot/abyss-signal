using System.Linq;
using HarmonyLib;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxPatcher.Patches.Dynamic;

namespace NitroxTest.Patcher.Patches.Dynamic;

[TestClass]
public class BreakableResourceSyncTest
{
    [TestMethod]
    public void LegacySpawnBroadcastsExactlyOneInstantiatedResource()
    {
        var target = AccessTools.Method(typeof(BreakableResource), "SpawnResourceFromPrefab");
        var callback = AccessTools.Method(typeof(BreakableResource_Sync_Patch), nameof(BreakableResource_Sync_Patch.BroadcastYield));
        var instructions = PatchTestHelper.GetInstructionsFromMethod(target);

        Assert.AreEqual(1, BreakableResource_Sync_Patch.Transpiler(instructions).Count(instruction => instruction.Calls(callback)));
    }
}

