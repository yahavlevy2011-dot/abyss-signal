using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxModel.DataStructures;
using NitroxModel.Helper;
namespace Nitrox.Test.Model.Helper
{
    [TestClass]
    public class QuickSlotKeyTest
    {
        [TestMethod] public void PreservesDistinctCopiesOfSameTool()
        {
            var a = new NitroxId(Guid.NewGuid()); var b = new NitroxId(Guid.NewGuid());
            Assert.AreNotEqual(QuickSlotKey.Encode(a), QuickSlotKey.Encode(b));
            Assert.IsTrue(QuickSlotKey.TryDecode(QuickSlotKey.Encode(a), out var restored));
            Assert.AreEqual(a, restored);
        }
        [DataTestMethod]
        [DataRow(null)] [DataRow("null")] [DataRow("")] [DataRow("dc-item:broken")]
        [DataRow("dc-item:00000000000000000000000000000000")]
        [DataRow("00000000-0000-0000-0000-000000000000")]
        public void InvalidOrLegacyKeyIsNotReinterpretedAsNetworkIdentity(string value)
        { Assert.IsFalse(QuickSlotKey.TryDecode(value, out var id)); Assert.IsNull(id); }
    }
}
