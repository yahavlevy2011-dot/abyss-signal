using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using NitroxLauncher.Models.Events;

namespace NitroxLauncher
{
    internal sealed class ServerLogic : IDisposable
    {
        public const string SERVER_EXECUTABLE = "NitroxServer-Subnautica.exe";

        public bool IsManagedByLauncher => IsEmbedded && IsServerRunning;
        public bool IsServerRunning => !serverProcess?.HasExited ?? false;
        private volatile bool isListening;
        public bool IsListening => IsManagedByLauncher && isListening;
        public string PlayerRoster { get; private set; }
        public string ActiveWorld { get; private set; }
        public string StatusLabel => !IsServerRunning ? "SERVER · OFFLINE"
            : !IsEmbedded ? "SERVER · EXTERNAL PROCESS"
            : isListening ? "SERVER · LISTENING" : "SERVER · STARTING";
        public bool IsEmbedded { get; private set; }

        public event EventHandler<ServerStartEventArgs> ServerStarted;
        public event DataReceivedEventHandler ServerDataReceived;
        public event EventHandler ServerExited;

        private Process serverProcess;

        public void Dispose()
        {
            if (IsEmbedded)
            {
                SendServerCommand("stop\n");
            }

            serverProcess?.Dispose();
            serverProcess = null;
        }

        internal Process StartServer(bool standalone, string worldName, bool requireExistingWorld = false)
        {
            if (IsServerRunning)
            {
                throw new Exception("An instance of Nitrox Server is already running");
            }

            string launcherDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            string serverPath = Path.Combine(launcherDir, SERVER_EXECUTABLE);
            string tidraServerPath = Path.Combine(launcherDir, "TIDRA.Server.exe");
            if (File.Exists(tidraServerPath)) serverPath = tidraServerPath;
            string abyssServerPath = Path.Combine(launcherDir, "AbyssSignal.Server.exe");
            if (File.Exists(abyssServerPath)) serverPath = abyssServerPath;
            ProcessStartInfo startInfo = new(serverPath);
            startInfo.WorkingDirectory = launcherDir;

            startInfo.UseShellExecute = false;
            startInfo.EnvironmentVariables.Remove(NitroxModel.Helper.DeepCurrentLegacy.WorldSelectionVariable);
            if (!string.IsNullOrEmpty(worldName))
            {
                startInfo.EnvironmentVariables[NitroxModel.Helper.DeepCurrentLegacy.WorldSelectionVariable] = worldName;
            }

            startInfo.EnvironmentVariables.Remove(NitroxModel.Helper.DeepCurrentLegacy.RequireExistingWorldVariable);
            if (requireExistingWorld)
            {
                startInfo.EnvironmentVariables[NitroxModel.Helper.DeepCurrentLegacy.RequireExistingWorldVariable] = "1";
            }

            if (!standalone)
            {
                startInfo.RedirectStandardError = true;
                startInfo.RedirectStandardOutput = true;
                startInfo.RedirectStandardInput = true;
                startInfo.CreateNoWindow = true;
            }

            isListening = false;
            PlayerRoster = null;
            ActiveWorld = worldName;
            serverProcess = Process.Start(startInfo);
            if (serverProcess != null)
            {
                serverProcess.Exited += (sender, args) => OnEndServer();
                OnStartServer(!standalone);
                serverProcess.EnableRaisingEvents = true;

                if (!standalone)
                {
                    serverProcess.ErrorDataReceived += ServerProcessOnOutputDataReceived;
                    serverProcess.BeginErrorReadLine();
                    serverProcess.OutputDataReceived += ServerProcessOnOutputDataReceived;
                    serverProcess.BeginOutputReadLine();
                }

            }

            return serverProcess;
        }

        internal void SendServerCommand(string inputText)
        {
            if (!IsServerRunning)
            {
                return;
            }

            try
            {
                serverProcess.StandardInput.WriteLine(inputText);
            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
        }

        private void OnEndServer()
        {
            IsEmbedded = false;
            isListening = false;
            ServerExited?.Invoke(serverProcess, new EventArgs());
        }

        private void OnStartServer(bool embedded)
        {
            IsEmbedded = embedded;
            ServerStarted?.Invoke(serverProcess, new ServerStartEventArgs(embedded));
        }

        private void ServerProcessOnOutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (e.Data?.IndexOf("Server is listening on port ", StringComparison.Ordinal) >= 0)
            {
                isListening = true;
            }
            const string rosterPrefix = "TIDRA_ROSTER ";
            if (e.Data?.StartsWith(rosterPrefix, StringComparison.Ordinal) == true)
            {
                PlayerRoster = string.Join("\n", e.Data.Substring(rosterPrefix.Length)
                    .Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries));
            }

            ServerDataReceived?.Invoke(sender, e);
        }
    }
}




