using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using NitroxLauncher.Models;
using NitroxModel.Helper;

namespace NitroxLauncher.Pages
{
    public partial class WorldsPage : PageBase
    {
        public WorldsPage()
        {
            InitializeComponent();
            DispatcherTimer telemetry = new() { Interval = TimeSpan.FromSeconds(3) };
            telemetry.Tick += (_, _) => RefreshLiveWorld();
            Loaded += (_, _) =>
            {
                Refresh();
                RefreshLiveWorld();
                telemetry.Start();
            };
            Unloaded += (_, _) => telemetry.Stop();
        }

        private void RefreshLiveWorld()
        {
            var server = LauncherLogic.Server;
            LiveWorld.Text = server.IsListening && server.PlayerRoster != null
                ? $"Hosting {server.ActiveWorld ?? "default world"} · {server.PlayerRoster.Replace("\n", " · ")}"
                : string.Empty;
            LiveWorld.Visibility = string.IsNullOrEmpty(LiveWorld.Text) ? Visibility.Collapsed : Visibility.Visible;
            if (server.IsListening)
            {
                server.SendServerCommand("list --tidra-roster");
            }
        }

        private void Refresh()
        {
            try
            {
                string root = Path.GetDirectoryName(DeepCurrentLegacy.WorldDirectory("world"));
                var worlds = (Directory.Exists(root) ? Directory.EnumerateDirectories(root) : Array.Empty<string>())
                    .SelectMany(path => new[] { ".json", ".nitrox" }.Select(extension =>
                        new FileInfo(Path.Combine(path, "WorldData" + extension))))
                    .Where(save => save.Exists)
                    .GroupBy(save => save.DirectoryName)
                    .Select(group => group.OrderByDescending(save => save.LastWriteTimeUtc).First())
                    .OrderByDescending(save => save.LastWriteTimeUtc)
                    .Select(save => new { Name = save.Directory.Name, Saved = $"Last saved · {save.LastWriteTime:g}" })
                    .ToArray();
                WorldCards.ItemsSource = worlds;
                ArchiveStatus.Text = worlds.Length == 0
                    ? "No local saves yet. Create a world in Server Control."
                    : "Continue a local expedition from its existing save.";
            }
            catch (IOException ex)
            {
                ArchiveStatus.Text = ex.Message;
            }
            catch (UnauthorizedAccessException ex)
            {
                ArchiveStatus.Text = ex.Message;
            }
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            string name = (string)((FrameworkElement)sender).Tag;
            if (LauncherLogic.Server.IsServerRunning)
            {
                ArchiveStatus.Text = "Stop the server before removing a world.";
                return;
            }

            if (MessageBox.Show(Window.GetWindow(this), $"Move the world '{name}' to the Removed Worlds folder?",
                    "Remove world", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No) != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                string source = DeepCurrentLegacy.WorldDirectory(name);
                string archive = Path.Combine(DeepCurrentLegacy.DataDirectory, "removed-worlds");
                Directory.CreateDirectory(archive);
                if (((File.GetAttributes(source) | File.GetAttributes(archive)) & FileAttributes.ReparsePoint) != 0)
                {
                    throw new IOException("Linked world folders cannot be moved.");
                }

                Directory.Move(source, Path.Combine(archive, Guid.NewGuid().ToString("N") + "-" + name));
                Refresh();
                ArchiveStatus.Text = $"'{name}' was moved to Removed Worlds.";
            }
            catch (IOException ex)
            {
                ArchiveStatus.Text = ex.Message;
            }
            catch (UnauthorizedAccessException ex)
            {
                ArchiveStatus.Text = ex.Message;
            }
        }

        private void Continue_Click(object sender, RoutedEventArgs e)
        {
            string worldName = (string)((FrameworkElement)sender).Tag;
            try
            {
                if (LauncherLogic.Server.IsServerRunning)
                {
                    if (string.Equals(LauncherLogic.Server.ActiveWorld, worldName, StringComparison.OrdinalIgnoreCase))
                    {
                        LauncherLogic.Instance.NavigateTo<ServerPage>();
                        return;
                    }

                    ArchiveStatus.Text = "Stop the current server before continuing another world.";
                    return;
                }

                string path = DeepCurrentLegacy.WorldDirectory(worldName);
                if (!File.Exists(Path.Combine(path, "WorldData.json")) && !File.Exists(Path.Combine(path, "WorldData.nitrox")))
                {
                    Refresh();
                    ArchiveStatus.Text = "This save is no longer available.";
                    return;
                }

                LauncherLogic.Server.StartServer(false, worldName, requireExistingWorld: true);
            }
            catch (Exception ex)
            {
                ArchiveStatus.Text = ex.Message;
            }
        }
    }
}


