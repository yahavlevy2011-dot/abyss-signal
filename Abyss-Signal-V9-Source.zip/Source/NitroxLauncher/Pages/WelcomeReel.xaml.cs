using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using NitroxModel.Helper;

namespace NitroxLauncher.Pages
{
    public partial class WelcomeReel : UserControl
    {
        private const double SecondsPerShot = 2.4;
        private static readonly (int Scene, string Kicker, string Title, string Subtitle)[] shots =
        {
            (-1, "WELCOME TO", "ABYSS SIGNAL", "A shared expedition into the depths."),
            (-1, "EXPEDITION BROADCAST", "YLS PRESENTS", "Subnautica multiplayer"),
            (0, "01  /  EXPLORATION", "SAFE SHALLOWS", "Sunlit reefs and a world to discover."),
            (1, "02  /  DESCENT", "JELLYSHROOM CAVES", "Follow the light beneath the reef."),
            (2, "03  /  FAUNA", "THE LOST RIVER", "Some things are better faced together."),
            (3, "04  /  THE DEPTHS", "LAVA ZONE", "Far below the surface, something is waiting."),
            (-1, "ABYSS SIGNAL", "DIVE TOGETHER", "Your expedition starts here.")
        };

        private readonly DispatcherTimer timer = new();
        private BitmapSource reef;
        private BitmapSource montage;
        private bool started;
        private int index;

        public WelcomeReel()
        {
            InitializeComponent();
            timer.Interval = TimeSpan.FromSeconds(SecondsPerShot);
            timer.Tick += (_, _) =>
            {
                if (++index == shots.Length) Finish();
                else ShowShot();
            };
            Unloaded += (_, _) => timer.Stop();
        }

        public void PlayOnFirstLaunch()
        {
            try
            {
                if (started) return;
                started = true;
                string seenPath = Path.Combine(DeepCurrentLegacy.DataDirectory, "abyss-launcher-intro.seen");
                if (File.Exists(seenPath)) return;

                reef = LoadImage("deep_current.jpg");
                montage = LoadImage("welcome_montage.png");
                try
                {
                    using (File.Open(seenPath, FileMode.CreateNew, FileAccess.Write, FileShare.Read)) { }
                }
                catch (IOException) when (File.Exists(seenPath))
                {
                    return;
                }

                index = 0;
                Visibility = Visibility.Visible;
                ShowShot();
                SkipButton.Focus();
                Progress.BeginAnimation(RangeBaseValueProperty,
                    new DoubleAnimation(0, 100, TimeSpan.FromSeconds(SecondsPerShot * shots.Length)));
                timer.Start();
            }
            catch (Exception error)
            {
                Visibility = Visibility.Collapsed;
                Log.Warn("Unable to play the launcher opening: " + error.Message);
            }
        }

        private static DependencyProperty RangeBaseValueProperty => System.Windows.Controls.Primitives.RangeBase.ValueProperty;

        private static BitmapSource LoadImage(string file)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "DiveMedia", file);
            return File.Exists(path) ? new BitmapImage(new Uri(path)) : null;
        }

        private void ShowShot()
        {
            var shot = shots[index];
            Artwork.Source = shot.Scene < 0 || montage == null
                ? reef
                : new CroppedBitmap(montage, new Int32Rect(
                    shot.Scene % 2 * montage.PixelWidth / 2, shot.Scene / 2 * montage.PixelHeight / 2,
                    montage.PixelWidth / 2, montage.PixelHeight / 2));
            Kicker.Text = shot.Kicker;
            Headline.Text = shot.Title;
            Subtitle.Text = shot.Subtitle;
            Zoom.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1.01, 1.085, timer.Interval));
            Zoom.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1.01, 1.085, timer.Interval));
            Caption.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(350)));
            Artwork.BeginAnimation(OpacityProperty, new DoubleAnimation(0.4, 1, TimeSpan.FromMilliseconds(450)));
        }

        private void Skip_Click(object sender, RoutedEventArgs args) => Finish();

        private void WelcomeKeyDown(object sender, KeyEventArgs args)
        {
            if (args.Key == Key.Escape)
            {
                args.Handled = true;
                Finish();
            }
        }

        private void Finish()
        {
            timer.Stop();
            Progress.BeginAnimation(RangeBaseValueProperty, null);
            Visibility = Visibility.Collapsed;
        }
    }
}
