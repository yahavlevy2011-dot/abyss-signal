using NitroxLauncher.Models;
namespace NitroxLauncher.Pages { public partial class AboutPage : PageBase { public AboutPage() { InitializeComponent(); } } }
