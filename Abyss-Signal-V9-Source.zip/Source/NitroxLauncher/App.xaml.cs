global using NitroxModel.Logger;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace NitroxLauncher
{
    /// <summary>
    ///     Use MainWindow.xaml.cs or LauncherLogic.cs for Nitrox init code to make exceptions during startup unlikely.
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            // Direct .exe launches can inherit System32 as their directory.
            // Never attempt to change its permissions to make it writable.
            System.IO.Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);
            // Set default style for all windows to the style with the target type 'Window' (in App.xaml).
            FrameworkElement.StyleProperty.OverrideMetadata(typeof(Window),
                new FrameworkPropertyMetadata
                {
                    DefaultValue = FindResource(typeof(Window))
                });
            FrameworkElement.StyleProperty.OverrideMetadata(typeof(Page),
                new FrameworkPropertyMetadata
                {
                    DefaultValue = FindResource(typeof(Page))
                });

            base.OnStartup(e);
            _ = Task.Run(RefreshInstalledHub);
        }

        private static void RefreshInstalledHub()
        {
            string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "TIDRA", "Deep Current");
            string runtime = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
            string versions = Path.Combine(root, "versions");
            if (!string.Equals(Path.GetDirectoryName(runtime), versions, StringComparison.OrdinalIgnoreCase) ||
                !File.Exists(Path.Combine(runtime, ".ready")))
            {
                return;
            }

            string bundled = Path.Combine(runtime, "Abyss Signal Hub.exe");
            string installed = Path.Combine(root, "Abyss Signal Hub.exe");
            if (!File.Exists(bundled) || !File.Exists(installed)) return;

            try
            {
                using Mutex gate = new(false, @"Local\TIDRA.DeepCurrent.Setup");
                bool acquired;
                try { acquired = gate.WaitOne(TimeSpan.FromSeconds(10)); }
                catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) return;
                try
                {
                    if (!File.Exists(installed) ||
                        FileVersionInfo.GetVersionInfo(installed).FileMajorPart >= FileVersionInfo.GetVersionInfo(bundled).FileMajorPart)
                    {
                        return;
                    }

                    string pending = Path.Combine(root, Guid.NewGuid().ToString("N") + ".hub.tmp");
                    try
                    {
                        File.Copy(bundled, pending);
                        File.Replace(pending, installed, null);
                    }
                    finally { File.Delete(pending); }
                }
                finally { gate.ReleaseMutex(); }
            }
            catch (Exception error)
            {
                Log.Warn("Unable to refresh the installed Abyss Signal updater: " + error.Message);
            }
        }

        private void Application_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            // If something went wrong. Close the server if embedded.
            LauncherLogic.Instance.Dispose();

            Log.Error(e.Exception.GetBaseException().ToString()); // Gets the exception that was unhandled, not the "dispatched unhandled" exception.
            MessageBox.Show(GetExceptionError(e.Exception), "Error", MessageBoxButton.OK, MessageBoxImage.Error, MessageBoxResult.OK, MessageBoxOptions.DefaultDesktopOnly);
        }

        private string GetExceptionError(Exception e)
        {
#if RELEASE
            return e.GetBaseException().Message;
#else
            return e.GetBaseException().ToString();
#endif
        }
    }
}
