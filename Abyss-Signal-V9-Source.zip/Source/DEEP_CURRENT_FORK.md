# TIDRA / Deep Current Legacy — modified fork

Based on SubnauticaNitrox/Nitrox 1.7.1.0 (release commit 820e2f2).
Modified 2026-11-04. Not an official Nitrox release. GPLv3 license and original
copyright notices are retained. Corresponding modified source is supplied.

Target: Legacy 68598 only, fixed maximum four players. Modifications include
explicit game selection, isolated worlds and per-session native scratch storage,
manual-save defaults, atomic original assembly backup/restore, server STOP/EOF
handling, TIDRA launcher/branding, remote PDA geometry and animation state,
world-camera layers for remote tools, observer-only extinguisher FX replication,
and release of the native cinematic movement lock after terrain loading.
No game DRM, Steam API files or platform authentication are modified.

Two real game processes on one Windows PC validated connection, remote character
textures/colors, PDA opening/closing, held extinguisher visibility, test item save
and reload, food/water consumption, and timed native extinguisher spray replicated
as white particles with an OFF transition. The spray input was an explicitly
opted-in native integration fixture, not a manual sustained mouse press.
167 unit/patch tests passed. This is not verification of every upstream system.
No two-PC or Hamachi latency validation has been completed. Manual host START,
all-player intro gates/no-skip rules, quick-slot binding persistence and a custom
quit-without-save confirmation remain unfinished. See VERIFIED_RESULTS_HE.md.

Build Nitrox.BuildTool, run it with --game-path pointing to an isolated clean
Legacy reference directory, then build NitroxLauncher (net472). Do not distribute
game.props, generated reference/game DLLs, saves or private test logs. Packaging
renames launcher/server executables and their config files to TIDRA.exe and
TIDRA.Server.exe; managed library names are retained for compatibility.
