using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

internal static class TidraSetup
{
    private const int EmbeddedVersion = 74;
    private const long MaxPackage = 150 * 1024 * 1024;
    private static string root;
    private static string Versions { get { return Path.Combine(root, "versions"); } }
    private static string FeedFile { get { return Path.Combine(root, "update-source.txt"); } }

    [STAThread]
    private static int Main(string[] args)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        bool test = args.Length >= 2 && args[0] == "--test-root";
        root = test ? Path.GetFullPath(args[1]) : Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TIDRA", "Deep Current");
        using (Mutex gate = new Mutex(false, @"Local\TIDRA.DeepCurrent.Setup"))
        {
            bool acquired;
            try { acquired = gate.WaitOne(0); }
            catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) return 2;
            try
            {
                Directory.CreateDirectory(Versions);
                if (test)
                {
                    InstallEmbedded(null);
                    if (args.Length == 3) Update(args[2]);
                    Console.WriteLine("Installed Preview " + Latest());
                    return 0;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                if (Latest() < EmbeddedVersion || !string.Equals(Application.ExecutablePath, HubPath, StringComparison.OrdinalIgnoreCase))
                    Application.Run(new SetupWizard());
                else
                    Application.Run(new InstallerWindow());
                return 0;
            }
            catch (Exception error)
            {
                if (test) Console.Error.WriteLine(error.Message);
                else MessageBox.Show(error.Message, "Abyss Signal", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
            finally { gate.ReleaseMutex(); }
        }
    }

    private static string HubPath { get { return Path.Combine(root, "Abyss Signal Hub.exe"); } }

    private static void InstallEmbedded(Action<int, string> progress)
    {
        int previous = Latest();
        if (previous >= EmbeddedVersion) return;
        using (Stream seed = Assembly.GetExecutingAssembly().GetManifestResourceStream("tidra.seed"))
            Install(seed, EmbeddedVersion, previous, progress);
    }

    private static void OpenLauncher()
    {
        string directory = VersionPath(Latest());
        Process.Start(new ProcessStartInfo(LauncherPath(directory)) { WorkingDirectory = directory });
    }

    private static string VersionPath(int version)
    {
        return Path.Combine(Versions, version.ToString(CultureInfo.InvariantCulture));
    }

    private static string LauncherPath(string directory)
    {
        string branded = Path.Combine(directory, "AbyssSignal.exe");
        return File.Exists(branded) ? branded : Path.Combine(directory, "TIDRA.exe");
    }

    private static bool Installed(int version)
    {
        string path = VersionPath(version);
        return File.Exists(Path.Combine(path, ".ready")) && File.Exists(LauncherPath(path));
    }

    private static int Latest()
    {
        return Directory.EnumerateDirectories(Versions).Select(Path.GetFileName)
            .Select(name => { int number; return int.TryParse(name, out number) && Installed(number) ? number : 0; })
            .DefaultIfEmpty(0).Max();
    }

    private static void Install(Stream payload, int version, int previous, Action<int, string> progress = null)
    {
        string target = VersionPath(version);
        string stage = Path.Combine(Versions, ".install-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(stage);
        try
        {
            string safeRoot = Path.GetFullPath(stage) + Path.DirectorySeparatorChar;
            long extracted = 0;
            int reported = -1;
            using (ZipArchive zip = new ZipArchive(payload, ZipArchiveMode.Read, true))
            {
                long total = zip.Entries.Sum(entry => entry.Length);
                if (total > MaxPackage) throw new InvalidDataException("Package is too large.");
                foreach (ZipArchiveEntry entry in zip.Entries)
                {
                    if (entry.FullName.Contains(":"))
                        throw new InvalidDataException("Invalid package file name.");
                    string path = Path.GetFullPath(Path.Combine(stage, entry.FullName));
                    if (!path.StartsWith(safeRoot, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidDataException("Invalid package file path.");
                    if (string.IsNullOrEmpty(entry.Name)) { Directory.CreateDirectory(path); continue; }
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    using (Stream source = entry.Open())
                    using (FileStream destination = new FileStream(path, FileMode.CreateNew))
                        source.CopyTo(destination);
                    extracted += entry.Length;
                    int percent = total == 0 ? 0 : (int)(extracted * 95 / total);
                    if (percent != reported && progress != null)
                    {
                        reported = percent;
                        progress(percent, "Installing " + entry.Name);
                    }
                }
            }

            if (!File.Exists(LauncherPath(stage)) ||
                !(File.Exists(Path.Combine(stage, "AbyssSignal.Server.exe")) || File.Exists(Path.Combine(stage, "TIDRA.Server.exe"))))
                throw new InvalidDataException("Package is missing the launcher or server.");
            foreach (string file in new[] { @"lib\NitroxClient.dll", @"lib\NitroxPatcher.dll" })
                if (!File.Exists(Path.Combine(stage, file))) throw new InvalidDataException("Package is missing " + file);
            if (previous > 0)
            {
                string previousServers = Path.Combine(VersionPath(previous), "servers");
                if (File.Exists(previousServers)) File.Copy(previousServers, Path.Combine(stage, "servers"), true);
            }
            File.WriteAllText(Path.Combine(stage, ".ready"), "");
            Directory.Move(stage, target);
            if (progress != null) progress(100, "Files installed.");
        }
        finally
        {
            if (Directory.Exists(stage)) Directory.Delete(stage, true);
        }
    }

    private static Uri SourceUri(string input)
    {
        Uri uri;
        if (Path.IsPathRooted(input) && !input.StartsWith(@"\\")) uri = new Uri(Path.GetFullPath(input));
        else if (!Uri.TryCreate(input, UriKind.Absolute, out uri)) throw new InvalidDataException("Use an HTTPS URL or a local catalog path.");
        if (uri.Scheme != "https" && !(uri.IsFile && !uri.IsUnc))
            throw new InvalidDataException("Only HTTPS and local catalog files are supported.");
        return uri;
    }

    private static byte[] Read(Uri uri, long limit, Action<long> progress = null)
    {
        if (uri.IsFile)
        {
            using (FileStream source = File.OpenRead(uri.LocalPath)) return ReadLimited(source, limit, progress);
        }
        var request = (HttpWebRequest)WebRequest.Create(uri);
        request.Timeout = 12000;
        request.ReadWriteTimeout = 12000;
        request.AllowAutoRedirect = false;
        using (var response = (HttpWebResponse)request.GetResponse())
        {
            if (response.StatusCode != HttpStatusCode.OK) throw new IOException("Update source must return HTTP 200.");
            using (Stream source = response.GetResponseStream()) return ReadLimited(source, limit, progress);
        }
    }

    private static byte[] ReadLimited(Stream source, long limit, Action<long> progress)
    {
        using (var buffer = new MemoryStream())
        {
            byte[] block = new byte[65536];
            int count;
            while ((count = source.Read(block, 0, block.Length)) > 0)
            {
                if (buffer.Length + count > limit) throw new InvalidDataException("Download exceeded the expected size.");
                buffer.Write(block, 0, count);
                if (progress != null) progress(buffer.Length);
            }
            return buffer.ToArray();
        }
    }

    private static void Update(string source, Action<int, string> progress = null, int minimumVersion = 1)
    {
        Uri catalog = SourceUri(source);
        string[] lines = System.Text.Encoding.UTF8.GetString(Read(catalog, 4096)).Trim().Split('\n').Select(x => x.Trim()).ToArray();
        int version;
        if (lines.Length != 3 || !int.TryParse(lines[0], out version) || version < 1 || lines[2].Length != 64)
            throw new InvalidDataException("Invalid update catalog.");
        int installed = Latest();
        if (version <= installed || version < minimumVersion) return;

        Uri package = new Uri(catalog, lines[1]);
        if (package.Scheme != catalog.Scheme || !string.Equals(package.Authority, catalog.Authority, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("The package must use the same source as the catalog.");
        long shown = -1;
        byte[] data = Read(package, MaxPackage, bytes =>
        {
            long megabytes = bytes / 1048576;
            if (progress != null && megabytes != shown)
            {
                shown = megabytes;
                progress(-1, "Downloading Preview " + version + " (" + megabytes + " MB)...");
            }
        });
        if (progress != null) progress(0, "Verifying the download...");
        using (SHA256 sha = SHA256.Create())
        {
            string digest = BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "");
            if (!string.Equals(digest, lines[2], StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Package integrity check failed.");
        }
        using (var stream = new MemoryStream(data, false)) Install(stream, version, installed, progress);
    }

    private static void RegisterShortcut()
    {
        string source = Application.ExecutablePath;
        string installed = HubPath;
        if (!string.Equals(source, installed, StringComparison.OrdinalIgnoreCase)) File.Copy(source, installed, true);
        string shortcutFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), "Abyss Signal.lnk");
        Type shellType = Type.GetTypeFromProgID("WScript.Shell", true);
        dynamic shell = Activator.CreateInstance(shellType);
        dynamic link = shell.CreateShortcut(shortcutFile);
        link.TargetPath = installed;
        link.WorkingDirectory = root;
        link.Description = "Open Abyss Signal and check for updates";
        link.IconLocation = LauncherPath(VersionPath(Latest())) + ",0";
        link.Save();
        string previousShortcut = Path.Combine(Path.GetDirectoryName(shortcutFile), "TIDRA - Deep Current.lnk");
        if (File.Exists(previousShortcut))
        {
            dynamic previousLink = shell.CreateShortcut(previousShortcut);
            if (string.Equals((string)previousLink.TargetPath, Path.Combine(root, "TIDRA Hub.exe"), StringComparison.OrdinalIgnoreCase))
                File.Delete(previousShortcut);
        }
    }

    private static void StyleAction(Button button, bool primary)
    {
        button.FlatStyle = FlatStyle.Flat;
        button.UseVisualStyleBackColor = false;
        button.BackColor = primary ? Color.FromArgb(255, 182, 96) : Color.FromArgb(18, 55, 70);
        button.ForeColor = primary ? Color.FromArgb(10, 27, 38) : Color.FromArgb(215, 247, 249);
        button.FlatAppearance.BorderColor = primary ? Color.FromArgb(255, 202, 132) : Color.FromArgb(73, 156, 168);
        button.Cursor = Cursors.Hand;
    }

    private sealed class OceanPanel : Panel
    {
        private readonly Bitmap artwork;

        public OceanPanel()
        {
            DoubleBuffered = true;
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("abyss.art"))
            {
                if (stream != null)
                    using (Image image = Image.FromStream(stream))
                        artwork = new Bitmap(image);
            }
        }

        protected override void OnPaint(PaintEventArgs args)
        {
            base.OnPaint(args);
            Graphics g = args.Graphics;
            g.Clear(Color.FromArgb(10, 38, 54));
            if (artwork != null)
            {
                int sourceWidth = artwork.Height * Width / Height;
                int left = (artwork.Width - sourceWidth) * 4 / 5;
                g.DrawImage(artwork, ClientRectangle, new Rectangle(left, 0, sourceWidth, artwork.Height), GraphicsUnit.Pixel);
            }
            using (var tint = new System.Drawing.Drawing2D.LinearGradientBrush(ClientRectangle,
                Color.FromArgb(185, 5, 22, 34), Color.FromArgb(42, 5, 22, 34), 90f))
                g.FillRectangle(tint, ClientRectangle);
            using (var line = new Pen(Color.FromArgb(89, 185, 194)))
            {
                g.DrawLine(line, Width - 1, 0, Width - 1, Height);
                g.DrawLine(line, 16, 86, 68, 86);
            }
            using (var brand = new Font("Segoe UI", 17, FontStyle.Bold))
            using (var small = new Font("Segoe UI", 8, FontStyle.Bold))
            {
                TextRenderer.DrawText(g, "ABYSS\r\nSIGNAL", brand, new Point(13, 18), Color.White);
                TextRenderer.DrawText(g, "EXPEDITION SYSTEMS", small, new Point(14, 94), Color.PaleTurquoise);
                TextRenderer.DrawText(g, "SUBNAUTICA LEGACY", small, new Point(14, Height - 35), Color.White);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && artwork != null) artwork.Dispose();
            base.Dispose(disposing);
        }
    }

    private sealed class SetupWizard : Form
    {
        private readonly Label heading = new Label { Left = 180, Top = 26, Width = 392, Height = 66 };
        private readonly Label body = new Label { Left = 180, Top = 103, Width = 392, Height = 90 };
        private readonly Label sourceLabel = new Label { Left = 180, Top = 174, Width = 400, Height = 22, Text = "Update source (optional HTTPS URL or local catalog)" };
        private readonly TextBox sourceField = new TextBox { Left = 180, Top = 199, Width = 400 };
        private readonly Label status = new Label { Left = 180, Top = 207, Width = 392, Height = 44 };
        private readonly ProgressBar progress = new ProgressBar { Left = 180, Top = 258, Width = 390, Height = 20, Visible = false };
        private readonly Button next = new Button { Text = "Install", Left = 381, Top = 13, Width = 88, Height = 28 };
        private readonly Button cancel = new Button { Text = "Cancel", Left = 476, Top = 13, Width = 88, Height = 28 };
        private readonly CheckBox launch = new CheckBox { Text = "Launch Abyss Signal", Checked = true, Left = 180, Top = 254, Width = 360, Visible = false };
        private bool busy;
        private bool finished;

        public SetupWizard()
        {
            Text = "Abyss Signal Setup";
            ClientSize = new Size(624, 382);
            Font = new Font("Segoe UI", 9);
            BackColor = Color.FromArgb(8, 25, 38);
            ForeColor = Color.FromArgb(219, 245, 249);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            heading.Text = "Welcome to the Abyss Signal\r\nSetup Wizard";
            heading.Font = new Font("Segoe UI", 17, FontStyle.Bold);
            heading.ForeColor = Color.White;
            status.ForeColor = Color.FromArgb(133, 231, 229);
            body.Text = "Setup will install Abyss Signal for this account and add a Start menu shortcut.\r\n\r\nIf you enter an update source, Setup checks it first.";
            sourceField.BackColor = Color.FromArgb(15, 45, 60);
            sourceField.ForeColor = Color.FromArgb(220, 244, 248);
            if (File.Exists(FeedFile)) sourceField.Text = File.ReadAllText(FeedFile).Trim();
            status.Top = 237;
            status.Text = "Version: Preview " + Math.Max(EmbeddedVersion, Latest());
            var side = new OceanPanel { Left = 0, Top = 0, Width = 156, Height = 327 };
            var footer = new Panel { Left = 0, Top = 327, Width = 624, Height = 55, BackColor = Color.FromArgb(12, 40, 54) };
            footer.Controls.Add(new Label { Left = 18, Top = 16, Width = 230, Height = 24,
                ForeColor = Color.FromArgb(133, 231, 229), Text = "ABYSS SIGNAL  /  SETUP" });
            next.Left = 414;
            cancel.Left = 512;
            StyleAction(next, true);
            StyleAction(cancel, false);
            footer.Controls.AddRange(new Control[] { next, cancel });
            Controls.AddRange(new Control[] { side, heading, body, sourceLabel, sourceField, status, progress, launch, footer });
            AcceptButton = next;
            CancelButton = cancel;
            cancel.Click += (_, __) => Close();
            FormClosing += (_, args) => args.Cancel = busy;
            next.Click += async (_, __) => await Advance();
        }

        private async Task Advance()
        {
            if (finished)
            {
                try
                {
                    if (launch.Checked) OpenLauncher();
                    Close();
                }
                catch (Exception error) { status.Text = error.Message; }
                return;
            }

            busy = true;
            next.Enabled = false;
            cancel.Enabled = false;
            heading.Text = "Installing Abyss Signal";
            sourceLabel.Visible = false;
            sourceField.Visible = false;
            status.Top = 207;
            body.Text = "Please wait while Setup installs the application.";
            status.Text = "Preparing installation...";
            progress.Visible = true;
            progress.Value = 0;
            var report = new Progress<Tuple<int, string>>(item =>
            {
                progress.Style = item.Item1 < 0 ? ProgressBarStyle.Marquee : ProgressBarStyle.Continuous;
                if (item.Item1 >= 0) progress.Value = item.Item1;
                status.Text = item.Item2;
            });
            try
            {
                string source = sourceField.Text.Trim();
                Action<int, string> reportProgress = (percent, message) =>
                    ((IProgress<Tuple<int, string>>)report).Report(Tuple.Create(percent, message));
                if (source.Length > 0)
                {
                    status.Text = "Checking for the latest version...";
                    progress.Style = ProgressBarStyle.Marquee;
                    try
                    {
                        SourceUri(source);
                        await Task.Run(() => TidraSetup.Update(source, reportProgress, EmbeddedVersion));
                        File.WriteAllText(FeedFile, source);
                    }
                    catch (Exception error)
                    {
                        int fallback = Math.Max(EmbeddedVersion, Latest());
                        DialogResult choice = MessageBox.Show(this,
                            "The update source could not be used.\r\n\r\n" + error.Message +
                            "\r\n\r\nContinue with Preview " + fallback + "?",
                            "Abyss Signal Setup", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                        if (choice != DialogResult.Yes)
                        {
                            heading.Text = "Choose an update source";
                            body.Text = "Edit the source and retry, or clear it to install the version included with Setup.";
                            progress.Visible = false;
                            status.Text = "";
                            sourceLabel.Visible = true;
                            sourceField.Visible = true;
                            next.Text = "Retry";
                            cancel.Enabled = true;
                            return;
                        }
                    }
                }
                await Task.Run(() => InstallEmbedded(reportProgress));
                RegisterShortcut();
                finished = true;
                heading.Text = "Completing the Abyss Signal\r\nSetup Wizard";
                body.Text = "Abyss Signal Preview " + Latest() + " was installed successfully.\r\n\r\nClick Finish to close Setup.";
                status.Text = "You can also open Abyss Signal from the Start menu.";
                progress.Visible = false;
                launch.Visible = true;
                next.Text = "Finish";
            }
            catch (Exception error)
            {
                heading.Text = "Setup could not complete";
                body.Text = "You can retry the installation or close Setup.";
                status.Text = error.Message;
                progress.Visible = false;
                next.Text = "Retry";
                sourceLabel.Visible = true;
                sourceField.Visible = true;
                cancel.Enabled = true;
            }
            finally
            {
                busy = false;
                next.Enabled = true;
            }
        }
    }

    private sealed class InstallerWindow : Form
    {
        private readonly Label status = new Label { Left = 24, Top = 80, Width = 432, Height = 54 };
        private readonly ProgressBar progressBar = new ProgressBar { Left = 24, Top = 121, Width = 432, Height = 10, Visible = false };
        private readonly TextBox feed = new TextBox { Left = 24, Top = 154, Width = 432 };
        private readonly Button play = new Button { Left = 24, Top = 196, Width = 170, Height = 36, Text = "OPEN ABYSS SIGNAL" };
        private readonly Button update = new Button { Left = 204, Top = 196, Width = 252, Height = 36, Text = "SAVE SOURCE & CHECK FOR UPDATES" };

        public InstallerWindow()
        {
            Text = "Abyss Signal";
            ClientSize = new Size(482, 256);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(8, 26, 39);
            ForeColor = Color.LightCyan;
            Font = new Font("Segoe UI", 10);
            Controls.Add(new Label { Left = 24, Top = 20, Width = 432, Height = 48, Text = "ABYSS SIGNAL", Font = new Font("Segoe UI", 24, FontStyle.Bold) });
            Controls.Add(new Label { Left = 24, Top = 131, Width = 432, Height = 23, Text = "Trusted update catalog (HTTPS or local file)" });
            Controls.AddRange(new Control[] { status, progressBar, feed, play, update });
            StyleAction(play, true);
            StyleAction(update, false);
            feed.BackColor = Color.FromArgb(15, 45, 60);
            feed.ForeColor = Color.FromArgb(220, 244, 248);
            if (File.Exists(FeedFile)) feed.Text = File.ReadAllText(FeedFile).Trim();
            FormClosing += (_, args) =>
            {
                if (!play.Enabled) args.Cancel = true;
            };
            play.Click += (_, __) =>
            {
                try
                {
                    OpenLauncher();
                    Close();
                }
                catch (Exception error) { status.Text = error.Message; }
            };
            update.Click += async (_, __) => await Check();
            Shown += async (_, __) => await Check();
        }

        private async Task Check()
        {
            string source = feed.Text.Trim();
            update.Enabled = false;
            play.Enabled = false;
            try
            {
                if (source.Length == 0)
                {
                    if (File.Exists(FeedFile)) File.Delete(FeedFile);
                    status.Text = "Preview " + Latest() + " installed. No update source is configured.";
                    return;
                }
                SourceUri(source);
                File.WriteAllText(FeedFile, source);
                status.Text = "Checking for updates…";
                int previous = Latest();
                progressBar.Visible = true;
                var report = new Progress<Tuple<int, string>>(item =>
                {
                    progressBar.Style = item.Item1 < 0 ? ProgressBarStyle.Marquee : ProgressBarStyle.Continuous;
                    if (item.Item1 >= 0) progressBar.Value = item.Item1;
                    status.Text = item.Item2;
                });
                await Task.Run(() => TidraSetup.Update(source,
                    (percent, message) => ((IProgress<Tuple<int, string>>)report).Report(Tuple.Create(percent, message))));
                status.Text = Latest() > previous ? "Updated to Preview " + Latest() + "." : "Preview " + Latest() + " is up to date.";
            }
            catch (Exception error) { status.Text = "Update failed. Preview " + Latest() + " is available. " + error.Message; }
            finally { if (!IsDisposed) { progressBar.Visible = false; update.Enabled = true; play.Enabled = true; } }
        }
    }
}















