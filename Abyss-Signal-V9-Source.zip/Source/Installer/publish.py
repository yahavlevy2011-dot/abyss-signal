"""Build the runtime payload and catalog from a TIDRA release archive."""
import argparse
import hashlib
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument("version", type=int)
parser.add_argument("release", type=Path)
parser.add_argument("destination", type=Path)
args = parser.parse_args()
if args.version < 1:
    parser.error("version must be positive")

args.destination.mkdir(parents=True, exist_ok=True)
name = f"TIDRA-Preview{args.version}-Runtime.zip"
payload = args.destination / name
temporary = payload.with_suffix(".tmp")
skip = {"MANIFEST_SHA256.json", "MODEL_SHA256.txt", "START_HERE.cmd"}
with zipfile.ZipFile(args.release) as release, zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as package:
    for entry in release.namelist():
        if entry in skip or entry.startswith(("Source/", "Nitrox Logs/", "screenshots/")):
            continue
        package.writestr(entry, release.read(entry))
temporary.replace(payload)

digest = hashlib.sha256(payload.read_bytes()).hexdigest()
catalog = args.destination / "catalog.txt"
pending_catalog = catalog.with_suffix(".tmp")
pending_catalog.write_text(f"{args.version}\n{name}\n{digest}\n", encoding="ascii")
pending_catalog.replace(catalog)
print(catalog.resolve())
