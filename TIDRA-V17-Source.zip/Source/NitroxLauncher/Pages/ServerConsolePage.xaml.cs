using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using NitroxLauncher.Models;
using NitroxLauncher.Models.Events;
using dnlib.DotNet;

namespace NitroxLauncher.Pages
{
    public partial class ServerConsolePage : PageBase
    {
        private readonly List<string> commandLinesHistory = new();
        private readonly StringBuilder serverOutput = new("");
        private string commandInputText;
        private int commandHistoryIndex;
        private string[] gameItemNames = Array.Empty<string>();
        private static readonly string[] terminalCommands = { "give", "gamemode", "help", "list", "save", "start", "stop" };
        public List<string> GiveSuggestions { get; private set; } = new();

        public string ServerStatus => LauncherLogic.Server.StatusLabel + "  /  " +
            (LauncherLogic.Server.ActiveWorld ?? "Default world");
        public string Roster { get; private set; } = "Waiting for server…";

        public string ServerOutput
        {
            get => serverOutput.ToString();
            set
            {
                serverOutput.AppendLine(value);
                if (serverOutput.Length > 48000)
                {
                    serverOutput.Remove(0, serverOutput.Length - 40000);
                }
                OnPropertyChanged();
                Dispatcher?.BeginInvoke(new Action(() => ConsoleWindowScrollView.ScrollToEnd()));
            }
        }

        public string CommandInputText
        {
            get => commandInputText;
            set
            {
                commandInputText = value;
                OnPropertyChanged();
                RefreshGiveSuggestions();
            }
        }

        public int CommandHistoryIndex
        {
            get => commandHistoryIndex;
            set
            {
                commandHistoryIndex = Math.Min(Math.Max(value, 0), commandLinesHistory.Count);
                if (commandHistoryIndex >= commandLinesHistory.Count)
                {
                    // Out of bounds index means command history is disabled
                    CommandInputText = string.Empty;
                }
                else
                {
                    CommandInputText = commandLinesHistory[commandHistoryIndex];
                    // Move cursor at the end of the text
                    CommandInput.SelectionStart = CommandInputText.Length;
                    CommandInput.SelectionLength = 0;
                }

                OnPropertyChanged();
            }
        }

        public ServerConsolePage()
        {
            InitializeComponent();

            LauncherLogic.Server.ServerStarted += ServerStarted;
            LauncherLogic.Server.ServerDataReceived += ServerDataReceived;

            DispatcherTimer telemetry = new() { Interval = TimeSpan.FromSeconds(3) };
            telemetry.Tick += (_, _) =>
            {
                OnPropertyChanged(nameof(ServerStatus));
                if (LauncherLogic.Server.IsListening)
                {
                    LauncherLogic.Server.SendServerCommand("list --tidra-roster");
                }
            };
            Unloaded += (_, _) => telemetry.Stop();

            Loaded += (sender, args) =>
            {
                LoadGameItemNames();
                RefreshGiveSuggestions();
                telemetry.Start();
                Roster = LauncherLogic.Server.PlayerRoster ?? "Waiting for server…";
                OnPropertyChanged(nameof(Roster));
                OnPropertyChanged(nameof(ServerStatus));
                if (LauncherLogic.Server.IsListening)
                {
                    LauncherLogic.Server.SendServerCommand("list --tidra-roster");
                }
                CommandInput.Focus();
            };
        }

        private void LoadGameItemNames()
        {
            try
            {
                string gamePath = LauncherLogic.Config?.SubnauticaPath;
                string assembly = Path.Combine(gamePath ?? "", "Subnautica_Data", "Managed", "Assembly-CSharp.dll");
                if (!File.Exists(assembly)) return;
                using ModuleDefMD module = ModuleDefMD.Load(assembly);
                TypeDef techType = module.Find("TechType", false);
                if (techType == null) return;
                gameItemNames = techType.Fields.Where(field => field.IsLiteral && field.Name != "value__")
                    .Select(field => field.Name.String).OrderBy(name => name, StringComparer.OrdinalIgnoreCase).ToArray();
            }
            catch (Exception ex)
            {
                Log.Warn($"Could not load game item names for terminal completion: {ex.Message}");
            }
        }

        private void RefreshGiveSuggestions()
        {
            string text = commandInputText?.TrimStart() ?? "";
            if (text.StartsWith("/give ", StringComparison.OrdinalIgnoreCase))
            {
                string prefix = text.Substring(6).Trim();
                GiveSuggestions = prefix.Length > 0 && prefix.IndexOf(' ') < 0
                    ? gameItemNames.Where(name => name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).Take(8).ToList()
                    : new List<string>();
            }
            else if (text.StartsWith("/gamemode ", StringComparison.OrdinalIgnoreCase))
            {
                string prefix = text.Substring(10).Trim();
                GiveSuggestions = Enum.GetNames(typeof(NitroxModel.Server.ServerGameMode))
                    .Where(name => name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            else if (text.StartsWith("/") && text.IndexOf(' ') < 0)
            {
                string prefix = text.Substring(1);
                GiveSuggestions = terminalCommands.Where(name => name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            else
            {
                GiveSuggestions = new List<string>();
            }
            OnPropertyChanged(nameof(GiveSuggestions));
            if (GiveSuggestionsList != null)
                GiveSuggestionsList.Visibility = GiveSuggestions.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void GiveSuggestions_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (GiveSuggestionsList.SelectedItem is string item)
            {
                CompleteSuggestion(item);
                CommandInput.CaretIndex = CommandInputText.Length;
                CommandInput.Focus();
            }
        }

        private void CompleteSuggestion(string item)
        {
            string text = commandInputText?.TrimStart() ?? "";
            string command = text.StartsWith("/give ", StringComparison.OrdinalIgnoreCase) ? "/give " :
                text.StartsWith("/gamemode ", StringComparison.OrdinalIgnoreCase) ? "/gamemode " : null;
            CommandInputText = command != null ? command + item : "/" + item + " ";
        }

        private void ServerStarted(object sender, ServerStartEventArgs e)
        {
            serverOutput.Clear();
            Roster = "Waiting for server…";
            OnPropertyChanged(nameof(Roster));
            OnPropertyChanged(nameof(ServerOutput));
        }

        private void ServerDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (e.Data == null)
            {
                return;
            }

            Dispatcher.BeginInvoke(new Action(() =>
            {
                const string prefix = "TIDRA_ROSTER ";
                if (e.Data.StartsWith(prefix, StringComparison.Ordinal))
                {
                    Roster = LauncherLogic.Server.PlayerRoster;
                    OnPropertyChanged(nameof(Roster));
                    return;
                }

                ServerOutput = e.Data;
            }));
        }

        private void SendCommandInputToServer()
        {
            if (string.IsNullOrWhiteSpace(CommandInputText))
            {
                return;
            }

            if (!LauncherLogic.Server.IsListening)
            {
                ServerOutput = "TIDRA: start the server before sending commands.";
                return;
            }

            ServerOutput = "> " + CommandInputText;
            string serverCommand = CommandInputText.TrimStart();
            if (serverCommand.StartsWith("/")) serverCommand = serverCommand.Substring(1);
            if (string.IsNullOrWhiteSpace(serverCommand)) return;
            LauncherLogic.Server.SendServerCommand(serverCommand);

            // Deduplication of command history
            if (!string.IsNullOrWhiteSpace(CommandInputText) && CommandInputText != commandLinesHistory.LastOrDefault())
            {
                commandLinesHistory.Add(CommandInputText);
            }

            HideCommandHistory();
        }

        private void HideCommandHistory()
        {
            CommandHistoryIndex = commandLinesHistory.Count;
        }

        private void CommandButton_OnClick(object sender, RoutedEventArgs e)
        {
            SendCommandInputToServer();
        }

        private void StartWorld_Click(object sender, RoutedEventArgs e)
        {
            ServerOutput = "> start";
            LauncherLogic.Server.SendServerCommand("start");
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            ServerOutput = "> save";
            LauncherLogic.Server.SendServerCommand("save");
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            // Suggest referencing NitroxServer.ConsoleCommands.ExitCommand.name, but the class is internal
            LauncherLogic.Server.SendServerCommand("stop");
            commandLinesHistory.Add("stop");
            HideCommandHistory();
        }

        private void CommandLine_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;

            switch (e.Key)
            {
                case Key.Enter:
                    SendCommandInputToServer();
                    break;

                case Key.Escape:
                    HideCommandHistory();
                    break;

                case Key.Up:
                    CommandHistoryIndex--;
                    break;

                case Key.Down:
                    CommandHistoryIndex++;
                    break;

                case Key.Tab when GiveSuggestions.Count > 0:
                    CompleteSuggestion(GiveSuggestions[0]);
                    CommandInput.CaretIndex = CommandInputText.Length;
                    break;

                default:
                    e.Handled = false;
                    break;
            }
        }
    }
}



