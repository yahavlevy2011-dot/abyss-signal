using NitroxClient.GameLogic;
using NitroxModel.Core;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    public class AnimationSender : MonoBehaviour
    {
        private LocalPlayer localPlayer;

        AnimChangeState lastUnderwaterState = AnimChangeState.UNSET;
        private AnimChangeState lastPdaState = AnimChangeState.UNSET;
        private float nextStateRefresh;
        private AnimChangeState lastBuilderState = AnimChangeState.UNSET;
        private static readonly System.Reflection.FieldInfo builderConstructing = typeof(BuilderTool).GetField("isConstructing",
            System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public);
        private AnimChangeState lastScannerState = AnimChangeState.UNSET;
        private AnimChangeState lastLaserCutterState = AnimChangeState.UNSET;
        private AnimChangeState lastSeaglideState = AnimChangeState.UNSET;
        private static readonly System.Reflection.FieldInfo laserCutterPlaying = typeof(LaserCutter).GetField("fxIsPlaying",
            System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
        private AnimChangeState lastFlashlightState = AnimChangeState.UNSET;
        private AnimChangeState lastWelderState = AnimChangeState.UNSET;
        private static readonly System.Reflection.FieldInfo welderPlaying = typeof(Welder).GetField("fxIsPlaying",
            System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
        private AnimChangeState lastExtinguisherState = AnimChangeState.UNSET;
        private static readonly System.Reflection.FieldInfo extinguisherPlaying = typeof(FireExtinguisher).GetField("fxIsPlaying", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic);

        public void Awake()
        {
            localPlayer = NitroxServiceLocator.LocateService<LocalPlayer>();
        }

        public void Update()
        {
            if (!Player.main) return;
            bool refresh = Time.unscaledTime >= nextStateRefresh;
            if (refresh) nextStateRefresh = Time.unscaledTime + 2f;
            AnimChangeState underwaterState = (AnimChangeState)(Player.main.IsSwimming() ? 1 : 0);
            if (refresh || lastUnderwaterState != underwaterState)
            {
                localPlayer.AnimationChange(AnimChangeType.UNDERWATER, underwaterState);
                lastUnderwaterState = underwaterState;
            }
            PDA pda = Player.main.GetPDA();
            AnimChangeState pdaState = pda && pda.isInUse ? AnimChangeState.ON : AnimChangeState.OFF;
            if (refresh || lastPdaState != pdaState)
            {
                localPlayer.AnimationChange(AnimChangeType.PDA, pdaState);
                lastPdaState = pdaState;
            }
            PlayerTool tool = Inventory.main ? Inventory.main.GetHeldTool() : null;
            if (refresh && tool)
            {
                localPlayer.BroadcastHeldItemChanged(NitroxEntity.GetId(tool.gameObject),
                    NitroxModel.Packets.PlayerHeldItemChanged.ChangeType.DRAW_AS_TOOL, null);
            }

            FireExtinguisher extinguisher = tool as FireExtinguisher;
            FlashLight flashlight = tool as FlashLight;
            Welder welder = tool as Welder;
            BuilderTool builder = tool as BuilderTool;
            SendToolState(AnimChangeType.BUILDER, builder && builderConstructing != null && (bool)builderConstructing.GetValue(builder),
                ref lastBuilderState, refresh);
            ScannerTool scanner = tool as ScannerTool;
            LaserCutter cutter = tool as LaserCutter;
            Seaglide seaglide = tool as Seaglide;
            ToggleLights lights = flashlight ? flashlight.toggleLights : seaglide ? seaglide.toggleLights : null;
            SendToolState(AnimChangeType.SCANNER, scanner && scanner.scanBeam && scanner.scanBeam.activeSelf,
                ref lastScannerState, refresh);
            SendToolState(AnimChangeType.LASER_CUTTER, cutter && laserCutterPlaying != null && (bool)laserCutterPlaying.GetValue(cutter),
                ref lastLaserCutterState, refresh);
            SendToolState(AnimChangeType.SEAGLIDE, seaglide && seaglide.trailFX && seaglide.trailFX.isEmitting,
                ref lastSeaglideState, refresh);
            SendToolState(AnimChangeType.FLASHLIGHT, lights && lights.GetLightsActive(),
                ref lastFlashlightState, refresh);
            SendToolState(AnimChangeType.WELDER, welder && welderPlaying != null && (bool)welderPlaying.GetValue(welder),
                ref lastWelderState, refresh);
            bool spraying = extinguisher && extinguisherPlaying != null && (bool)extinguisherPlaying.GetValue(extinguisher);
            AnimChangeState sprayState = spraying ? AnimChangeState.ON : AnimChangeState.OFF;
            if (refresh || lastExtinguisherState != sprayState)
            {
                localPlayer.AnimationChange(AnimChangeType.EXTINGUISHER, sprayState);
                lastExtinguisherState = sprayState;
            }
        }

        private void SendToolState(AnimChangeType type, bool active, ref AnimChangeState previous, bool refresh)
        {
            AnimChangeState state = active ? AnimChangeState.ON : AnimChangeState.OFF;
            if (refresh || state != previous)
            {
                localPlayer.AnimationChange(type, state);
                previous = state;
            }
        }
    }

    public enum AnimChangeState
    {
        OFF,
        ON,
        UNSET
    }

    public enum AnimChangeType
    {
        UNDERWATER,
        BENCH,
        PDA,
        EXTINGUISHER,
        FLASHLIGHT,
        WELDER,
        SCANNER,
        LASER_CUTTER,
        SEAGLIDE,
        BUILDER
    }
}



