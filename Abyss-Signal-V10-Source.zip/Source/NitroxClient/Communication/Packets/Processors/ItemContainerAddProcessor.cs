using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.GameLogic;
using NitroxClient.GameLogic.Containers;
using NitroxClient.GameLogic.Helper;
using NitroxClient.MonoBehaviours;
using NitroxModel.DataStructures.GameLogic;
using NitroxModel.Packets;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors
{
    public class ItemContainerAddProcessor : ClientPacketProcessor<ItemContainerAdd>
    {
        private readonly ItemContainers itemContainer;
        private readonly Entities entities;

        public ItemContainerAddProcessor(ItemContainers itemContainer, Entities entities)
        {
            this.itemContainer = itemContainer;
            this.entities = entities;
        }

        public override void Process(ItemContainerAdd packet)
        {
            ItemData itemData = packet.ItemData;
            GameObject item = SerializationHelper.GetGameObject(itemData.SerializedData);
            // Replace the visible world copy before its ID is rebound to the inventory copy.
            if (entities.WasSpawnedByServer(itemData.ItemId) &&
                NitroxEntity.TryGetObjectFrom(itemData.ItemId, out GameObject worldCopy) && worldCopy != item)
            {
                worldCopy.SetActive(false);
                Object.Destroy(worldCopy);
                entities.RemoveEntity(itemData.ItemId);
            }
            NitroxEntity.SetNewId(item, itemData.ItemId);

            itemContainer.AddItem(item, itemData.ContainerId);

            ContainerAddItemPostProcessor postProcessor = ContainerAddItemPostProcessor.From(item);
            postProcessor.process(item, itemData);
        }
    }
}
