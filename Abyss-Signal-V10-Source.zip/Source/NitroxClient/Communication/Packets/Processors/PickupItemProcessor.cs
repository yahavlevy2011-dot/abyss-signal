using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.GameLogic;
using NitroxClient.MonoBehaviours;
using NitroxClient.GameLogic.PlayerLogic;
using System.Linq;
using NitroxModel.DataStructures.Util;
using NitroxModel.Packets;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors
{
    public class PickupItemProcessor : ClientPacketProcessor<PickupItem>
    {
        private readonly Entities entities;

        public PickupItemProcessor(Entities entities)
        {
            this.entities = entities;
        }

        public override void Process(PickupItem pickup)
        {
            Optional<GameObject> opGameObject = NitroxEntity.GetObjectFrom(pickup.Id);
            if (opGameObject.HasValue &&
                !opGameObject.Value.GetComponentInParent<RemotePlayerIdentifier>(true) &&
                (!Inventory.main || !Inventory.main.container.Any(item => item.item.gameObject == opGameObject.Value)))
            {
                opGameObject.Value.SetActive(false);
                Object.Destroy(opGameObject.Value);
            }
            entities.RemoveEntity(pickup.Id);
        }
    }
}

