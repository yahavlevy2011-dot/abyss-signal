﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace NitroxLauncher.Models
{
    public abstract class PageBase : Page, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Opens default browser with a specific link
        /// </summary>
        protected void OnRequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            e.Handled = true;
            Uri link = e.Uri;
            if (link == null || !link.IsAbsoluteUri || link.Scheme != Uri.UriSchemeHttps ||
                !string.IsNullOrEmpty(link.UserInfo))
            {
                MessageBox.Show("This link is not a valid HTTPS address.", "TIDRA");
                return;
            }
            try
            {
                Process.Start(new ProcessStartInfo(link.AbsoluteUri) { UseShellExecute = true });
            }
            catch (Exception error) when (error is Win32Exception || error is InvalidOperationException)
            {
                MessageBox.Show("The browser could not be opened. Check your default browser settings.", "TIDRA");
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
