﻿using NitroxModel.DataStructures.GameLogic.Entities.Metadata;
using UnityEngine;
using NitroxClient.Communication.Abstract;
using NitroxModel.Core;
using NitroxModel.Packets;

namespace NitroxClient.GameLogic.Spawning.Metadata
{
    public class SealedDoorMetadataProcessor : GenericEntityMetadataProcessor<SealedDoorMetadata>
    {
        public override void ProcessMetadata(GameObject gameObject, SealedDoorMetadata metadata)
        {
            ApplyOne(gameObject, metadata);
            if (metadata.Sealed) return;
            // Wreck prefabs can contain coincident sealed faces. Open each
            // native face so a second collider does not block the passage.
            foreach (Sealed sibling in Object.FindObjectsOfType<Sealed>())
            {
                if (sibling.gameObject == gameObject || !sibling._sealed ||
                    sibling.name != gameObject.name ||
                    (sibling.transform.position - gameObject.transform.position).sqrMagnitude > 0.02f * 0.02f)
                    continue;
                ApplyOne(sibling.gameObject, metadata);
            }
        }

        private static void ApplyOne(GameObject gameObject, SealedDoorMetadata metadata)
        {
            Log.Info($"Received door metadata change for {gameObject.name} with data of {metadata}");

            Sealed door = gameObject.GetComponent<Sealed>();
            if (!door) return;
            // Setting the flags alone skips the native opened event, leaving the
            // guest's door mesh/collider closed even when the cut is complete.
            IPacketSender sender = NitroxServiceLocator.LocateService<IPacketSender>();
            using (sender.Suppress<EntityMetadataUpdate>())
            using (sender.Suppress<SealedDoorStateChanged>())
            {
                if (door._sealed && !metadata.Sealed)
                {
                    door.Weld(Mathf.Max(0f, door.maxOpenedAmount - door.openedAmount));
                }
                door._sealed = metadata.Sealed;
                door.openedAmount = Mathf.Clamp(metadata.OpenedAmount, 0f, door.maxOpenedAmount);
            }

            LaserCutObject laseredObject = gameObject.GetComponent<LaserCutObject>();

            if (laseredObject && door._sealed)
            {
                laseredObject.lastCutValue = door.openedAmount;
                laseredObject.ActivateFX();
            }
        }
    }
}
