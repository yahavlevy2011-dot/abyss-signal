using NitroxModel.DataStructures.GameLogic.Entities.Metadata;
using NitroxClient.Communication.Abstract;
using NitroxModel.Core;
using NitroxModel.Packets;
using UnityEngine;

namespace NitroxClient.GameLogic.Spawning.Metadata
{
    class StarshipDoorMetadataProcessor : GenericEntityMetadataProcessor<StarshipDoorMetadata>
    {
        public override void ProcessMetadata(GameObject gameObject, StarshipDoorMetadata metadata)
        {
            if (!gameObject.TryGetComponent(out StarshipDoor starshipDoor))
            {
                return;
            }
            using (NitroxServiceLocator.LocateService<IPacketSender>().Suppress<EntityMetadataUpdate>())
            {
            // Apply the game's toggle path so its animation and interaction
            // state follow the replicated open flag as well.
            if (starshipDoor.doorOpen != metadata.DoorOpen)
            {
                starshipDoor.UnlockDoor();
                starshipDoor.OnDoorToggle();
                starshipDoor.doorOpen = metadata.DoorOpen;
            }
            starshipDoor.doorLocked = metadata.DoorLocked;
            if (metadata.DoorLocked)
            {
                starshipDoor.LockDoor();
            }
            else
            {
                starshipDoor.UnlockDoor();
            }
            }
        }
    }
}

