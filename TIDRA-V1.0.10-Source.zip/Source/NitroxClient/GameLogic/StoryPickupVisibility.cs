using UnityEngine;

namespace NitroxClient.GameLogic
{
    public static class StoryPickupVisibility
    {
        public static void RemoveCollected(GameObject root = null, string key = null)
        {
            // A PDA's story key is stable even when its nested object has no
            // shared NitroxId. The server already persists and synchronizes
            // these log entries, including for players joining later.
            StoryHandTarget[] targets = root
                ? root.GetComponentsInChildren<StoryHandTarget>(true)
                : Object.FindObjectsOfType<StoryHandTarget>();
            foreach (StoryHandTarget target in targets)
            {
                if (!target || target.goal == null || target.goal.goalType != Story.GoalType.PDA ||
                    string.IsNullOrEmpty(target.goal.key) || (key != null && target.goal.key != key) ||
                    !PDALog.entries.ContainsKey(target.goal.key) || !target.destroyGameObject) continue;
                GameObject pickup = target.destroyGameObject;
                if (Inventory.main && pickup.transform.IsChildOf(Inventory.main.container.tr)) continue;
                pickup.SetActive(false);
                Object.Destroy(pickup);
            }
        }
    }
}
