using System;
using System.Text.RegularExpressions;
using NitroxClient.MonoBehaviours;
using NitroxClient.GameLogic.PlayerLogic;
using NitroxClient.Unity.Helper;
using NitroxModel.DataStructures;
using NitroxModel.DataStructures.Util;
using UnityEngine;

namespace NitroxClient.GameLogic.Helper
{
    public class InventoryContainerHelper
    {

        public static Optional<ItemsContainer> TryGetContainerByOwner(GameObject owner)
        {
            StorageContainer directStorage = owner.GetComponent<StorageContainer>();
            if (directStorage)
            {
                return Optional.Of(directStorage.container);
            }
            SeamothStorageContainer seamothStorageContainer = owner.GetComponent<SeamothStorageContainer>();
            if (seamothStorageContainer)
            {
                return Optional.Of(seamothStorageContainer.container);
            }
            StorageContainer storageContainer = owner.GetComponentInChildren<StorageContainer>(true);
            if (storageContainer)
            {
                return Optional.Of(storageContainer.container);
            }
            BaseBioReactor baseBioReactor = owner.GetComponentInChildren<BaseBioReactor>();
            if (baseBioReactor)
            {
                return Optional.Of(baseBioReactor.container);
            }
            if (owner.name == "Player")
            {
                return Optional.Of(Inventory.Get().container);
            }
            RemotePlayerIdentifier remote = owner.GetComponent<RemotePlayerIdentifier>();
            if (remote && remote.RemotePlayer != null)
            {
                return Optional.Of(remote.RemotePlayer.Inventory);
            }

            Log.Debug("Couldn't resolve container from gameObject: " + owner.name);

            return Optional.Empty;
        }


        public static NitroxId GetOwnerId(Transform ownerTransform)
        {
            StorageContainer nearestStorage = ownerTransform.GetComponentInParent<StorageContainer>();
            if (nearestStorage && NitroxEntity.TryGetEntityFrom(nearestStorage.gameObject, out NitroxEntity storageEntity))
            {
                return storageEntity.Id;
            }
            // Some prefab storage roots are siblings of their StorageContainer.
            // Resolve through the enclosing object only when it contains one
            // storage component, so adjacent lockers cannot share an owner ID.
            if (ownerTransform.parent)
            {
                StorageContainer[] siblings = ownerTransform.parent.GetComponentsInChildren<StorageContainer>(true);
                if (siblings.Length == 1 && NitroxEntity.TryGetEntityFrom(siblings[0].gameObject, out storageEntity))
                {
                    return storageEntity.Id;
                }
            }
            if (Regex.IsMatch(ownerTransform.gameObject.name, @"Locker0([0-9])StorageRoot$", RegexOptions.IgnoreCase))
            {
                string lockerId = ownerTransform.gameObject.name.Substring(7, 1);
                GameObject locker = ownerTransform.parent.gameObject.FindChild("submarine_locker_01_0" + lockerId);
                if (!locker)
                {
                    throw new Exception("Could not find Locker Object: submarine_locker_01_0" + lockerId);
                }
                StorageContainer storageContainer = locker.GetComponentInChildren<StorageContainer>();
                if (!storageContainer)
                {
                    throw new Exception($"Could not find {nameof(StorageContainer)} From Object: submarine_locker_01_0{lockerId}");
                }

                return NitroxEntity.GetId(storageContainer.gameObject);
            }
            if (ownerTransform.parent.name.StartsWith("EscapePod"))
            {
                StorageContainer storageContainer = ownerTransform.parent.gameObject.RequireComponentInChildren<StorageContainer>();
                return NitroxEntity.GetId(storageContainer.gameObject);
            }

            return NitroxEntity.GetId(ownerTransform.parent.gameObject);
        }
    }
}
