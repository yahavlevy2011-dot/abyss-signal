﻿using NitroxClient.Communication.Abstract;
using NitroxModel.DataStructures;
using NitroxModel.Packets;
using NitroxClient.MonoBehaviours;
using NitroxModel_Subnautica.DataStructures;

namespace NitroxClient.GameLogic
{
    public class Interior
    {
        private readonly IPacketSender packetSender;

        public Interior(IPacketSender packetSender)
        {
            this.packetSender = packetSender;
        }

        public void OpenableStateChanged(NitroxId id, bool isOpen, float animationDuration, bool isLocker = false, int nativeKind = 0)
        {
            if (id == null || packetSender.IsPacketSuppressed(typeof(OpenableStateChanged))) return;
            BroadcastOpenableState(id, isOpen, animationDuration, isLocker, nativeKind);
        }

        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        private void BroadcastOpenableState(NitroxId id, bool isOpen, float animationDuration, bool isLocker, int nativeKind)
        {
            var target = NitroxEntity.GetObjectFrom(id);
            if (!target.HasValue || !target.Value) return;
            NitroxId parentId = null;
            var path = new System.Collections.Generic.Stack<int>();
            if (target.HasValue)
            {
                var child = target.Value.transform;
                while (child.parent && path.Count < 32)
                {
                    path.Push(child.GetSiblingIndex());
                    child = child.parent;
                    if (NitroxEntity.TryGetEntityFrom(child.gameObject, out NitroxEntity parent))
                    { parentId = parent.Id; break; }
                }
            }
            OpenableStateChanged stateChange = new OpenableStateChanged(id, isOpen, animationDuration,
                target.HasValue ? target.Value.transform.position.ToDto() : null,
                target.HasValue ? target.Value.name : null, isLocker, nativeKind, parentId,
                parentId != null ? path.ToArray() : null);
            packetSender.Send(stateChange);
        }
    }
}
