using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using NitroxClient.GameLogic.PlayerLogic;
using NitroxClient.GameLogic.PlayerLogic.PlayerModel;
using NitroxClient.GameLogic.PlayerLogic.PlayerModel.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxClient.Unity.Helper;
using NitroxModel.MultiplayerSession;
using UnityEngine;
using UWE;
using Object = UnityEngine.Object;

namespace NitroxClient.GameLogic
{
    public class RemotePlayer : INitroxPlayer
    {
        private static readonly int animatorPlayerIn = Animator.StringToHash("player_in");

        private readonly PlayerModelManager playerModelManager;
        private readonly HashSet<TechType> equipment;
        private GameObject remotePdaVisual;
        private Vector3 movementTarget;
        private Transform movementReference;
        private Vector3 relativeMovementTarget;
        private Quaternion relativeRotationTarget;
        private Quaternion rotationTarget;
        private float maxCorrectionSpeed;
        private float movementExpiresAt = float.PositiveInfinity;
        private float lastPilotMovementAt = float.NegativeInfinity;
        public bool CinematicMovement { get; private set; }
        public bool ExtinguisherSpraying { get; private set; }
        public bool FlashlightOn { get; private set; }
        public bool WelderActive { get; private set; }
        public bool ScannerActive { get; private set; }
        public GameObject ScannerTarget { get; set; }
        public bool LaserCutterActive { get; private set; }
        public bool SeaglideActive { get; private set; }
        public bool BuilderActive { get; private set; }

        public PlayerContext PlayerContext { get; }
        public GameObject Body { get; }
        public GameObject PlayerModel { get; }
        public Rigidbody RigidBody { get; }
        public CapsuleCollider Collider { get; private set; }
        public ArmsController ArmsController { get; }
        public AnimationController AnimationController { get; }
        public ItemsContainer Inventory { get; }
        public Transform ItemAttachPoint { get; }

        public ushort PlayerId => PlayerContext.PlayerId;
        public string PlayerName => PlayerContext.PlayerName;
        public PlayerSettings PlayerSettings => PlayerContext.PlayerSettings;

        public Vehicle Vehicle { get; private set; }
        public SubRoot SubRoot { get; private set; }
        public EscapePod EscapePod { get; private set; }
        public PilotingChair PilotingChair { get; private set; }

        public readonly Event<RemotePlayer> PlayerDeathEvent = new();

        public readonly Event<RemotePlayer> PlayerDisconnectEvent = new();

        public RemotePlayer(GameObject playerBody, PlayerContext playerContext, List<TechType> equippedTechTypes, List<Pickupable> inventoryItems, PlayerModelManager modelManager)
        {
            PlayerContext = playerContext;

            Body = playerBody;
            Body.name = PlayerName;

            equipment = new HashSet<TechType>(equippedTechTypes);

            RigidBody = Body.AddComponent<Rigidbody>();
            RigidBody.useGravity = false;
            RigidBody.interpolation = RigidbodyInterpolation.Interpolate;

            NitroxEntity.SetNewId(Body, playerContext.PlayerNitroxId);

            // Get player
            PlayerModel = Body.RequireGameObject("player_view");
            // Move variables to keep player animations from mirroring and for identification
            ArmsController = PlayerModel.GetComponent<ArmsController>();
            ArmsController.smoothSpeedUnderWater = 0;
            ArmsController.smoothSpeedAboveWater = 0;

            // ConditionRules has Player.Main based conditions from ArmsController
            PlayerModel.GetComponent<ConditionRules>().enabled = false;

            AnimationController = PlayerModel.AddComponent<AnimationController>();
            AnimationController.Initialize(this);

            Transform inventoryTransform = new GameObject("Inventory").transform;
            inventoryTransform.SetParent(Body.transform);
            Inventory = new ItemsContainer(6, 8, inventoryTransform, "NitroxInventoryStorage_" + PlayerName, null);
            foreach (Pickupable item in inventoryItems)
            {
                Inventory.UnsafeAdd(new InventoryItem(item));
                Log.Debug($"Added {item.name} to {playerContext.PlayerName}.");
            }

            ItemAttachPoint = PlayerModel.transform.Find(PlayerEquipmentConstants.ITEM_ATTACH_POINT_GAME_OBJECT_NAME);
            remotePdaVisual = RemotePdaVisual.Create(Body.transform);

            playerModelManager = modelManager;
            playerModelManager.AttachPing(this);
            playerModelManager.BeginApplyPlayerColor(this);
            playerModelManager.RegisterEquipmentVisibilityHandler(PlayerModel);
            UpdateEquipmentVisibility();
            SetupBody();
            SetupSkyAppliers();

            ErrorMessage.AddMessage($"{PlayerName} joined the game.");
        }

        public void Attach(Transform transform, bool keepWorldTransform = false)
        {
            Body.transform.SetParent(transform);

            if (!keepWorldTransform)
            {
                UWE.Utils.ZeroTransform(Body);
            }
            SkyEnvironmentChanged.Broadcast(Body, transform);
        }

        public void Detach()
        {
            Body.transform.SetParent(null);
            SkyEnvironmentChanged.Broadcast(Body, (GameObject)null);
        }

        public void UpdatePosition(Vector3 position, Vector3 velocity, Quaternion bodyRotation, Quaternion aimingRotation, bool cinematic = false)
        {
            // A walking snapshot can arrive just after a vehicle snapshot when
            // the sender crosses a piloting transition. Keep the remote body
            // seated while vehicle movement is still being received.
            if (!cinematic && (Vehicle || PilotingChair) && Time.unscaledTime - lastPilotMovementAt < 0.3f)
            {
                return;
            }

            Body.SetActive(true);

            // When receiving movement packets, a player can not be controlling a vehicle (they can walk through subroots though).
            SetVehicle(null);
            SetPilotingChair(null);
            if (CinematicMovement != cinematic)
            {
                CinematicMovement = cinematic;
                RigidBody.velocity = Vector3.zero;
                RigidBody.angularVelocity = Vector3.zero;
                RigidBody.isKinematic = cinematic || (SubRoot && !SubRoot.isBase);
            }
            // Keep the snapshot in the vessel frame so the target follows it between packets.
            movementReference = SubRoot && !SubRoot.isBase ? SubRoot.transform : null;
            if (movementReference)
            {
                // SetVehicle(null) can have just restored a dynamic Rigidbody
                // when the passenger left a smaller vehicle inside the Cyclops.
                // Reassert the presentation-only vessel-frame mode here.
                RigidBody.isKinematic = true;
                RigidBody.velocity = Vector3.zero;
                RigidBody.angularVelocity = Vector3.zero;
            }
            relativeMovementTarget = position;
            relativeRotationTarget = bodyRotation;
            // If in a subroot the position will be relative to the subroot
            if (SubRoot && !SubRoot.isBase)
            {
                Quaternion vehicleAngle = SubRoot.transform.rotation;
                position = vehicleAngle * position;
                position += SubRoot.transform.position;
                bodyRotation = vehicleAngle * bodyRotation;
                aimingRotation = vehicleAngle * aimingRotation;
            }
            // Project one snapshot ahead to reduce visible lag without changing network traffic.
            const float maxPredictionDistance = 0.5f;
            float interval = PlayerMovementBroadcaster.BROADCAST_INTERVAL;
            Vector3 prediction = movementReference || cinematic ? Vector3.zero : Vector3.ClampMagnitude(velocity * interval, maxPredictionDistance);
            // Keep the large-distance snap for actual relocations. Smooth normal
            // snapshots on the physics clock so a stalled frame cannot apply
            // an old correction velocity across multiple ticks.
            if ((position - RigidBody.position).sqrMagnitude > 20f * 20f)
            {
                RigidBody.position = position;
                RigidBody.velocity = Vector3.zero;
            }

            movementTarget = position + prediction;
            maxCorrectionSpeed = Mathf.Max(8f, velocity.magnitude * 2f);
            AnimationController.Velocity = velocity;
            movementExpiresAt = Time.unscaledTime + 0.25f;
            RigidBody.angularVelocity = Vector3.zero;
            rotationTarget = bodyRotation;

            AnimationController.AimingRotation = aimingRotation;
            AnimationController.UpdatePlayerAnimations = true;
        }

        internal void UpdateRemoteMovement()
        {
            if (Vehicle || PilotingChair)
            {
                CinematicMovement = false;
                KeepVehicleSeatAligned();
                return;
            }

            if (CinematicMovement)
            {
                // Native entry animation moves through its authored path. Local
                // collision response must not push its remote replica off it.
                RigidBody.isKinematic = true;
                float blend = 1f - Mathf.Exp(-20f * Time.fixedDeltaTime);
                Vector3 targetPosition = movementReference ? movementReference.TransformPoint(relativeMovementTarget) : movementTarget;
                Quaternion targetRotation = movementReference ? movementReference.rotation * relativeRotationTarget : rotationTarget;
                RigidBody.MovePosition(Vector3.Lerp(RigidBody.position, targetPosition, blend));
                RigidBody.MoveRotation(Quaternion.Slerp(RigidBody.rotation, targetRotation, blend));
                return;
            }

            // Remote passengers inside a moving Cyclops are visual replicas.
            // If their Rigidbody participates in local collision resolution,
            // a moving sub can impart a huge impulse and launch the avatar.
            // Keep them in the vessel's coordinate frame instead.
            if (movementReference && RigidBody.isKinematic)
            {
                const float vesselFrameBlend = 14f;
                float blend = 1f - Mathf.Exp(-vesselFrameBlend * Time.fixedDeltaTime);
                Body.transform.localPosition = Vector3.Lerp(Body.transform.localPosition, relativeMovementTarget, blend);
                Body.transform.localRotation = Quaternion.Slerp(Body.transform.localRotation, relativeRotationTarget, blend);
                return;
            }
            if (float.IsPositiveInfinity(movementExpiresAt) || RigidBody.isKinematic || Vehicle || PilotingChair)
            {
                return;
            }

            if (Time.unscaledTime >= movementExpiresAt)
            {
                movementExpiresAt = float.PositiveInfinity;
                RigidBody.velocity = Vector3.zero;
                AnimationController.Velocity = Vector3.zero;
                return;
            }

            if (movementReference)
            {
                movementTarget = movementReference.TransformPoint(relativeMovementTarget);
                rotationTarget = movementReference.rotation * relativeRotationTarget;
            }
            Vector3 correction = (movementTarget - RigidBody.position) / PlayerMovementBroadcaster.BROADCAST_INTERVAL;
            RigidBody.velocity = Vector3.ClampMagnitude(correction, maxCorrectionSpeed);
            RigidBody.MoveRotation(rotationTarget);
        }

        internal void KeepVehicleSeatAligned()
        {
            // The seat can move after the physics tick. Correct at both physics
            // and render time so interpolation cannot leave a remote pilot behind.
            Transform seat = Vehicle && Vehicle.playerPosition ? Vehicle.playerPosition.transform :
                PilotingChair && PilotingChair.sittingPosition ? PilotingChair.sittingPosition.transform : null;
            if (seat && Body.transform.parent == seat)
            {
                // Seat transforms are authored in the game prefabs. Correct the
                // full local pose, not only position, otherwise a stale rotation
                // or scale creates the sideways/stretching vehicle-pilot bug.
                Body.transform.localPosition = Vector3.zero;
                Body.transform.localRotation = Quaternion.identity;
                Body.transform.localScale = Vector3.one;
            }
        }

        public void SetPilotingChair(PilotingChair newPilotingChair)
        {
            if (newPilotingChair)
            {
                lastPilotMovementAt = Time.unscaledTime;
            }

            if (PilotingChair != newPilotingChair)
            {
                MultiplayerCyclops previousCyclops = PilotingChair
                    ? PilotingChair.GetComponentInParent<MultiplayerCyclops>() : null;
                PilotingChair = newPilotingChair;

                MultiplayerCyclops mpCyclops = null;

                // For unexpected and expected cases, for example when a player is driving a cyclops but the cyclops is destroyed
                if (!SubRoot)
                {
                    Log.Error("Player changed PilotingChair but is not in SubRoot!");
                }
                else
                {
                    mpCyclops = SubRoot.GetComponent<MultiplayerCyclops>();
                }

                if (PilotingChair)
                {
                    Attach(PilotingChair.sittingPosition.transform);
                    ArmsController.SetWorldIKTarget(PilotingChair.leftHandPlug, PilotingChair.rightHandPlug);

                    if (mpCyclops)
                    {
                        mpCyclops.CurrentPlayer = this;
                        mpCyclops.Enter();
                    }
                }
                else
                {
                    // The SubRoot reference has not changed, so SetSubRoot would
                    // leave the body parented to the helm seat after standing up.
                    if (SubRoot) Attach(SubRoot.transform, true);
                    else Detach();
                    ArmsController.SetWorldIKTarget(null, null);

                    MultiplayerCyclops departingCyclops = previousCyclops ? previousCyclops : mpCyclops;
                    if (departingCyclops)
                    {
                        departingCyclops.CurrentPlayer = null;
                        departingCyclops.Exit();
                    }
                }

                RigidBody.isKinematic = AnimationController["cyclops_steering"] = newPilotingChair != null;
            }
        }

        public void SetSubRoot(SubRoot newSubRoot)
        {
            if (SubRoot != newSubRoot)
            {
                if (newSubRoot)
                {
                    Attach(newSubRoot.transform, true);
                }
                else
                {
                    Detach();
                }

                SubRoot = newSubRoot;
                // Discard corrections expressed in the previous frame of
                // reference. Applying them after entering/leaving a hatch can
                // pull the avatar back through a wall until the next snapshot.
                movementExpiresAt = float.PositiveInfinity;
                movementReference = null;
                movementTarget = Body.transform.position;
                relativeMovementTarget = Body.transform.localPosition;
                relativeRotationTarget = Body.transform.localRotation;
                RigidBody.velocity = Vector3.zero;
                RigidBody.angularVelocity = Vector3.zero;
                RigidBody.isKinematic = CinematicMovement || (newSubRoot && !newSubRoot.isBase);
            }
        }

        public void SetEscapePod(EscapePod newEscapePod)
        {
            if (EscapePod != newEscapePod)
            {
                if (newEscapePod)
                {
                    Attach(newEscapePod.transform, true);
                }
                else
                {
                    Detach();
                }

                EscapePod = newEscapePod;
            }
        }

        public void SetVehicle(Vehicle newVehicle)
        {
            if (newVehicle)
            {
                lastPilotMovementAt = Time.unscaledTime;
            }

            if (Vehicle != newVehicle)
            {
                if (Vehicle)
                {
                    Vehicle.mainAnimator.SetBool(animatorPlayerIn, false);

                    Detach();
                    ArmsController.SetWorldIKTarget(null, null);
                    
                    MultiplayerVehicleControl previousControl = Vehicle.GetComponent<MultiplayerVehicleControl>();
                    if (previousControl) previousControl.Exit();
                }

                if (newVehicle)
                {
                    newVehicle.mainAnimator.SetBool(animatorPlayerIn, true);

                    Attach(newVehicle.playerPosition.transform);
                    // The remote avatar's arm IK is evaluated against a moving vehicle
                    // on a different physics tick. World-space hand plugs can pull the
                    // entire model away from its seat while the vehicle is corrected.
                    ArmsController.SetWorldIKTarget(null, null);

                    // From here, a basic issue can happen.
                    // When a vehicle is docked since we joined a game and another player undocks him before the local player does, no MultiplayerVehicleControl can be found on the vehicle because they are only created when receiving VehicleMovement packets
                    // Therefore we need to make sure that the MultiplayerVehicleControl component exists before using it
                    switch (newVehicle)
                    {
                        case SeaMoth:
                            MultiplayerSeaMoth seamothControl = newVehicle.gameObject.EnsureComponent<MultiplayerSeaMoth>();
                            if (!newVehicle.docked) seamothControl.Enter();
                            break;
                        case Exosuit:
                            MultiplayerExosuit exosuitControl = newVehicle.gameObject.EnsureComponent<MultiplayerExosuit>();
                            if (!newVehicle.docked) exosuitControl.Enter();
                            break;
                    }
                }

                RigidBody.isKinematic = newVehicle;

                Vehicle = newVehicle;
                KeepVehicleSeatAligned();

                AnimationController["in_seamoth"] = newVehicle is SeaMoth;
                AnimationController["in_exosuit"] = AnimationController["using_mechsuit"] = newVehicle is Exosuit;
            }
        }
        
        /// <summary>
        /// Drops the remote player, swimming where he is
        /// </summary>
        public void ResetStates()
        {
            CinematicMovement = false;
            ScannerTarget = null;
            SetVehicle(null);
            SetPilotingChair(null);
            SetSubRoot(null);
            RigidBody.isKinematic = false;
            RigidBody.velocity = Vector3.zero;
            RigidBody.angularVelocity = Vector3.zero;
            movementExpiresAt = float.PositiveInfinity;
            AnimationController.UpdatePlayerAnimations = true;
        }

        public void Destroy()
        {
            foreach (ScannerTool scanner in Body.GetComponentsInChildren<ScannerTool>(true))
            {
                if (!scanner.scanFX) continue;
                scanner.scanFX.RemoveOverlay();
                Object.Destroy(scanner.scanFX);
                scanner.scanFX = null;
            }
            ErrorMessage.AddMessage($"{PlayerName} left the game.");
            NitroxEntity.RemoveFrom(Body);
            Object.DestroyImmediate(Body);
        }

        public void UpdateAnimationAndCollider(AnimChangeType type, AnimChangeState state)
        {
            switch (type)
            {
                case AnimChangeType.EXTINGUISHER:
                    ExtinguisherSpraying = state == AnimChangeState.ON;
                    break;
                case AnimChangeType.FLASHLIGHT:
                    FlashlightOn = state == AnimChangeState.ON;
                    break;
                case AnimChangeType.WELDER:
                    WelderActive = state == AnimChangeState.ON;
                    break;
                case AnimChangeType.SCANNER:
                    ScannerActive = state == AnimChangeState.ON;
                    break;
                case AnimChangeType.LASER_CUTTER:
                    LaserCutterActive = state == AnimChangeState.ON;
                    break;
                case AnimChangeType.SEAGLIDE:
                    SeaglideActive = state == AnimChangeState.ON;
                    break;
                case AnimChangeType.BUILDER:
                    BuilderActive = state == AnimChangeState.ON;
                    break;
                case AnimChangeType.PDA:
                    bool open = state == AnimChangeState.ON;
                    AnimationController["using_pda"] = open;
                    if (remotePdaVisual) remotePdaVisual.SetActive(open);
                    break;
                case AnimChangeType.UNDERWATER:
                    AnimationController["is_underwater"] = state == AnimChangeState.ON;
                    break;
                case AnimChangeType.SURFACE_SWIM:
                    SafeAnimator.SetBool(ArmsController.GetComponent<Animator>(), "on_surface", state == AnimChangeState.ON);
                    break;
                case AnimChangeType.BENCH:
                    AnimationController["cinematics_enabled"] = state != AnimChangeState.UNSET;
                    AnimationController["bench_sit"] = state == AnimChangeState.ON;
                    AnimationController["bench_stand_up"] = state == AnimChangeState.OFF;
                    break;
            }

            AnimationController["using_tool"] = ExtinguisherSpraying || WelderActive || ScannerActive || LaserCutterActive || BuilderActive;

            // Change two parameters of the collider depending on the state of the player
            if (!Collider) return;

            if (AnimationController["is_underwater"])
            {
                Collider.center = new(0f, -0.3f, 0f);
                Collider.height = 0.5f;
            }
            else
            {
                Collider.center = new(0f, -0.8f, 0f);
                Collider.height = 1.5f;
            }
        }

        public void AddEquipment(TechType techType)
        {
            if (equipment.Contains(techType))
            {
                return;
            }

            equipment.Add(techType);

            UpdateEquipmentVisibility();
        }

        public void RemoveEquipment(TechType techType)
        {
            equipment.Remove(techType);
            UpdateEquipmentVisibility();
        }

        private void UpdateEquipmentVisibility()
        {
            playerModelManager.UpdateEquipmentVisibility(new ReadOnlyCollection<TechType>(equipment.ToList()));
        }
        
        /// <summary>
        /// Makes the RemotePlayer recognizable as an obstacle for buildings.
        /// </summary>
        private void SetupBody()
        {
            RemotePlayerIdentifier identifier = Body.AddComponent<RemotePlayerIdentifier>();
            identifier.RemotePlayer = this;
            
            if (Player.mainCollider is CapsuleCollider refCollider)
            {
                // This layer lets us have a collider as a trigger without preventing its detection as an obstacle
                Body.layer = LayerID.Useable;
                Collider = Body.AddComponent<CapsuleCollider>();
                
                Collider.center = Vector3.zero;
                Collider.radius = refCollider.radius;
                Collider.direction = refCollider.direction;
                Collider.contactOffset = refCollider.contactOffset;
                Collider.isTrigger = true;
            }
            else
            {
                Log.Warn("The main collider of the main Player couldn't be found or is not a CapsuleCollider. Collisions for the RemotePlayer won't be created");
            }
        }

        /// <summary>
        /// Allows the remote player model to have its lightings dynamicly adjusted
        /// </summary>
        private void SetupSkyAppliers()
        {
            // SkyAppliers apply the light effects of a lighting source on a set of renderers
            SkyApplier skyApplier = Body.AddComponent<SkyApplier>();
            skyApplier.anchorSky = Skies.Auto;
            skyApplier.emissiveFromPower = false;
            skyApplier.dynamic = true;
            skyApplier.renderers = Body.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        }
    }
}






