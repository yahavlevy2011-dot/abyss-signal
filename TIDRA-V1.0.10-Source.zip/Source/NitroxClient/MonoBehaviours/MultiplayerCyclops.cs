﻿using NitroxClient.GameLogic;
using NitroxModel.Helper;

namespace NitroxClient.MonoBehaviours
{
    class MultiplayerCyclops : MultiplayerVehicleControl
    {
        private ISubTurnHandler[] subTurnHandlers;
        private ISubThrottleHandler[] subThrottleHandlers;
        private float previousAbsYaw;
        private float lastRemoteTurnEffect;
        private float lastRemoteThrottleEffect;
        private bool wasThrottling;

        internal RemotePlayer CurrentPlayer { get; set; }

        protected override void Awake()
        {
            SubControl subControl = GetComponent<SubControl>();
            WheelYawSetter = value => subControl.steeringWheelYaw = value;
            WheelPitchSetter = value => subControl.steeringWheelPitch = value;
            
            subTurnHandlers = subControl.turnHandlers;
            subThrottleHandlers = subControl.throttleHandlers;
            base.Awake();
        }

        protected override void FixedUpdate()
        {
            base.FixedUpdate();
            if (CurrentPlayer != null)
            {
                // These values are set by the game code, but they do not seem to have any impact on animations.
                CurrentPlayer.AnimationController.SetFloat("cyclops_yaw", SmoothYaw.SmoothValue);
                CurrentPlayer.AnimationController.SetFloat("cyclops_pitch", SmoothPitch.SmoothValue);
            }
        }

        internal override void SetSteeringWheel(float yaw, float pitch)
        {
            base.SetSteeringWheel(yaw, pitch);

            ShipSide useShipSide = yaw > 0 ? ShipSide.Port : ShipSide.Starboard;
            yaw = UnityEngine.Mathf.Abs(yaw);
            if (yaw > .1f && yaw >= previousAbsYaw &&
                UnityEngine.Time.unscaledTime - lastRemoteTurnEffect >= 0.2f)
            {
                subTurnHandlers?.ForEach(turnHandler => turnHandler.OnSubTurn(useShipSide));
                lastRemoteTurnEffect = UnityEngine.Time.unscaledTime;
            }

            previousAbsYaw = yaw;
        }

        internal override void SetThrottle(bool isOn)
        {
            if (isOn && (!wasThrottling || UnityEngine.Time.unscaledTime - lastRemoteThrottleEffect >= 0.25f))
            {
                subThrottleHandlers?.ForEach(throttleHandlers => throttleHandlers.OnSubAppliedThrottle());
                lastRemoteThrottleEffect = UnityEngine.Time.unscaledTime;
            }
            wasThrottling = isOn;
        }

        public override void Exit()
        {
            wasThrottling = false;
            base.Exit();
        }
    }
}
