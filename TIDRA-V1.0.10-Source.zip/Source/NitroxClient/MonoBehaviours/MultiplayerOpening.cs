using System.Collections;
using NitroxClient.Communication.Abstract;
using NitroxModel.Core;
using NitroxModel.Packets;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    public static class MultiplayerOpening
    {
        public static EscapePod PlayingPod { get; private set; }
        private static uGUI_SceneIntro intro;
        private static TidraOpeningStatus status;
        private static bool waiting;
        private static bool votedReady;
        private static bool votedSkip;
        private static bool stopping;
        private static AvatarInputHandler blockedInput;

        public static void Receive(TidraOpeningStatus update)
        {
            if (waiting && (status == null || update.Phase >= status.Phase)) status = update;
        }

        public static IEnumerator PlayTogether(bool requested)
        {
            EscapePod pod = EscapePod.main;
            uGUI ui = uGUI.main;
            bool eligible = requested && Player.main && pod && Player.main.currentEscapePod == pod &&
                pod.introCinematic && pod.escapePodCinematicControl && ui && ui.intro && !ui.intro.showing;
            waiting = true;
            status = null;
            votedReady = false;
            votedSkip = false;
            Send(0, eligible);
            if (!eligible)
            {
                waiting = false;
                yield break;
            }

            if (AvatarInputHandler.main && AvatarInputHandler.main.enabled)
            {
                blockedInput = AvatarInputHandler.main;
                blockedInput.enabled = false;
            }

            try
            {
                float deadline = Time.realtimeSinceStartup + 300f;
                while (Multiplayer.Active && (status == null || status.Phase < 2) && Time.realtimeSinceStartup < deadline)
                {
                    if (status?.Phase == 1 && Input.anyKeyDown) VoteReady();
                    yield return null;
                }
                if (!Multiplayer.Active || status?.Phase != 2)
                {
                    if (Multiplayer.Active) Send(3);
                    yield break;
                }

                RestoreInput();
                intro = ui.intro;
                PlayingPod = pod;
                pod.startedIntroCinematic = false;
                intro.Play();
                deadline = Time.realtimeSinceStartup + 180f;
                while (Multiplayer.Active && intro && intro.showing && status.Phase < 3 && Time.realtimeSinceStartup < deadline)
                {
                    if (Input.GetKeyDown(KeyCode.Escape)) VoteSkip();
                    yield return null;
                }

                if (Multiplayer.Active && status.Phase < 3)
                {
                    if (intro && intro.showing) Send(3);
                    else
                    {
                        if (AvatarInputHandler.main && AvatarInputHandler.main.enabled)
                        {
                            blockedInput = AvatarInputHandler.main;
                            blockedInput.enabled = false;
                        }
                        VoteSkip();
                    }
                    while (Multiplayer.Active && status.Phase < 3 && Time.realtimeSinceStartup < deadline)
                        yield return null;
                }
            }
            finally
            {
                Stop();
            }
        }

        public static bool IntroAdvancePressed() => PlayingPod ? status?.Phase >= 2 : Input.anyKeyDown;

        public static bool AllowNativeStop(bool skipped)
        {
            if (!PlayingPod || stopping || !skipped || status?.Phase >= 3) return true;
            VoteSkip();
            return false;
        }

        public static void DrawStatus()
        {
            if (!waiting || status?.Phase >= 3) return;
            if (status == null || status.Phase < 2)
            {
                // Cover the world even before the first server status arrives.
                // Never expose the already-loaded pod behind the ready screen.
                int previousDepth = GUI.depth;
                Color previousColor = GUI.color;
                GUI.depth = -10000;
                GUI.color = Color.black;
                GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
                GUI.color = Color.white;
                GUIStyle title = new(GUI.skin.label) { fontSize = 30, alignment = TextAnchor.MiddleCenter };
                GUIStyle counter = new(title) { fontSize = 64, fontStyle = FontStyle.Bold };
                float center = Screen.height * 0.5f;
                GUI.Label(new Rect(0, center - 110, Screen.width, 60),
                    status?.Phase == 1 ? "PRESS ANY BUTTON" : "WAITING FOR PLAYERS", title);
                GUI.Label(new Rect(0, center - 35, Screen.width, 100),
                    status == null ? "…" : $"{status.Count} / {status.Total}", counter);
                if (votedReady)
                    GUI.Label(new Rect(0, center + 90, Screen.width, 50), "WAITING FOR ALL PLAYERS", title);
                GUI.color = previousColor;
                GUI.depth = previousDepth;
                return;
            }
            const int width = 440;
            var rect = new Rect((Screen.width - width) / 2f, Screen.height * 0.72f, width, 90);
            GUILayout.BeginArea(rect, GUI.skin.box);
            GUILayout.Label(status.Phase == 0 ? $"Loading crew · {status.Count}/{status.Total}" :
                status.Phase == 1 ? $"Press any key to start · {status.Count}/{status.Total}" :
                $"Skip / finished · {status.Count}/{status.Total}");
            if (status.Phase == 1 && votedReady) GUILayout.Label("Waiting for the rest of the crew...");
            if (status.Phase == 2) GUILayout.Label(votedSkip ? "Waiting for the rest of the crew..." : "Press Esc to vote to skip");
            GUILayout.EndArea();
        }

        private static void VoteReady()
        {
            if (votedReady) return;
            votedReady = true;
            Send(1);
        }

        private static void VoteSkip()
        {
            if (votedSkip || status?.Phase != 2) return;
            votedSkip = true;
            Send(2);
        }

        private static void Send(int step, bool eligible = false) =>
            NitroxServiceLocator.LocateService<IPacketSender>().Send(new TidraOpeningAction(step, eligible));

        private static void RestoreInput()
        {
            if (blockedInput) blockedInput.enabled = true;
            blockedInput = null;
        }

        public static void Stop()
        {
            stopping = true;
            try
            {
                if (intro && intro.showing) intro.Stop(true);
            }
            finally
            {
                RestoreInput();
                PlayingPod = null;
                intro = null;
                status = null;
                waiting = false;
                stopping = false;
            }
        }
    }
}
