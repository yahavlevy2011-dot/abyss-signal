﻿using System.Collections.Generic;
using FMOD.Studio;
using FMODUnity;
using UnityEngine;
using NitroxClient.Unity.Helper;
#pragma warning disable 618

namespace NitroxClient.MonoBehaviours
{
    public class FMODEmitterController : MonoBehaviour
    {
        private readonly Dictionary<string, FMOD_CustomEmitter> customEmitters = new();
        private readonly Dictionary<string, KeyValuePair<FMOD_CustomLoopingEmitter, float>> loopingEmitters = new();
        private readonly Dictionary<string, FMOD_StudioEventEmitter> studioEmitters = new();

        public void AddEmitter(string path, FMOD_CustomEmitter customEmitter, float radius)
        {
            if (!customEmitters.ContainsKey(path))
            {
                customEmitter.GetEventInstance().setProperty(EVENT_PROPERTY.MINIMUM_DISTANCE, 1f);
                customEmitter.GetEventInstance().setProperty(EVENT_PROPERTY.MAXIMUM_DISTANCE, radius);

                customEmitters.Add(path, customEmitter);
            }
            else
            {
                Log.Warn($"[FMODEmitterController] customEmitters already contains {path}");
            }
        }

        public void AddEmitter(string path, FMOD_CustomLoopingEmitter loopingEmitter, float radius)
        {
            if (!loopingEmitters.ContainsKey(path))
            {
                loopingEmitters.Add(path, new KeyValuePair<FMOD_CustomLoopingEmitter, float>(loopingEmitter, radius));
            }
            else
            {
                Log.Warn($"[FMODEmitterController] loopingEmitters already contains {path}");
            }
        }

        public void AddEmitter(string path, FMOD_StudioEventEmitter studioEmitter, float radius)
        {
            if (!studioEmitters.ContainsKey(path))
            {
                EventInstance evt = studioEmitter.evt;
                evt.setProperty(EVENT_PROPERTY.MINIMUM_DISTANCE, 1f);
                evt.setProperty(EVENT_PROPERTY.MAXIMUM_DISTANCE, radius);
                studioEmitter.evt = evt;

                studioEmitters.Add(path, studioEmitter);
            }
            else
            {
                Log.Warn($"[FMODEmitterController] studioEmitters already contains {path}");
            }
        }

        public void PlayCustomEmitter(string path) { if (path != null && customEmitters.TryGetValue(path, out var emitter)) emitter.AliveOrNull()?.Play(); }
        public void ParamCustomEmitter(string path, int paramIndex, float value) { if (path != null && customEmitters.TryGetValue(path, out var emitter)) emitter.AliveOrNull()?.SetParameterValue(paramIndex, value); }
        public void StopCustomEmitter(string path) { if (path != null && customEmitters.TryGetValue(path, out var emitter)) emitter.AliveOrNull()?.Stop(); }

        public void PlayStudioEmitter(string path) { if (path != null && studioEmitters.TryGetValue(path, out var emitter)) emitter.AliveOrNull()?.PlayUI(); }
        public void StopStudioEmitter(string path, bool allowFadeout) { if (path != null && studioEmitters.TryGetValue(path, out var emitter)) emitter.AliveOrNull()?.Stop(allowFadeout); }

        public void PlayCustomLoopingEmitter(string path)
        {
            if (path == null || !loopingEmitters.TryGetValue(path, out var entry)) return;
            FMOD_CustomLoopingEmitter loopingEmitter = entry.Key;
            if (!loopingEmitter) return;
            EventInstance eventInstance = FMODUWE.GetEvent(path);
            eventInstance.set3DAttributes(loopingEmitter.transform.To3DAttributes());
            eventInstance.setProperty(EVENT_PROPERTY.MINIMUM_DISTANCE, 1f);
            eventInstance.setProperty(EVENT_PROPERTY.MAXIMUM_DISTANCE, loopingEmitters[path].Value);
            eventInstance.start();
            eventInstance.release();
            loopingEmitter.timeLastStopSound = Time.time;
        }
    }
}
