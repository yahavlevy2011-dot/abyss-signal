using System;
using System.Linq;
using NitroxClient.GameLogic.Settings;
using NitroxModel.Helper;
using NitroxClient.MonoBehaviours.Discord;
using NitroxClient.MonoBehaviours.Gui.MainMenu;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    public class NitroxBootstrapper : MonoBehaviour
    {
        internal static NitroxBootstrapper Instance;
        private static readonly int[] FrameRates = { 30, 60, 90, 120, 144, 165, 240, 0 };
        public static readonly string[] FrameRateLabels = FrameRates.Select(rate => rate == 0 ? "Unlimited" : $"{rate} FPS").ToArray();
        private int targetFrameRate;
        private float fpsFrameTime;

        private void OnGUI()
        {
            // Keep the native held-tool power text and quickslot HUD. The
            // additional floating power bar duplicated that information.
            if (!NitroxPrefs.ShowFps.Value) return;
            fpsFrameTime = UnityEngine.Mathf.Lerp(fpsFrameTime, Time.unscaledDeltaTime, 0.1f);
            if (fpsFrameTime <= 0f) return;
            GUIStyle style = new(GUI.skin.box) { fontSize = 17, alignment = TextAnchor.MiddleCenter };
            style.normal.textColor = new Color(0.4f, 0.95f, 1f);
            GUI.Box(new Rect(20, 20, 130, 36), $"{1f / fpsFrameTime:0} FPS", style);
        }

        public static void SetFrameRateIndex(int index)
        {
            if (index < 0 || index >= FrameRates.Length) return;
            NitroxPrefs.FrameRateIndex.Value = index;
            if (Instance)
            {
                Instance.targetFrameRate = FrameRates[index] == 0 ? -1 : FrameRates[index];
                Instance.ApplyFramePacing();
            }
        }

        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            Instance = this;
            gameObject.AddComponent<TidraRecipeTracker>();
            gameObject.AddComponent<SceneCleanerPreserve>();
            gameObject.AddComponent<MainMenuMods>();
            gameObject.AddComponent<DiscordClient>();

            int index = NitroxPrefs.FrameRateIndex.Value;
            if (!PlayerPrefs.HasKey(NitroxPrefs.FrameRateIndex.Key) &&
                int.TryParse(Environment.GetEnvironmentVariable(DeepCurrentLegacy.FrameRateVariable), out int previousRate))
            {
                index = Array.IndexOf(FrameRates, previousRate);
            }
            SetFrameRateIndex(index >= 0 && index < FrameRates.Length
                ? index : Array.IndexOf(FrameRates, DeepCurrentLegacy.DefaultFrameRate));

            CreateDebugger();
        }

        private void LateUpdate()
        {
            ApplyFramePacing();
        }

        private void ApplyFramePacing()
        {
            if (!Application.runInBackground) Application.runInBackground = true;
            // On desktop Unity ignores targetFrameRate when v-sync is enabled.
            if (QualitySettings.vSyncCount != 0) QualitySettings.vSyncCount = 0;
            if (Application.targetFrameRate != targetFrameRate) Application.targetFrameRate = targetFrameRate;
        }

        private void CreateDebugger()
        {
            GameObject debugger = new GameObject();
            debugger.name = "Debug manager";
            debugger.AddComponent<NitroxDebugManager>();
            debugger.transform.SetParent(transform);
        }
    }
}
