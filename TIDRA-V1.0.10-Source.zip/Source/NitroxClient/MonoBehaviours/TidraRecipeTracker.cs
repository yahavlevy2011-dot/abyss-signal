using System;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    public class TidraRecipeTracker : MonoBehaviour
    {
        private const string Preference = "TIDRA.trackedRecipe";
        private TechType tracked;

        private void Start()
        {
            Enum.TryParse(PlayerPrefs.GetString(Preference, "None"), out tracked);
        }

        public static bool Toggle(TechType selected)
        {
            if (!CanTrack(selected)) return false;
            TidraRecipeTracker tracker = UnityEngine.Object.FindObjectOfType<TidraRecipeTracker>();
            if (!tracker) return false;
            tracker.tracked = tracker.tracked == selected ? TechType.None : selected;
            PlayerPrefs.SetString(Preference, tracker.tracked.ToString());
            PlayerPrefs.Save();
            return true;
        }

        public static bool CanTrack(TechType selected) => selected != TechType.None &&
            CraftData.techData.ContainsKey(selected) && CrafterLogic.IsCraftRecipeUnlocked(selected);

        public static bool IsTracked(TechType selected)
        {
            TidraRecipeTracker tracker = UnityEngine.Object.FindObjectOfType<TidraRecipeTracker>();
            return tracker && tracker.tracked == selected;
        }

        private void OnGUI()
        {
            if (!Player.main || !Inventory.main || Player.main.cinematicModeActive) return;
            if (tracked == TechType.None || !CraftData.techData.TryGetValue(tracked, out var recipe)) return;
            float scale = UnityEngine.Mathf.Clamp(Screen.height / 1080f, 0.7f, 1.5f);
            float width = 300f * scale;
            float height = (54 + recipe.ingredientCount * 48) * scale;
            float left = Screen.width - width - 24 * scale;
            float top = 150 * scale;
            Color previous = GUI.color;
            GUI.color = new Color(0.025f, 0.12f, 0.18f, 0.87f);
            GUI.DrawTexture(new Rect(left, top, width, height), Texture2D.whiteTexture);
            GUI.color = new Color(0.25f, 0.9f, 1f, 0.9f);
            GUI.DrawTexture(new Rect(left, top, 3 * scale, height), Texture2D.whiteTexture);
            GUI.color = Color.white;
            GUIStyle title = new(GUI.skin.label) { fontSize = (int)(18 * scale), fontStyle = FontStyle.Bold };
            GUIStyle row = new(GUI.skin.label) { fontSize = (int)(16 * scale), alignment = TextAnchor.MiddleLeft };
            GUI.Label(new Rect(left + 14 * scale, top + 10 * scale, width - 28 * scale, 32 * scale),
                Language.main.Get(tracked.ToString()), title);
            DrawPin(new Rect(left + width - 28 * scale, top + 12 * scale, 12 * scale, 20 * scale));
            for (int i = 0; i < recipe.ingredientCount; i++)
            {
                var ingredient = recipe.GetIngredient(i);
                int owned = Inventory.main.container.GetCount(ingredient.techType);
                float y = top + (48 + i * 48) * scale;
                DrawIngredientIcon(ingredient.techType, new Rect(left + 12 * scale, y, 38 * scale, 38 * scale));
                GUI.color = owned >= ingredient.amount ? new Color(0.45f, 0.95f, 1f) : new Color(1f, 0.4f, 0.25f);
                GUI.Label(new Rect(left + 60 * scale, y, width - 70 * scale, 40 * scale),
                    $"{Language.main.Get(ingredient.techType.ToString())}  {owned}/{ingredient.amount}", row);
                GUI.color = Color.white;
            }
            GUI.color = previous;
        }

        private static void DrawPin(Rect rect)
        {
            Color old = GUI.color;
            GUI.color = new Color(0.35f, 0.95f, 1f, 0.95f);
            GUI.DrawTexture(new Rect(rect.x + rect.width * 0.2f, rect.y, rect.width * 0.6f, rect.width * 0.6f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x + rect.width * 0.43f, rect.y + rect.width * 0.5f, rect.width * 0.14f, rect.height * 0.5f), Texture2D.whiteTexture);
            GUI.color = old;
        }

        private static void DrawIngredientIcon(TechType type, Rect rect)
        {
            Atlas.Sprite sprite = SpriteManager.Get(type);
            if (sprite == null || !sprite.texture || sprite.uv0 == null || sprite.uv0.Length == 0) return;
            Vector2 min = sprite.uv0[0], max = min;
            foreach (Vector2 uv in sprite.uv0)
            {
                min = Vector2.Min(min, uv);
                max = Vector2.Max(max, uv);
            }
            GUI.DrawTextureWithTexCoords(rect, sprite.texture, new Rect(min.x, min.y, max.x - min.x, max.y - min.y));
        }
    }
}
