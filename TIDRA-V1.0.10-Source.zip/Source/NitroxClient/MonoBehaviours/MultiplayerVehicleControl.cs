﻿using System;
using NitroxClient.GameLogic;
using NitroxClient.Unity.Smoothing;
using UnityEngine;

namespace NitroxClient.MonoBehaviours
{
    public abstract class MultiplayerVehicleControl : MonoBehaviour
    {
        private Rigidbody rigidbody;
        private RigidbodyInterpolation originalInterpolation;
        private bool originalKinematic;
        private bool remoteControlActive;
        private bool hasMovementSnapshot;
        private float snapshotReceivedAt;
        private Vector3 snapshotPosition;
        private Quaternion snapshotRotation;
        private bool isCyclops;

        protected readonly SmoothParameter SmoothYaw = new SmoothParameter();
        protected readonly SmoothParameter SmoothPitch = new SmoothParameter();
        protected readonly SmoothVector SmoothLeftArm = new SmoothVector();
        protected readonly SmoothVector SmoothRightArm = new SmoothVector();
        protected SmoothVector SmoothPosition;
        protected SmoothVector SmoothVelocity;
        protected SmoothRotation SmoothRotation;
        protected SmoothVector SmoothAngularVelocity;
        protected Action<float> WheelYawSetter;
        protected Action<float> WheelPitchSetter;

        protected virtual void Awake()
        {
            rigidbody = gameObject.GetComponent<Rigidbody>();
            SubRoot subRoot = gameObject.GetComponent<SubRoot>();
            isCyclops = subRoot && subRoot.isCyclops;
            // For now, we assume the set position and rotation is equal to the server one.
            // Default velocities are probably empty, but set them anyway.
            SmoothPosition = new SmoothVector(gameObject.transform.position);
            SmoothVelocity = new SmoothVector(rigidbody.velocity);
            SmoothRotation = new SmoothRotation(gameObject.transform.rotation);
            SmoothAngularVelocity = new SmoothVector(rigidbody.angularVelocity);
            // AddComponent enables a behaviour by default. Do not take over
            // local vehicle physics until a remote pilot explicitly enters.
            enabled = false;
        }

        protected virtual void FixedUpdate()
        {
            SmoothYaw.FixedUpdate();
            SmoothPitch.FixedUpdate();

            // A held network position becomes a staircase at 20Hz. Advance
            // the target between snapshots using the supplied velocity, with
            // a short bound so a lost connection cannot run the ship away.
            if (hasMovementSnapshot)
            {
                float age = Mathf.Clamp(Time.unscaledTime - snapshotReceivedAt, 0f,
                    isCyclops ? 0.08f : 0.15f);
                // The Cyclops velocity can fluctuate slightly while its local
                // physics settles. Predict from the filtered velocity so these
                // fluctuations do not shake the entire remote interior.
                SmoothPosition.Target = snapshotPosition +
                    (isCyclops ? SmoothVelocity.Current : SmoothVelocity.Target) * age;
                Vector3 angular = isCyclops ? SmoothAngularVelocity.Current : SmoothAngularVelocity.Target;
                float speed = angular.magnitude;
                SmoothRotation.Target = speed > 0.0001f
                    ? Quaternion.AngleAxis(speed * age * Mathf.Rad2Deg, angular / speed) * snapshotRotation
                    : snapshotRotation;
            }

            SmoothPosition.FixedUpdate();
            SmoothVelocity.FixedUpdate();
            SmoothRotation.FixedUpdate();
            SmoothAngularVelocity.FixedUpdate();

            // This component controls a remote replica, never the authority.
            // Dynamic local physics creates feedback with the authoritative
            // snapshot stream: Cyclops jitter, violent boarding impulses and
            // Prawn position corrections. Apply the smoothed snapshot as a
            // kinematic replica instead.
            rigidbody.isKinematic = true;
            rigidbody.velocity = Vector3.zero;
            rigidbody.angularVelocity = Vector3.zero;
            rigidbody.MovePosition(SmoothPosition.Current);
            rigidbody.MoveRotation(SmoothRotation.Current);
            
            WheelYawSetter(SmoothYaw.SmoothValue);
            WheelPitchSetter(SmoothPitch.SmoothValue);
        }

        internal void SetPositionVelocityRotation(Vector3 remotePosition, Vector3 remoteVelocity, Quaternion remoteRotation, Vector3 remoteAngularVelocity)
        {
            gameObject.SetActive(true);
            SmoothPosition.Target = remotePosition;
            snapshotPosition = remotePosition;
            snapshotRotation = remoteRotation;
            snapshotReceivedAt = Time.unscaledTime;
            SmoothVelocity.Target = remoteVelocity;
            SmoothRotation.Target = remoteRotation;
            SmoothAngularVelocity.Target = remoteAngularVelocity;
            hasMovementSnapshot = true;
        }

        internal virtual void SetSteeringWheel(float yaw, float pitch)
        {
            SmoothYaw.Target = yaw;
            SmoothPitch.Target = pitch;
        }

        internal virtual void SetArmPositions(Vector3 leftArmPosition, Vector3 rightArmPosition)
        {
            SmoothLeftArm.Target = leftArmPosition;
            SmoothRightArm.Target = rightArmPosition;
        }

        internal virtual void Enter()
        {
            if (!remoteControlActive)
            {
                originalInterpolation = rigidbody.interpolation;
                originalKinematic = rigidbody.isKinematic;
                remoteControlActive = true;
            }
            rigidbody.interpolation = RigidbodyInterpolation.Interpolate;
            SmoothPosition.Current = rigidbody.position;
            SmoothRotation.Current = rigidbody.rotation;
            SmoothVelocity.Current = rigidbody.velocity;
            SmoothAngularVelocity.Current = rigidbody.angularVelocity;
            // A movement packet can create and seat the pilot in the same call.
            // Preserve that packet's targets rather than replacing them on entry.
            if (!hasMovementSnapshot)
            {
                SmoothPosition.Target = rigidbody.position;
                SmoothRotation.Target = rigidbody.rotation;
                SmoothVelocity.Target = rigidbody.velocity;
                SmoothAngularVelocity.Target = rigidbody.angularVelocity;
            }
            enabled = true;
        }

        public virtual void Exit()
        {
            if (remoteControlActive)
            {
                rigidbody.interpolation = originalInterpolation;
                rigidbody.isKinematic = originalKinematic;
                remoteControlActive = false;
            }
            enabled = false;
            hasMovementSnapshot = false;
        }

        internal abstract void SetThrottle(bool isOn);
    }
}
