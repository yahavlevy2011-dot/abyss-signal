using UnityEngine;
using UnityEngine.UI;

namespace NitroxClient.MonoBehaviours
{
    /// <summary>Charge belongs to the bound item, not only to the currently held tool.</summary>
    public class TidraQuickslotCharge : MonoBehaviour
    {
        private InventoryItem boundItem;
        private bool initialized;
        private EnergyMixin energy;
        private Image indicator;

        public void Refresh(InventoryItem item)
        {
            if (!initialized || boundItem != item)
            {
                initialized = true;
                boundItem = item;
                energy = item?.item ? item.item.GetComponent<EnergyMixin>() : null;
                if (!energy && item?.item) energy = item.item.GetComponentInChildren<EnergyMixin>();
            }

            if (!energy)
            {
                if (indicator) indicator.gameObject.SetActive(false);
                return;
            }
            if (!indicator)
            {
                var child = new GameObject("TIDRA charge", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
                child.transform.SetParent(transform, false);
                indicator = child.GetComponent<Image>();
                indicator.raycastTarget = false;
                indicator.rectTransform.anchorMin = indicator.rectTransform.anchorMax = new Vector2(0.5f, 0f);
                indicator.rectTransform.pivot = new Vector2(0f, 0.5f);
            }
            indicator.gameObject.SetActive(true);
            float charge = Mathf.Clamp01(energy.GetEnergyScalar());
            float width = ((RectTransform)transform).rect.width * 0.55f;
            indicator.rectTransform.anchoredPosition = new Vector2(-width * 0.5f, 6f);
            indicator.rectTransform.sizeDelta = new Vector2(width * charge, 3f);
            indicator.color = charge <= 0.15f ? new Color(1f, 0.35f, 0.15f) : new Color(1f, 0.85f, 0.25f);
        }
    }
}
