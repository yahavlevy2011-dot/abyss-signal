using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UWE;
using NitroxClient.Communication.Abstract;
using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.GameLogic.Spawning.Metadata;
using NitroxClient.MonoBehaviours;
using NitroxModel.Core;
using NitroxModel.DataStructures.GameLogic.Entities.Metadata;
using NitroxModel.Packets;
using NitroxModel_Subnautica.DataStructures;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors
{
    public sealed class SealedDoorStateChangedProcessor : ClientPacketProcessor<SealedDoorStateChanged>
    {
        private readonly IPacketSender packetSender;
        private readonly Dictionary<string, SealedDoorStateChanged> pending = new();
        private bool retrying;

        public SealedDoorStateChangedProcessor(IPacketSender packetSender)
        {
            this.packetSender = packetSender;
        }

        public override void Process(SealedDoorStateChanged packet)
        {
            string key = GetKey(packet);
            if (TryApply(packet))
            {
                pending.Remove(key);
                return;
            }
            pending[key] = packet;
            if (retrying) return;
            retrying = true;
            CoroutineHost.StartCoroutine(RetryPending());
        }

        private static string GetKey(SealedDoorStateChanged packet) =>
            packet.Id != null ? packet.Id.ToString() :
                packet.ParentId != null && packet.ChildPath != null
                    ? $"{packet.ParentId}/{string.Join(",", packet.ChildPath)}"
                    : $"{packet.ObjectName}/{packet.Position}";

        private IEnumerator RetryPending()
        {
            while (Multiplayer.Main && pending.Count > 0)
            {
                yield return new WaitForSecondsRealtime(1f);
                foreach (KeyValuePair<string, SealedDoorStateChanged> entry in pending.ToArray())
                {
                    if (TryApply(entry.Value)) pending.Remove(entry.Key);
                }
            }
            pending.Clear();
            retrying = false;
        }

        private bool TryApply(SealedDoorStateChanged packet)
        {
            GameObject target = null;
            NitroxEntity.TryGetObjectFrom(packet.Id, out target);
            if (!target && packet.ParentId != null && packet.ChildPath != null && packet.ChildPath.Length <= 32 &&
                NitroxEntity.TryGetObjectFrom(packet.ParentId, out GameObject parent))
            {
                Transform child = parent.transform;
                foreach (int index in packet.ChildPath)
                {
                    if (!child || index < 0 || index >= child.childCount) { child = null; break; }
                    child = child.GetChild(index);
                }
                if (child && child.name == packet.ObjectName) target = child.gameObject;
            }
            if (!target && !string.IsNullOrEmpty(packet.ObjectName))
            {
                Vector3 position = packet.Position.ToUnity();
                float closest = 0.25f * 0.25f;
                foreach (Sealed candidate in Object.FindObjectsOfType<Sealed>())
                {
                    if (candidate.name != packet.ObjectName) continue;
                    float distance = (candidate.transform.position - position).sqrMagnitude;
                    if (distance < closest) { closest = distance; target = candidate.gameObject; }
                }
            }
            if (!target || !target.TryGetComponent(out Sealed door)) return false;
            if (!door._sealed && packet.IsSealed) return true;
            if (packet.IsSealed && packet.OpenedAmount < door.openedAmount) return true;
            using (packetSender.Suppress<SealedDoorStateChanged>())
            {
                var metadata = new SealedDoorMetadata(packet.IsSealed, packet.OpenedAmount);
                var processor = new SealedDoorMetadataProcessor();
                processor.ProcessMetadata(target, metadata);
            }
            return true;
        }
    }
}
