﻿using NitroxClient.Communication.Abstract;
using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxClient.Unity.Helper;
using NitroxModel.Packets;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors;

public class PlayFMODCustomEmitterProcessor : ClientPacketProcessor<PlayFMODCustomEmitter>
{
    private readonly IPacketSender packetSender;

    public PlayFMODCustomEmitterProcessor(IPacketSender packetSender)
    {
        this.packetSender = packetSender;
    }


    public override void Process(PlayFMODCustomEmitter packet)
    {
        if (!NitroxEntity.TryGetComponentFrom(packet.Id, out FMODEmitterController fmodEmitterController) || !fmodEmitterController) return;

        using (packetSender.Suppress<PlayFMODCustomEmitter>())
        using (packetSender.Suppress<PlayFMODCustomLoopingEmitter>())
        {
            if (packet.Play)
            {
                fmodEmitterController.PlayCustomEmitter(packet.AssetPath);
            }
            else
            {
                fmodEmitterController.StopCustomEmitter(packet.AssetPath);
            }
        }
    }
}
