﻿using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.GameLogic;
using NitroxClient.GameLogic.PlayerLogic;
using NitroxClient.MonoBehaviours;
using NitroxModel.DataStructures.Util;
using NitroxModel.Packets;
using NitroxModel_Subnautica.DataStructures;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors
{
    public class AnimationProcessor : ClientPacketProcessor<AnimationChangeEvent>
    {
        private readonly PlayerManager remotePlayerManager;

        public AnimationProcessor(PlayerManager remotePlayerManager)
        {
            this.remotePlayerManager = remotePlayerManager;
        }

        public override void Process(AnimationChangeEvent animEvent)
        {
            Optional<RemotePlayer> opPlayer = remotePlayerManager.Find(animEvent.PlayerId);
            if (opPlayer.HasValue)
            {
                if (animEvent.Type == 12)
                {
                    GameObject resolved = null;
                    if (animEvent.State == 1 && animEvent.TargetId != null && NitroxEntity.TryGetComponentFrom(animEvent.TargetId, out NitroxEntity target))
                        resolved = target.gameObject;
                    else if (animEvent.State == 1 && animEvent.TargetPosition.HasValue && animEvent.TargetTechType != null)
                    {
                        TechType type = animEvent.TargetTechType.ToUnity();
                        Vector3 position = animEvent.TargetPosition.Value.ToUnity();
                        GameObject previous = opPlayer.Value.ScannerTarget;
                        if (type != TechType.None && previous && CraftData.GetTechType(previous) == type &&
                            (previous.transform.position - position).sqrMagnitude <= 0.0625f)
                            resolved = previous;
                        else if (type != TechType.None)
                        {
                            // A loaded fragment may have a client-local child
                            // ID. Never put the overlay on ambiguous neighbours.
                            foreach (TechTag tag in Object.FindObjectsOfType<TechTag>())
                            {
                                if (tag.type != type || !((tag.transform.position - position).sqrMagnitude <= 0.0625f) ||
                                    tag.GetComponentInParent<RemotePlayerIdentifier>(true)) continue;
                                if (Inventory.main && tag.transform.IsChildOf(Inventory.main.container.tr)) continue;
                                if (resolved) { resolved = null; break; }
                                resolved = tag.gameObject;
                            }
                        }
                    }
                    opPlayer.Value.ScannerTarget = resolved;
                    return;
                }
                if (animEvent.Type == 11 && !string.IsNullOrEmpty(animEvent.CinematicParameter) && animEvent.CinematicParameter.Length <= 128)
                {
                    var animator = opPlayer.Value.ArmsController.GetComponent<UnityEngine.Animator>();
                    foreach (var parameter in animator.parameters)
                    {
                        if (parameter.name == animEvent.CinematicParameter && parameter.type == UnityEngine.AnimatorControllerParameterType.Bool)
                        {
                            animator.SetBool(parameter.name, animEvent.State == 1);
                            break;
                        }
                    }
                    return;
                }
                opPlayer.Value.UpdateAnimationAndCollider((AnimChangeType)animEvent.Type, (AnimChangeState)animEvent.State);
            }
        }
    }
}
