using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.GameLogic;
using NitroxClient.MonoBehaviours;
using NitroxClient.GameLogic.PlayerLogic;
using System.Linq;
using NitroxModel.DataStructures.Util;
using NitroxModel.Packets;
using UnityEngine;
using NitroxModel_Subnautica.DataStructures;

namespace NitroxClient.Communication.Packets.Processors
{
    public class PickupItemProcessor : ClientPacketProcessor<PickupItem>
    {
        private readonly Entities entities;

        public PickupItemProcessor(Entities entities)
        {
            this.entities = entities;
        }

        public override void Process(PickupItem pickup)
        {
            Optional<GameObject> opGameObject = NitroxEntity.GetObjectFrom(pickup.Id);
            if (!opGameObject.HasValue)
            {
                TechType type = pickup.TechType.ToUnity();
                PDAScanner.EntryData scan = PDAScanner.GetEntryData(type);
                bool fragment = scan != null && scan.destroyAfterScan && type.ToString().EndsWith("Fragment", System.StringComparison.OrdinalIgnoreCase);
                if (type != TechType.None)
                {
                    // Placeholder fragments can have client-local child IDs.
                    // Match only a loaded fragment of the exact type at the
                    // scanned position; never remove nearby unrelated loot.
                    Vector3 position = pickup.ItemPosition.ToUnity();
                    GameObject nearest = null;
                    float distance = 0.25f * 0.25f;
                    foreach (TechTag tag in Object.FindObjectsOfType<TechTag>())
                    {
                        if (tag.type != type || tag.GetComponentInParent<RemotePlayerIdentifier>(true)) continue;
                        if (!fragment && !tag.GetComponent<Pickupable>()) continue;
                        if (Inventory.main && tag.transform.IsChildOf(Inventory.main.container.tr)) continue;
                        float candidate = (tag.transform.position - position).sqrMagnitude;
                        if (candidate < distance) { nearest = tag.gameObject; distance = candidate; }
                    }
                    if (nearest) opGameObject = Optional.Of(nearest);
                }
            }
            if (opGameObject.HasValue &&
                !opGameObject.Value.GetComponentInParent<RemotePlayerIdentifier>(true) &&
                (!Inventory.main || !Inventory.main.container.Any(item => item.item.gameObject == opGameObject.Value)))
            {
                opGameObject.Value.SetActive(false);
                Object.Destroy(opGameObject.Value);
            }
            entities.RemoveEntity(pickup.Id);
        }
    }
}

