using System;
using System.Collections;
using System.Linq;
using UWE;
using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxModel.Packets;
using NitroxModel.Core;
using NitroxClient.GameLogic;
using NitroxClient.MonoBehaviours;
using NitroxModel.DataStructures.GameLogic;
using NitroxModel_Subnautica.DataStructures;
using NitroxModel_Subnautica.Helper;
using UnityEngine;
using Object = UnityEngine.Object;

namespace NitroxClient.Communication.Packets.Processors
{
    internal class GiveTestItemProcessor : ClientPacketProcessor<GiveTestItem>
    {
        public override void Process(GiveTestItem packet)
        {
            if (packet.Count < 1 || packet.Count > GiveTestItem.MaxCount) return;
            if (!Inventory.main || !Player.main || Player.main.cinematicModeActive)
            {
                Log.InGame("GIVE: wait until your player is ready, then try again.");
                return;
            }

            // "Habitat Builder" is the player-facing name; Legacy exposes its
            // TechType as Builder. Keep the terminal natural to use while using
            // the real game identifier internally.
            string requestedItem = string.Equals(packet.Item, "HabitatBuilder", StringComparison.OrdinalIgnoreCase)
                ? nameof(TechType.Builder) : packet.Item;
            if (string.Equals(requestedItem, "RepairTool", StringComparison.OrdinalIgnoreCase)) requestedItem = "Welder";
            if (string.Equals(requestedItem, "PrawnSuit", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(requestedItem, "PrownSuit", StringComparison.OrdinalIgnoreCase)) requestedItem = "Exosuit";
            if (string.Equals(requestedItem, "PurpleTablet", StringComparison.OrdinalIgnoreCase)) requestedItem = "PrecursorKey_Purple";
            if (string.Equals(requestedItem, "OrangeTablet", StringComparison.OrdinalIgnoreCase)) requestedItem = "PrecursorKey_Orange";
            if (string.Equals(requestedItem, "BlueTablet", StringComparison.OrdinalIgnoreCase)) requestedItem = "PrecursorKey_Blue";
            if (!Enum.TryParse(requestedItem, true, out TechType techType) ||
                techType == TechType.None || !Enum.IsDefined(typeof(TechType), techType))
            {
                Log.InGame($"GIVE: unknown item '{packet.Item}'.");
                return;
            }

            if (techType == TechType.Cyclops)
            {
                if (packet.Count != 1)
                {
                    Log.InGame("GIVE: spawn one Cyclops at a time; use count 1.");
                    return;
                }
                Log.InGame("GIVE: loading Cyclops...");
                LightmappedPrefabs.main.RequestScenePrefab("cyclops", prefab =>
                {
                    if (!Player.main || !prefab) return;
                    CoroutineHost.StartCoroutine(GivePrefab(packet, techType, prefab));
                });
                return;
            }
            GameObject prefab = ResolvePrefab(techType);
            if (!prefab)
            {
                CoroutineHost.StartCoroutine(LoadWorldPrefab(packet, techType));
                return;
            }
            CoroutineHost.StartCoroutine(GivePrefab(packet, techType, prefab));
        }

        private static IEnumerator LoadWorldPrefab(GiveTestItem packet, TechType techType)
        {
            string classId = CraftData.GetClassIdForTechType(techType);
            var ids = PrefabDatabase.prefabFiles.Where(entry =>
                NitroxModel.Helper.PrefabNameMatcher.Matches(techType.ToString(), entry.Value))
                .OrderBy(entry => entry.Value, StringComparer.Ordinal)
                .Select(entry => entry.Key);
            if (!string.IsNullOrEmpty(classId)) ids = new[] { classId }.Concat(ids);
            foreach (string id in ids.Distinct())
            {
                // TryGetPrefab only finds already loaded assets. Request the
                // asset first so distant creatures/fragments can be spawned.
                IPrefabRequest request = PrefabDatabase.GetPrefabAsync(id);
                yield return request;
                if (!Player.main || !Inventory.main) yield break;
                if (request.TryGetPrefab(out GameObject loaded) && loaded)
                {
                    yield return GivePrefab(packet, techType, loaded);
                    yield break;
                }
            }
            Log.InGame($"GIVE: no loadable Legacy prefab found for {techType}.");
        }

        private static GameObject ResolvePrefab(TechType techType)
        {
            GameObject prefab = CraftData.GetPrefabForTechType(techType, false);
            if (prefab)
            {
                return prefab;
            }

            // Unloaded world objects are resolved by LoadWorldPrefab. Do not
            // substitute a similarly named creature or story spawner here.
            return null;
        }

        private static IEnumerator GivePrefab(GiveTestItem packet, TechType techType, GameObject prefab)
        {
            if (prefab && (!prefab.GetComponent<Pickupable>() || prefab.GetComponent<Creature>() || techType.ToString().EndsWith("Fragment", StringComparison.OrdinalIgnoreCase)))
            {
                if (packet.Count != 1)
                {
                    Log.InGame("GIVE: spawn one world object at a time; use count 1.");
                    yield break;
                }
                Vector3 forward = Player.main.transform.forward;
                forward.y = 0;
                if (forward.sqrMagnitude < 0.01f) forward = Vector3.forward;
                Vector3 spawnPosition = Player.main.transform.position + forward.normalized * (techType == TechType.Cyclops ? 35f : 10f);
                GameObject vehicle = Utils.SpawnPrefabAt(prefab, null, spawnPosition);
                vehicle.transform.rotation = Quaternion.identity;
                vehicle.SetActive(true);
                LargeWorldEntity.Register(vehicle);
                vehicle.SendMessage("StartConstruction", SendMessageOptions.DontRequireReceiver);
                CrafterLogic.NotifyCraftEnd(vehicle, techType);
                Rigidbody body = vehicle.GetComponent<Rigidbody>();
                if (body) body.isKinematic = false;
                if (!vehicle.activeInHierarchy)
                {
                    Object.Destroy(vehicle);
                    Log.InGame($"GIVE: {techType} could not be activated.");
                    yield break;
                }
                // Awake runs on activation; Start and child spawn initialization run next frame.
                yield return null;
                yield return null;
                if (!vehicle) yield break;
                if (techType == TechType.Exosuit && vehicle.GetComponent<Exosuit>() is Exosuit exosuit)
                {
                    // The Mobile Vehicle Bay normally invokes this completion
                    // hook. Direct admin spawns bypass that construction path,
                    // leaving the Prawn in an unfinished state (open storage,
                    // disabled movement or broken exit). Invoke it after Start
                    // has initialized the prefab, before it can be entered.
                    exosuit.SubConstructionComplete();
                }
                if (VehicleHelper.IsVehicle(techType))
                {
                    if (!NitroxServiceLocator.LocateService<NitroxConsole>().Spawn(vehicle, techType))
                    {
                        Object.Destroy(vehicle);
                        Log.InGame($"GIVE: failed to initialize {techType}; see the game log.");
                        yield break;
                    }
                }
                else
                {
                    PrefabIdentifier identifier = vehicle.GetComponent<PrefabIdentifier>();
                    if (!identifier || string.IsNullOrEmpty(identifier.ClassId))
                    {
                        Object.Destroy(vehicle);
                        Log.InGame($"GIVE: {techType} has no synchronized world prefab.");
                        yield break;
                    }
                    Entity entity = new(vehicle.transform.position.ToDto(), vehicle.transform.rotation.ToDto(),
                        vehicle.transform.localScale.ToDto(), techType.ToDto(), 0, identifier.ClassId,
                        false, NitroxEntity.GetId(vehicle), null);
                    NitroxServiceLocator.LocateService<Entities>().BroadcastEntitySpawnedByClient(entity);
                }
                LargeWorldEntity.Register(vehicle);
                Log.InGame($"GIVE: spawned one {techType} nearby.");
                yield break;
            }
            if (!prefab || !prefab.GetComponent<Pickupable>())
            {
                Log.InGame($"GIVE: no spawnable prefab was found for {techType} in this game version.");
                yield break;
            }

            int given = 0;
            while (given < packet.Count)
            {
                GameObject item = Utils.SpawnPrefabAt(prefab, null, Player.main.transform.position);
                item.SetActive(true);
                if (!Inventory.main.Pickup(item.GetComponent<Pickupable>(), false))
                {
                    Object.Destroy(item);
                    break;
                }

                given++;
            }

            Log.InGame($"GIVE: added {given}/{packet.Count} x {techType} to your inventory.");
        }
    }
}
