using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxModel.Core;
using NitroxModel.Packets;

namespace NitroxClient.Communication.Packets.Processors
{
    public sealed class InteractiveStateSnapshotProcessor : ClientPacketProcessor<InteractiveStateSnapshot>
    {
        private static InteractiveStateSnapshot pending;

        public override void Process(InteractiveStateSnapshot packet)
        {
            pending = packet;
        }

        public static void ApplyPending()
        {
            InteractiveStateSnapshot snapshot = pending;
            pending = null;
            if (snapshot == null) return;

            ClientPacketProcessor<OpenableStateChanged> openables =
                NitroxServiceLocator.LocateService<ClientPacketProcessor<OpenableStateChanged>>();
            ClientPacketProcessor<StorageContainerStateChanged> storage =
                NitroxServiceLocator.LocateService<ClientPacketProcessor<StorageContainerStateChanged>>();
            ClientPacketProcessor<SealedDoorStateChanged> sealedDoors =
                NitroxServiceLocator.LocateService<ClientPacketProcessor<SealedDoorStateChanged>>();
            snapshot.Openables?.ForEach(openables.Process);
            snapshot.StorageContainers?.ForEach(storage.Process);
            snapshot.SealedDoors?.ForEach(sealedDoors.Process);
        }
    }
}
