﻿using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxClient.Unity.Helper;
using NitroxModel.Packets;
using UnityEngine;

namespace NitroxClient.Communication.Packets.Processors;

public class PlayFMODCustomLoopingEmitterProcessor : ClientPacketProcessor<PlayFMODCustomLoopingEmitter>
{
    public override void Process(PlayFMODCustomLoopingEmitter packet)
    {
        if (!NitroxEntity.TryGetComponentFrom(packet.Id, out FMODEmitterController fmodEmitterController) || !fmodEmitterController) return;

        fmodEmitterController.PlayCustomLoopingEmitter(packet.AssetPath);
    }
}
