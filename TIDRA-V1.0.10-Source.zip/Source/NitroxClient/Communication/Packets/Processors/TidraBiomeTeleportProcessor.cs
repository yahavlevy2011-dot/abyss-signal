using System;
using System.Linq;
using NitroxModel.Packets;
using NitroxClient.Communication.Packets.Processors.Abstract;
namespace NitroxClient.Communication.Packets.Processors
{
    public class TidraBiomeTeleportProcessor : ClientPacketProcessor<TidraBiomeTeleport>
    {
        public override void Process(TidraBiomeTeleport packet)
        {
            var data = BiomeConsoleCommand.main ? BiomeConsoleCommand.main.data : null;
            if (!data || data.locations == null || !Player.main) return;
            var location = data.locations.FirstOrDefault(p => string.Equals(p.name, packet.Name, StringComparison.OrdinalIgnoreCase));
            if (location == null)
            {
                Log.InGame($"Biomes: {string.Join(", ", data.locations.Select(p => p.name))}");
                return;
            }
            if (Player.main.GetVehicle() || Player.main.isPiloting || Player.main.cinematicModeActive)
            { Log.InGame("Exit the vehicle or cinematic before biome teleport."); return; }
            Player.main.SetCurrentSub(null);
            Player.main.SetPosition(location.position);
            Player.main.OnPlayerPositionCheat();
        }
    }
}
