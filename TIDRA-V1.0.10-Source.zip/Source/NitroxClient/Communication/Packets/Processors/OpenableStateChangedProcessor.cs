﻿using NitroxClient.Communication.Abstract;
using NitroxClient.Communication.Packets.Processors.Abstract;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UWE;
using NitroxClient.MonoBehaviours;
using NitroxClient.Unity.Helper;
using NitroxModel.Packets;
using UnityEngine;
using NitroxModel_Subnautica.DataStructures;

namespace NitroxClient.Communication.Packets.Processors
{
    public class OpenableStateChangedProcessor : ClientPacketProcessor<OpenableStateChanged>
    {
        private readonly IPacketSender packetSender;
        private readonly Dictionary<string, OpenableStateChanged> pending = new();
        private bool retrying;

        public OpenableStateChangedProcessor(IPacketSender packetSender)
        {
            this.packetSender = packetSender;
        }

        public override void Process(OpenableStateChanged packet)
        {
            if (packet?.Id == null) return;
            string key = packet.ParentId != null && packet.ChildPath != null
                ? $"{packet.NativeKind}:{packet.ParentId}/{string.Join(",", packet.ChildPath)}"
                : packet.Position != null && !string.IsNullOrEmpty(packet.ObjectName)
                    ? $"{packet.NativeKind}:{packet.ObjectName}/{packet.Position}"
                    : $"{packet.NativeKind}:{packet.Id}";
            if (TryApply(packet)) { pending.Remove(key); return; }
            pending[key] = packet;
            if (retrying) return;
            retrying = true;
            CoroutineHost.StartCoroutine(RetryPending());
        }

        private IEnumerator RetryPending()
        {
            while (Multiplayer.Main && pending.Count > 0)
            {
                yield return new WaitForSecondsRealtime(1f);
                foreach (KeyValuePair<string, OpenableStateChanged> entry in pending.ToArray())
                    if (TryApply(entry.Value)) pending.Remove(entry.Key);
            }
            pending.Clear();
            retrying = false;
        }

        private bool TryApply(OpenableStateChanged packet)
        {
            // Native hatch animation plays sound locally. Do not broadcast
            // those side effects back as new multiplayer interactions.
            using var customSound = packetSender.Suppress<PlayFMODCustomEmitter>();
            using var loopingSound = packetSender.Suppress<PlayFMODCustomLoopingEmitter>();
            using var studioSound = packetSender.Suppress<PlayFMODStudioEmitter>();
            using var assetSound = packetSender.Suppress<PlayFMODAsset>();
            var target = NitroxEntity.GetObjectFrom(packet.Id);
            if (target.HasValue && !HasExpectedComponent(target.Value, packet))
                target = default;
            if (!target.HasValue && packet.ParentId != null && packet.ChildPath != null && packet.ChildPath.Length <= 32)
            {
                var parent = NitroxEntity.GetObjectFrom(packet.ParentId);
                Transform resolved = parent.HasValue ? parent.Value.transform : null;
                foreach (int index in packet.ChildPath)
                {
                    if (!resolved || index < 0 || index >= resolved.childCount) { resolved = null; break; }
                    resolved = resolved.GetChild(index);
                }
                if (resolved && resolved.name == packet.ObjectName && HasExpectedComponent(resolved.gameObject, packet))
                    target = NitroxModel.DataStructures.Util.Optional.Of(resolved.gameObject);
            }
            if (packet.NativeKind != 0)
            {
                if (!target.HasValue && packet.Position != null && !string.IsNullOrEmpty(packet.ObjectName))
                {
                    Vector3 position = packet.Position.Value.ToUnity();
                    GameObject nearest = null;
                    float closest = 0.25f * 0.25f;
                    Component[] candidates = packet.NativeKind == 1 ? Object.FindObjectsOfType<CyclopsEntryHatch>() :
                        packet.NativeKind == 2 ? Object.FindObjectsOfType<OpenHatch>() :
                        Object.FindObjectsOfType<StarshipDoor>();
                    foreach (Component candidate in candidates)
                    {
                        if (candidate.name != packet.ObjectName) continue;
                        float distance = (candidate.transform.position - position).sqrMagnitude;
                        if (distance < closest) { closest = distance; nearest = candidate.gameObject; }
                    }
                    if (nearest) target = NitroxModel.DataStructures.Util.Optional.Of(nearest);
                }
                if (!target.HasValue) return false;
                using (packetSender.Suppress<OpenableStateChanged>())
                {
                    var hatch = target.Value.GetComponent<CyclopsEntryHatch>();
                    var openHatch = target.Value.GetComponent<OpenHatch>();
                    var door = target.Value.GetComponent<StarshipDoor>();
                    if (packet.NativeKind == 1 && !hatch || packet.NativeKind == 2 && !openHatch ||
                        packet.NativeKind == 3 && !door) return false;
                    if (packet.NativeKind == 3 && door && door.doorOpen != packet.IsOpen)
                    {
                        using (packetSender.Suppress<EntityMetadataUpdate>())
                        {
                            door.UnlockDoor();
                            door.OnDoorToggle();
                            door.doorOpen = packet.IsOpen;
                        }
                    }
                    if (packet.NativeKind == 1 && hatch && hatch.hatchOpen != packet.IsOpen)
                    { if (packet.IsOpen) hatch.OpenHatch(); else hatch.CloseHatch(false); }
                    else if (packet.NativeKind == 2 && openHatch && openHatch.IsOpen() != packet.IsOpen)
                        openHatch.SetOpenState(packet.IsOpen);
                }
                return true;
            }
            if (packet.IsLocker)
            {
                CyclopsLocker locker = target.HasValue ? target.Value.GetComponent<CyclopsLocker>() : null;
                if (locker && locker.openState != packet.IsOpen)
                    using (packetSender.Suppress<OpenableStateChanged>()) locker.ToggleDoor();
                return locker != null;
            }
            Openable openable = target.HasValue ? target.Value.GetComponent<Openable>() : null;
            if (!openable && packet.Position != null && !string.IsNullOrEmpty(packet.ObjectName))
            {
                float distance = 0.25f;
                foreach (Openable candidate in Object.FindObjectsOfType<Openable>())
                {
                    if (candidate.name != packet.ObjectName) continue;
                    float squared = (candidate.transform.position - packet.Position.Value.ToUnity()).sqrMagnitude;
                    if (squared < distance) { openable = candidate; distance = squared; }
                }
            }
            if (!openable) return false;

            using (packetSender.Suppress<OpenableStateChanged>())
            {
                openable.PlayOpenAnimation(packet.IsOpen, packet.Duration);
            }
            return true;
        }

        private static bool HasExpectedComponent(GameObject target, OpenableStateChanged packet)
        {
            if (packet.NativeKind == 1) return target.GetComponent<CyclopsEntryHatch>();
            if (packet.NativeKind == 2) return target.GetComponent<OpenHatch>();
            if (packet.NativeKind == 3) return target.GetComponent<StarshipDoor>();
            if (packet.IsLocker) return target.GetComponent<CyclopsLocker>();
            return target.GetComponent<Openable>();
        }
    }
}
