using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UWE;
using NitroxClient.Communication.Abstract;
using NitroxClient.Communication.Packets.Processors.Abstract;
using NitroxClient.MonoBehaviours;
using NitroxModel.Packets;
using UnityEngine;
using NitroxModel_Subnautica.DataStructures;

namespace NitroxClient.Communication.Packets.Processors
{
    public sealed class StorageContainerStateChangedProcessor : ClientPacketProcessor<StorageContainerStateChanged>
    {
        private readonly IPacketSender packetSender;
        private readonly Dictionary<string, StorageContainerStateChanged> pending = new();
        private bool retrying;

        public StorageContainerStateChangedProcessor(IPacketSender packetSender)
        {
            this.packetSender = packetSender;
        }

        public override void Process(StorageContainerStateChanged packet)
        {
            if (packet == null) return;
            string key = packet.ParentId != null && packet.ChildPath != null
                ? $"{packet.ParentId}/{string.Join(",", packet.ChildPath)}"
                : packet.Position != null && !string.IsNullOrEmpty(packet.ObjectName)
                    ? $"{packet.ObjectName}/{packet.Position}"
                    : packet.Id?.ToString();
            if (key == null) return;
            if (TryApply(packet)) { pending.Remove(key); return; }
            pending[key] = packet;
            if (retrying) return;
            retrying = true;
            CoroutineHost.StartCoroutine(RetryPending());
        }

        private IEnumerator RetryPending()
        {
            while (Multiplayer.Main && pending.Count > 0)
            {
                yield return new WaitForSecondsRealtime(1f);
                foreach (KeyValuePair<string, StorageContainerStateChanged> entry in pending.ToArray())
                    if (TryApply(entry.Value)) pending.Remove(entry.Key);
            }
            pending.Clear();
            retrying = false;
        }

        private bool TryApply(StorageContainerStateChanged packet)
        {
            GameObject gameObject = null;
            NitroxEntity.TryGetObjectFrom(packet.Id, out gameObject);
            if ((!gameObject || !gameObject.GetComponentInChildren<StorageContainer>(true)) && packet.ParentId != null && packet.ChildPath != null && packet.ChildPath.Length <= 32 &&
                NitroxEntity.TryGetObjectFrom(packet.ParentId, out GameObject parent))
            {
                Transform child = parent.transform;
                foreach (int index in packet.ChildPath)
                {
                    if (!child || index < 0 || index >= child.childCount) { child = null; break; }
                    child = child.GetChild(index);
                }
                if (child && child.name == packet.ObjectName) gameObject = child.gameObject;
            }
            if ((!gameObject || !gameObject.GetComponentInChildren<StorageContainer>(true)) && packet.Position != null && !string.IsNullOrEmpty(packet.ObjectName))
            {
                Vector3 position = packet.Position.Value.ToUnity();
                float closest = 0.25f * 0.25f;
                foreach (StorageContainer candidate in Object.FindObjectsOfType<StorageContainer>())
                {
                    if (candidate.name != packet.ObjectName) continue;
                    float distance = (candidate.transform.position - position).sqrMagnitude;
                    if (distance < closest) { closest = distance; gameObject = candidate.gameObject; }
                }
            }
            if (!gameObject) return false;

            StorageContainer storage = gameObject.GetComponentInChildren<StorageContainer>(true);
            if (!storage) return false;
            if (storage.open == packet.IsOpen)
            {
                return true;
            }

            using (packetSender.Suppress<StorageContainerStateChanged>())
            {
                // The native UseEvent drives locker/lifepod animation hooks.  A remote
                // player must never open our PDA, so replay only that visual event.
                storage.open = packet.IsOpen;
                storage.onUse?.Invoke();
            }
            return true;
        }
    }
}
