﻿using UnityEngine;

namespace NitroxClient.Unity.Smoothing
{
    class ExosuitSmoothRotation : SmoothRotation
    {
        private const float SMOOTHING_SPEED = 20f;
        private Quaternion target;
        public override Quaternion Target
        {
            get => target;
            set
            {
                target = value;
            }
        }

        public ExosuitSmoothRotation(Quaternion initial)
        {
            Target = Current = initial;
        }

        public ExosuitSmoothRotation()
        {
        }

        public override void FixedUpdate()
        {
            float blend = 1f - Mathf.Exp(-SMOOTHING_SPEED * Time.fixedDeltaTime);
            Current = Quaternion.Slerp(Current, Target, blend);
        }
    }
}
