﻿using UnityEngine;

namespace NitroxClient.Unity.Smoothing
{
    public class SmoothVector
    {
        private const float SMOOTHING_SPEED = 10f;
        public Vector3 Target { get; set; }
        public Vector3 Current { get; set; }

        public SmoothVector(Vector3 initial)
        {
            Target = Current = initial;
        }

        public SmoothVector()
        {
        }

        public void FixedUpdate()
        {
            // Positions and velocities are Cartesian values. Spherical interpolation
            // bends position corrections around the world origin and limits how
            // quickly a moving vehicle can catch up with its network target.
            float blend = 1f - Mathf.Exp(-SMOOTHING_SPEED * Time.fixedDeltaTime);
            Current = Vector3.Lerp(Current, Target, blend);
        }
    }
}
