from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
import json

root = Path(__file__).resolve().parent
publish = root / 'abyss75-publish'
source = Path('C:/Users/Yahav/Documents/Codex/2026-10-31/referenced-chatgpt-conversation-this-is-an-2/outputs/DeepCurrent-Legacy')
launcher = root / 'tidra-launcher-preview' / 'NitroxLauncher.exe'
output = publish / 'TIDRA-V1.0.10.zip'

with ZipFile(publish / 'TIDRA-V1.0.9.zip') as previous:
    files = {name: previous.read(name) for name in previous.namelist() if not name.endswith('/')}
files.pop('MANIFEST_SHA256.json', None)
files['AbyssSignal.exe'] = launcher.read_bytes()
notes = (
    'TIDRA 1.0.10 | Subnautica Legacy 68598\n'
    'Launcher update: Friends Network host/join steps, official ZeroTier installer download, '
    'network selection when multiple networks are joined, correct game IP for the selected network, '
    'and host approval of pending devices through a locally encrypted Legacy Central API token.\n'
    'Gameplay and server binaries are unchanged from 1.0.9. '
    'The launcher API connection was checked on the host. Two-computer gameplay was not tested.\n'
).encode('utf-8')
files['RELEASE_NOTES.txt'] = notes
files['READ_FIRST_HE.txt'] = (
    'TIDRA 1.0.10 | Subnautica Legacy 68598\n'
    'מסך Friends Network עודכן: בחירת רשת, כתובת משחק נכונה לרשת שנבחרה, '
    'הורדת ZeroTier במחשב שבו הוא חסר ואישור חברים ממתינים מתוך הלאנצ׳ר. '
    'אישור מתוך TIDRA דורש מפתח API חד־פעמי של בעל הרשת; אין לשלוח אותו לחברים. '
    'קובצי המשחק והשרת זהים לגרסה 1.0.9. החיבור בין שני מחשבים עדיין דורש בדיקה.\n'
).encode('utf-8')
files['MANIFEST_SHA256.json'] = json.dumps(
    {name: sha256(data).hexdigest() for name, data in sorted(files.items())}, indent=2
).encode('utf-8')

with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
    for name, data in files.items():
        archive.writestr(name, data)
with ZipFile(output) as archive:
    assert archive.testzip() is None
    manifest = json.loads(archive.read('MANIFEST_SHA256.json'))
    assert all(sha256(archive.read(name)).hexdigest() == expected for name, expected in manifest.items())

with ZipFile(publish / 'TIDRA-V1.0.9-Source.zip') as previous:
    sources = {name: previous.read(name) for name in previous.namelist() if not name.endswith('/')}
for file in source.rglob('*'):
    if not file.is_file() or file.suffix.lower() not in {'.cs', '.csproj', '.xaml', '.props', '.targets'}:
        continue
    relative = file.relative_to(source)
    if any(part.lower() in {'bin', 'obj', '.git', 'packages', 'generated_files'} for part in relative.parts):
        continue
    sources['Source/' + relative.as_posix()] = file.read_bytes()
sources['Source/Installer/package-v1010.py'] = Path(__file__).read_bytes()
sources['RELEASE_NOTES.txt'] = notes
source_output = publish / 'TIDRA-V1.0.10-Source.zip'
with ZipFile(source_output, 'w', ZIP_DEFLATED) as archive:
    for name, data in sorted(sources.items()):
        archive.writestr(name, data)
with ZipFile(source_output) as archive:
    assert archive.testzip() is None

digest = sha256(output.read_bytes()).hexdigest()
(publish / 'catalog.txt').write_text(f'120\n{output.name}\n{digest}\n', encoding='ascii')
(publish / 'index.html').write_text(
    '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    '<title>TIDRA V1.0.10</title><style>body{background:#071c29;color:#e5f8ff;font:18px system-ui;max-width:760px;margin:10vh auto;padding:24px}a{color:#6ce6ff}</style>'
    '<h1>TIDRA V1.0.10</h1><p>Subnautica Legacy 68598 launcher update · build 120</p>'
    '<p><a href="TIDRA-Setup.exe">Download Windows installer</a></p>'
    '<p>Friends Network now guides hosts and friends, selects the correct ZeroTier network and IP, and lets a host approve new devices in TIDRA after one-time API setup.</p>'
    '<p>Gameplay binaries are unchanged from 1.0.9. Two-computer gameplay still needs testing.</p>'
    '<p>No game files included. Original multiplayer engine attribution and license are preserved.</p>'
    '<p><a href="TIDRA-V1.0.10-Source.zip">Source and license</a> · <a href="catalog.txt">Update catalog</a></p></html>',
    encoding='utf-8'
)
print(f'{output}\nfiles={len(files)}\nsha256={digest}\n{source_output}')
