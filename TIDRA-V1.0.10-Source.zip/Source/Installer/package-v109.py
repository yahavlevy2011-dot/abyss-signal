from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
import json

root = Path(__file__).resolve().parent
publish = root / 'abyss75-publish'
build = root / 'tidra-next-build'
source = Path('C:/Users/Yahav/Documents/Codex/2026-10-31/referenced-chatgpt-conversation-this-is-an-2/outputs/DeepCurrent-Legacy')
output = publish / 'TIDRA-V1.0.9.zip'

with ZipFile(publish / 'TIDRA-V1.0.8.zip') as previous:
    files = {name: previous.read(name) for name in previous.namelist() if not name.endswith('/')}

files.pop('MANIFEST_SHA256.json', None)
files['AbyssSignal.exe'] = (build / 'NitroxLauncher.exe').read_bytes()
files['AbyssSignal.Server.exe'] = (build / 'NitroxServer-Subnautica.exe').read_bytes()
for project in ('NitroxClient', 'NitroxPatcher', 'NitroxModel', 'NitroxModel-Subnautica', 'NitroxServer'):
    files[f'lib/{project}.dll'] = (build / 'lib' / f'{project}.dll').read_bytes()

notes = (
    'TIDRA 1.0.9 | Subnautica Legacy 68598\n'
    'Based on TIDRA 1.0.8.\n'
    'Changes: remote Cyclops physics no longer runs native pilot thrust on a network replica; '
    'late-loaded storage and doors retry synchronized state; wrong local object IDs fall back to '
    'the matching physical object. Launcher version label updated.\n'
    'This is a public playtest build. Two-player storage/door animation and Cyclops movement '
    'still need gameplay verification.\n'
).encode('utf-8')
files['RELEASE_NOTES.txt'] = notes
files['READ_FIRST_HE.txt'] = (
    'TIDRA 1.0.9 | Subnautica Legacy 68598\n'
    'עדכון לבדיקה עם חברים. סנכרון האחסון והדלתות כולל כעת ניסיון חוזר לאחר טעינת אובייקט, '
    'ותנועת Cyclops מרוחקת אינה מפעילה גם את פיזיקת הנהג המקומית. '\
    'לא בוצעה בדיקת משחק לגרסה הזאת; בדקו במשחק לפני שמסתמכים עליה.\n'
).encode('utf-8')
files['MANIFEST_SHA256.json'] = json.dumps(
    {name: sha256(data).hexdigest() for name, data in sorted(files.items())}, indent=2
).encode('utf-8')

with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
    for name, data in files.items():
        archive.writestr(name, data)

with ZipFile(output) as archive:
    assert archive.testzip() is None
    manifest = json.loads(archive.read('MANIFEST_SHA256.json'))
    for name, expected in manifest.items():
        assert sha256(archive.read(name)).hexdigest() == expected, name

print(f'{output}\nfiles={len(files)}\nsha256={sha256(output.read_bytes()).hexdigest()}')

with ZipFile(publish / 'TIDRA-V17-Source.zip') as previous_source:
    sources = {name: previous_source.read(name) for name in previous_source.namelist() if not name.endswith('/')}
for file in source.rglob('*'):
    if not file.is_file() or file.suffix.lower() not in {'.cs', '.csproj', '.xaml', '.props', '.targets'}:
        continue
    relative = file.relative_to(source)
    if any(part.lower() in {'bin', 'obj', '.git', 'packages', 'generated_files'} for part in relative.parts):
        continue
    sources['Source/' + relative.as_posix()] = file.read_bytes()
sources['Source/Installer/TidraSetup.cs'] = (root / 'tidra-v17-installer' / 'TidraSetup.cs').read_bytes()
sources['Source/Installer/package-v109.py'] = Path(__file__).read_bytes()
sources['RELEASE_NOTES.txt'] = notes
source_output = publish / 'TIDRA-V1.0.9-Source.zip'
with ZipFile(source_output, 'w', ZIP_DEFLATED) as archive:
    for name, data in sorted(sources.items()):
        archive.writestr(name, data)
with ZipFile(source_output) as archive:
    assert archive.testzip() is None
print(f'{source_output}\nsource_files={len(sources)}')
