using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxModel.DataStructures;
using NitroxModel.DataStructures.Unity;
using NitroxModel.Packets;

namespace Nitrox.Test.Model.Packets
{
    [TestClass]
    public class TidraInteractionPacketTest
    {
        [TestMethod]
        public void ScanTargetSurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var id = new NitroxId();
            var sent = new AnimationChangeEvent(7, 12, 1, targetId: id);
            var received = (AnimationChangeEvent)Packet.Deserialize(sent.Serialize());
            Assert.AreEqual(id, received.TargetId);
            Assert.AreEqual(12, received.Type);
        }

        [TestMethod]
        public void CinematicMovementSurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var sent = new PlayerMovement(7, new NitroxVector3(1, 2, 3), NitroxVector3.Zero,
                NitroxQuaternion.Identity, NitroxQuaternion.Identity, true);
            var received = (PlayerMovement)Packet.Deserialize(sent.Serialize());
            Assert.IsTrue(received.IsCinematic);
            Assert.AreEqual(sent.Position, received.Position);
        }

        [TestMethod]
        public void ScannerFallbackSurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var sent = new AnimationChangeEvent(7, 12, 1, targetPosition: new NitroxVector3(1, 2, 3),
                targetTechType: new NitroxModel.DataStructures.GameLogic.NitroxTechType("SeamothFragment"));
            var received = (AnimationChangeEvent)Packet.Deserialize(sent.Serialize());
            Assert.AreEqual(sent.TargetPosition, received.TargetPosition);
            Assert.AreEqual(sent.TargetTechType, received.TargetTechType);
        }

        [TestMethod]
        public void OpenableFallbackSurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var sent = new OpenableStateChanged(new NitroxId(), true, 0.8f, new NitroxVector3(1, 2, 3), "Hatch");
            var received = (OpenableStateChanged)Packet.Deserialize(sent.Serialize());
            Assert.AreEqual(sent.Position, received.Position);
            Assert.AreEqual("Hatch", received.ObjectName);
            Assert.IsTrue(received.IsOpen);
        }

        [TestMethod]
        public void MovingVesselHatchIdentitySurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var parent = new NitroxId();
            var sent = new OpenableStateChanged(new NitroxId(), true, 0.5f,
                objectName: "Hatch", nativeKind: 1, parentId: parent, childPath: new[] { 2, 0, 3 });
            var received = (OpenableStateChanged)Packet.Deserialize(sent.Serialize());
            Assert.AreEqual(parent, received.ParentId);
            CollectionAssert.AreEqual(new[] { 2, 0, 3 }, received.ChildPath);
            Assert.AreEqual(1, received.NativeKind);
        }

        [TestMethod]
        public void OpenableWithoutFallbackSurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var sent = new OpenableStateChanged(new NitroxId(), false, 0.5f);
            var received = (OpenableStateChanged)Packet.Deserialize(sent.Serialize());
            Assert.IsFalse(received.Position.HasValue);
            Assert.IsNull(received.ObjectName);
        }

        [TestMethod]
        public void StorageContainerStateSurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var id = new NitroxId();
            var parentId = new NitroxId();
            var sent = new StorageContainerStateChanged(id, true, parentId, new[] { 1, 3 },
                "storage", new NitroxModel.DataStructures.Unity.NitroxVector3(2, 4, 6));
            var received = (StorageContainerStateChanged)Packet.Deserialize(sent.Serialize());
            Assert.AreEqual(id, received.Id);
            Assert.IsTrue(received.IsOpen);
            Assert.AreEqual(parentId, received.ParentId);
            CollectionAssert.AreEqual(new[] { 1, 3 }, received.ChildPath);
            Assert.AreEqual("storage", received.ObjectName);
            Assert.AreEqual(sent.Position, received.Position);
        }

        [TestMethod]
        public void SealedDoorFallbackSurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var parentId = new NitroxId();
            var sent = new SealedDoorStateChanged(null, parentId, new[] { 2, 1 }, "sealed_wall",
                new NitroxModel.DataStructures.Unity.NitroxVector3(10, 20, 30), false, 1.5f);
            var received = (SealedDoorStateChanged)Packet.Deserialize(sent.Serialize());
            Assert.AreEqual(parentId, received.ParentId);
            CollectionAssert.AreEqual(new[] { 2, 1 }, received.ChildPath);
            Assert.AreEqual("sealed_wall", received.ObjectName);
            Assert.IsFalse(received.IsSealed);
            Assert.AreEqual(1.5f, received.OpenedAmount);
        }

        [TestMethod]
        public void InteractiveStateSnapshotSurvivesNetworkSerialization()
        {
            Packet.InitSerializer();
            var openable = new OpenableStateChanged(new NitroxId(), true, 0.5f);
            var storage = new StorageContainerStateChanged(new NitroxId(), false);
            var sealedDoor = new SealedDoorStateChanged(null, null, null, "wreck_wall",
                new NitroxModel.DataStructures.Unity.NitroxVector3(5, 6, 7), false, 1f);
            var sent = new InteractiveStateSnapshot(new System.Collections.Generic.List<OpenableStateChanged> { openable },
                new System.Collections.Generic.List<StorageContainerStateChanged> { storage },
                new System.Collections.Generic.List<SealedDoorStateChanged> { sealedDoor });
            var received = (InteractiveStateSnapshot)Packet.Deserialize(sent.Serialize());
            Assert.AreEqual(1, received.Openables.Count);
            Assert.AreEqual(1, received.StorageContainers.Count);
            Assert.IsTrue(received.Openables[0].IsOpen);
            Assert.IsFalse(received.StorageContainers[0].IsOpen);
            Assert.AreEqual(1, received.SealedDoors.Count);
            Assert.AreEqual("wreck_wall", received.SealedDoors[0].ObjectName);
        }
    }
}
