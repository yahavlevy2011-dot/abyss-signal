using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxModel.Helper;

namespace Nitrox.Test.Model
{
    [TestClass]
    public class PrefabNameMatcherTest
    {
        [DataTestMethod]
        [DataRow("CyclopsBridgeFragment", "WorldEntities/Fragments/CyclopsBridge_Fragment", true)]
        [DataRow("CyclopsBridgeFragment", "WorldEntities/Environment/Wrecks/cyclopsbridgefragment3", true)]
        [DataRow("SeamothFragment", "WorldEntities/Fragments/Seamoth_Fragment.prefab", true)]
        [DataRow("SeaEmperorBaby", "WorldEntities/Creatures/SeaEmperorBaby", true)]
        [DataRow("SeaEmperor", "WorldEntities/Creatures/SeaEmperorBaby", false)]
        [DataRow("SeaEmperor", "WorldEntities/Creatures/SeaEmperorBabiesSpawner", false)]
        [DataRow("SeaEmperorBaby", "WorldEntities/Creatures/SeaEmperorBabiesSpawner", false)]
        [DataRow("CyclopsBridgeFragment", "WorldEntities/Fragments/OLD/CyclopsBridgeFragment", false)]
        [DataRow("CyclopsBridgeFragment", "WorldEntities/Fragments/CyclopsBridgeFragment_old", false)]
        [DataRow("Cyclops", "WorldEntities/Environment/CyclopsBridgeFragment", false)]
        [DataRow("", "WorldEntities/Creatures/Peeper", false)]
        public void OnlyExactItemsAndNumberedVariantsMatch(string techName, string path, bool expected)
        {
            Assert.AreEqual(expected, PrefabNameMatcher.Matches(techName, path));
        }
    }
}
