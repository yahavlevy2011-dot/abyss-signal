using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxModel.Helper;
using System.Threading.Tasks;

namespace Nitrox.Test.Model
{
    [TestClass]
    public class BoundedLogBufferTest
    {
        [TestMethod]
        public void ConsoleBurstRemainsBoundedAndRetainsRecentOutput()
        {
            var buffer = new BoundedLogBuffer();
            for (int i = 0; i < 100000; i++) buffer.Add($"packet {i}");
            Assert.IsTrue(buffer.PendingCount <= 256);
            string output = buffer.Drain(256);
            StringAssert.Contains(output, "skipped");
            StringAssert.Contains(output, "packet 99999");
            Assert.AreEqual(0, buffer.PendingCount);
            Assert.AreEqual("", buffer.Drain());
        }

        [TestMethod]
        public void ConcurrentThreeClientOutputDoesNotGrowWithoutBound()
        {
            var buffer = new BoundedLogBuffer();
            Parallel.For(0, 3, client =>
            {
                for (int i = 0; i < 10000; i++) buffer.Add($"client {client}: {i}");
            });
            Assert.IsTrue(buffer.PendingCount <= 256);
            Assert.IsTrue(buffer.Drain(256).Length < 65000);
        }

        [TestMethod]
        public void BatchesPreserveOrderAndClearDropsPendingOutput()
        {
            var buffer = new BoundedLogBuffer();
            buffer.Add("first"); buffer.Add("second");
            Assert.AreEqual("first" + System.Environment.NewLine, buffer.Drain(1));
            Assert.AreEqual(1, buffer.PendingCount);
            buffer.Clear();
            Assert.AreEqual("", buffer.Drain());
        }

        [TestMethod]
        public void OversizedLinesAreBoundedWithoutBlockingFutureOutput()
        {
            var buffer = new BoundedLogBuffer();
            for (int i = 0; i < 100; i++) buffer.Add(new string('x', 100000));
            buffer.Add("server ready");
            string output = buffer.Drain(256);
            Assert.IsTrue(output.Length < 65000);
            StringAssert.Contains(output, "server ready");
        }
    }
}
