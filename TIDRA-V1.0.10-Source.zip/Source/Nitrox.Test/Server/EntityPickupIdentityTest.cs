using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxModel.DataStructures;
using NitroxModel.DataStructures.GameLogic;
using NitroxModel.DataStructures.Unity;
using NitroxServer.GameLogic.Entities;

namespace Nitrox.Test.Server
{
    [TestClass]
    public class EntityPickupIdentityTest
    {
        private static Entity Create(string type, NitroxVector3 position, Entity parent = null) =>
            new Entity(position, NitroxQuaternion.Identity, NitroxVector3.One,
                new NitroxTechType(type), 0, "test", true, new NitroxId(), null, parent);

        [TestMethod]
        public void KnownIdentityTakesPrecedenceOverNearbyFragment()
        {
            Entity first = Create("SeamothFragment", NitroxVector3.Zero);
            Entity second = Create("SeamothFragment", NitroxVector3.Zero);
            var manager = new EntityManager(new List<Entity> { first, second }, null);
            Assert.AreEqual(first.Id, manager.ResolvePickupId(first.Id, first.TechType, NitroxVector3.Zero));
        }

        [DataTestMethod]
        [DataRow("SeamothFragment")]
        [DataRow("FireExtinguisher")]
        public void UniqueNearbyWorldObjectResolvesToServerIdentity(string type)
        {
            Entity entity = Create(type, new NitroxVector3(100, 20, 30));
            var manager = new EntityManager(new List<Entity> { entity }, null);
            Assert.AreEqual(entity.Id, manager.ResolvePickupId(new NitroxId(), entity.TechType,
                new NitroxVector3(100.1f, 20, 30)));
        }

        [TestMethod]
        public void AmbiguousFragmentsAreNotRemovedByPosition()
        {
            Entity first = Create("SeamothFragment", NitroxVector3.Zero);
            Entity second = Create("SeamothFragment", new NitroxVector3(0.1f, 0, 0));
            var manager = new EntityManager(new List<Entity> { first, second }, null);
            var supplied = new NitroxId();
            Assert.AreEqual(supplied, manager.ResolvePickupId(supplied, first.TechType, NitroxVector3.Zero));
        }

        [DataTestMethod]
        [DataRow("SeamothFragment", 1f)]
        [DataRow("CyclopsHullFragment", 0f)]
        [DataRow("Titanium", 0f)]
        [DataRow("SeamothFragment", float.NaN)]
        public void UnrelatedDistantOrInvalidPositionDoesNotResolve(string requestedType, float x)
        {
            Entity entity = Create("SeamothFragment", NitroxVector3.Zero);
            var manager = new EntityManager(new List<Entity> { entity }, null);
            var supplied = new NitroxId();
            Assert.AreEqual(supplied, manager.ResolvePickupId(supplied, new NitroxTechType(requestedType),
                new NitroxVector3(x, 0, 0)));
        }

        [TestMethod]
        public void ResolvedChildUsesWorldPositionAndIsRemovedFromAllServerIndexes()
        {
            Entity parent = Create("Wreck", new NitroxVector3(100, 0, 0));
            Entity fragment = Create("SeamothFragment", new NitroxVector3(1, 0, 0), parent);
            parent.ChildEntities.Add(fragment);
            var manager = new EntityManager(new List<Entity> { parent, fragment }, null);
            NitroxId resolved = manager.ResolvePickupId(new NitroxId(), fragment.TechType, new NitroxVector3(101, 0, 0));
            Assert.AreEqual(fragment.Id, resolved);
            manager.PickUpEntity(resolved);
            Assert.IsFalse(manager.GetEntityById(resolved).HasValue);
            Assert.IsFalse(parent.ChildEntities.Contains(fragment));
            Assert.IsFalse(manager.GetEntities(fragment.AbsoluteEntityCell).Contains(fragment));
        }

        [TestMethod]
        public void WorldPickupIsAcceptedOnceUntilTheItemIsDroppedAgain()
        {
            Entity entity = Create("Titanium", NitroxVector3.Zero);
            var manager = new EntityManager(new List<Entity> { entity }, null);
            Assert.IsTrue(manager.TryMarkPickedUp(entity.Id));
            Assert.IsFalse(manager.TryMarkPickedUp(entity.Id));
            manager.PickUpEntity(entity.Id);
            manager.RegisterNewEntity(entity);
            Assert.IsTrue(manager.TryMarkPickedUp(entity.Id));
        }

        [TestMethod]
        public void ResourceKeepsAllYieldsFromOnePlayerAndRejectsAnotherPlayer()
        {
            var manager = new EntityManager(new List<Entity>(), null);
            NitroxId source = new();
            Assert.IsTrue(manager.TryMarkResourceYield(source, 0, 1));
            Assert.IsTrue(manager.TryMarkResourceYield(source, 1, 1));
            Assert.IsFalse(manager.TryMarkResourceYield(source, 0, 1));
            Assert.IsFalse(manager.TryMarkResourceYield(source, 2, 2));
        }
    }
}
