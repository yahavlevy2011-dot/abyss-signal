using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxModel.DataStructures;
using NitroxModel.Packets;
using NitroxServer.GameLogic;

namespace Nitrox.Test.Server
{
    [TestClass]
    public class OpenableRelayGuardTest
    {
        [TestMethod]
        public void ThreeClientDuplicateBurstRelaysOnlyOneState()
        {
            var guard = new OpenableRelayGuard();
            var id = new NitroxId();
            int relayed = 0;
            for (int frame = 0; frame < 10000; frame++)
                for (int client = 0; client < 3; client++)
                    if (guard.TryAccept(new OpenableStateChanged(id, false, 0.5f, nativeKind: 1))) relayed++;
            Assert.AreEqual(1, relayed);
            Assert.IsTrue(guard.TryAccept(new OpenableStateChanged(id, true, 0.5f, nativeKind: 1)));
            Assert.IsTrue(guard.TryAccept(new OpenableStateChanged(id, false, 0.5f, nativeKind: 1)));
        }

        [TestMethod]
        public void InvalidUninitializedHatchesAreNeverRelayed()
        {
            var guard = new OpenableRelayGuard();
            for (int i = 0; i < 30000; i++)
                Assert.IsFalse(guard.TryAccept(new OpenableStateChanged(null, false, 0.5f, nativeKind: 1)));
            Assert.IsFalse(guard.TryAccept(new OpenableStateChanged(new NitroxId(), false, float.NaN)));
        }

        [TestMethod]
        public void DoorsRemainIndependentAndStateChangesAreNotRateDropped()
        {
            var guard = new OpenableRelayGuard();
            var first = new NitroxId();
            var second = new NitroxId();
            for (int i = 0; i < 100; i++)
            {
                bool open = i % 2 == 0;
                Assert.IsTrue(guard.TryAccept(new OpenableStateChanged(first, open, 0.5f)));
                Assert.IsTrue(guard.TryAccept(new OpenableStateChanged(second, open, 0.5f)));
            }
        }

        [TestMethod]
        public void BoundedStateCacheCanEvictAndReadmitOldObjects()
        {
            var guard = new OpenableRelayGuard();
            var first = new NitroxId();
            Assert.IsTrue(guard.TryAccept(new OpenableStateChanged(first, true, 0.5f)));
            for (int i = 0; i < 5000; i++)
                Assert.IsTrue(guard.TryAccept(new OpenableStateChanged(new NitroxId(), true, 0.5f)));
            Assert.IsTrue(guard.TryAccept(new OpenableStateChanged(first, true, 0.5f)));
        }

        [TestMethod]
        public void SamePhysicalDoorWithDifferentClientIdsRelaysOneState()
        {
            var guard = new OpenableRelayGuard();
            var parent = new NitroxId();
            var first = new OpenableStateChanged(new NitroxId(), true, 0.5f,
                objectName: "Door", parentId: parent, childPath: new[] { 2, 1 });
            var second = new OpenableStateChanged(new NitroxId(), true, 0.5f,
                objectName: "Door", parentId: parent, childPath: new[] { 2, 1 });
            Assert.IsTrue(guard.TryAccept(first));
            Assert.IsFalse(guard.TryAccept(second));
            Assert.IsTrue(guard.TryAccept(new OpenableStateChanged(new NitroxId(), false, 0.5f,
                objectName: "Door", parentId: parent, childPath: new[] { 2, 1 })));
        }
    }
}
