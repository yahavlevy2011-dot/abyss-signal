using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxModel.DataStructures;
using NitroxModel.DataStructures.GameLogic;
using NitroxServer.GameLogic.Items;

namespace Nitrox.Test.Server
{
    [TestClass]
    public class InventoryContainerOrderTest
    {
        [TestMethod]
        public void LateRemoveCannotEraseItemMovedToAnotherLocker()
        {
            NitroxId firstLocker = new();
            NitroxId secondLocker = new();
            NitroxId itemId = new();
            var manager = new InventoryManager(new List<ItemData>(), new List<ItemData>(), new List<EquippedItemData>());
            Assert.IsTrue(manager.InventoryItemAdded(new BasicItemData(firstLocker, itemId, new byte[] { 1 })));
            Assert.IsTrue(manager.InventoryItemAdded(new BasicItemData(secondLocker, itemId, new byte[] { 2 })));
            Assert.IsFalse(manager.InventoryItemRemoved(itemId, firstLocker));
            Assert.AreEqual(secondLocker, new List<ItemData>(manager.GetAllInventoryItems())[0].ContainerId);
            Assert.IsTrue(manager.InventoryItemRemoved(itemId, secondLocker));
        }

        [TestMethod]
        public void RepeatedAddToSameLockerDoesNotDuplicateItem()
        {
            NitroxId locker = new();
            NitroxId itemId = new();
            var manager = new InventoryManager(new List<ItemData>(), new List<ItemData>(), new List<EquippedItemData>());
            Assert.IsTrue(manager.InventoryItemAdded(new BasicItemData(locker, itemId, new byte[] { 1 })));
            Assert.IsFalse(manager.InventoryItemAdded(new BasicItemData(locker, itemId, new byte[] { 1 })));
            Assert.AreEqual(1, manager.GetAllInventoryItems().Count);
        }
    }
}
