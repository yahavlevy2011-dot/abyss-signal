using Microsoft.VisualStudio.TestTools.UnitTesting;
using NitroxClient.Communication.Abstract;
using NitroxClient.GameLogic;
using NitroxModel.DataStructures;
using NitroxModel.Packets;
using NSubstitute;

namespace Nitrox.Test.Client
{
    [TestClass]
    public class InteriorSuppressionTest
    {
        [TestMethod]
        public void UninitializedIdentityDoesNotSend()
        {
            var sender = Substitute.For<IPacketSender>();
            var interior = new Interior(sender);
            for (int i = 0; i < 10000; i++) interior.OpenableStateChanged(null, false, 0.5f, nativeKind: 1);
            sender.DidNotReceive().Send(Arg.Any<Packet>());
        }

        [TestMethod]
        public void RemoteSuppressedInteractionDoesNotSendOrResolveObjects()
        {
            var sender = Substitute.For<IPacketSender>();
            sender.IsPacketSuppressed(typeof(OpenableStateChanged)).Returns(true);
            new Interior(sender).OpenableStateChanged(new NitroxId(), true, 0.5f, nativeKind: 1);
            sender.DidNotReceive().Send(Arg.Any<Packet>());
        }
    }
}
