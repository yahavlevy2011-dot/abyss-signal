TIDRA V16 — tested multiplayer fixes

Includes shared opening readiness/skip, remote held-tool inventory identification,
camera aim synchronization, initial world-cell reconciliation and join rejection/cancel fixes.
Samples passed in two real local game clients: matched world items, pickup in both
directions, reload persistence, tools/PDA, Fabricator occupancy, basic construction,
short Seamoth/Prawn entry/movement/exit tests.

Not a full-game certification. Creature movement, sustained swim smoothness,
cross-computer latency, all biomes, Cyclops, Aurora and the ending remain incomplete.
The unverified experimental fish-motion change is NOT included.
Both the server and all clients must update together. Stop the old server first.
No Subnautica game files are included. Existing game installation and worlds remain separate.
